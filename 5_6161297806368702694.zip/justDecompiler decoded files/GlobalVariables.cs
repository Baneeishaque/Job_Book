using Microsoft.VisualBasic.CompilerServices;
using System;

namespace ScanApp
{
	internal static class GlobalVariables
	{
		public static string strNetworkAddress;

		public static string strNetworkDB;

		public static string strNetworkUsername;

		public static string strNetworkPassword;

		public static string strConnectionString;

		public static string strDepartmentCode;

		public static string strTableId;

		public static string strSpreadSheetLocation;

		public static string VerifyServer;

		public static string VerifyDB;

		public static string VerifyTable;

		public static string CopyTable;

		public static string VerifyUser;

		public static string VerifyPwd;

		public static string WebServiceURL;

		public static string strMessagePrefixWarning;

		public static string strMessagePrefixError;

		public static string strMessagePrefixInfo;

		public static string strBarcodeNumber;

		static GlobalVariables()
		{
			GlobalVariables.strNetworkAddress = "";
			GlobalVariables.strNetworkDB = "";
			GlobalVariables.strNetworkUsername = "";
			GlobalVariables.strNetworkPassword = "";
			GlobalVariables.strConnectionString = "";
			GlobalVariables.strDepartmentCode = "";
			GlobalVariables.strTableId = "";
			GlobalVariables.strSpreadSheetLocation = "";
			GlobalVariables.VerifyServer = "";
			GlobalVariables.VerifyDB = "";
			GlobalVariables.VerifyTable = "";
			GlobalVariables.CopyTable = "";
			GlobalVariables.VerifyUser = "";
			GlobalVariables.VerifyPwd = "";
			GlobalVariables.WebServiceURL = "";
			GlobalVariables.strMessagePrefixWarning = "Warning : ";
			GlobalVariables.strMessagePrefixError = "Error : ";
			GlobalVariables.strMessagePrefixInfo = "Info : ";
			GlobalVariables.strBarcodeNumber = "";
		}
	}
}