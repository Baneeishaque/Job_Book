using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Web.Services;
using System.Web.Services.Description;
using System.Web.Services.Protocols;

namespace ScanApp.LegnanoService
{
	[DebuggerStepThrough]
	[DesignerCategory("code")]
	[WebServiceBinding(Name="Service1Soap", Namespace="http://tempuri.org/")]
	public class Service1 : SoapHttpClientProtocol
	{
		public Service1()
		{
			this.Url = "http://localhost/WSLegnanoConnectionService/Service1.asmx";
		}

		public IAsyncResult BeginCheckRecords(string Job, string Item, int CoreTotal, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, CoreTotal };
			IAsyncResult asyncResult = this.BeginInvoke("CheckRecords", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginCheckTableIsBusy(string EquipmentNo, AsyncCallback callback, object asyncState)
		{
			object[] equipmentNo = new object[] { EquipmentNo };
			IAsyncResult asyncResult = this.BeginInvoke("CheckTableIsBusy", equipmentNo, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BegincloseMK500Connection(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("closeMK500Connection", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginCommitTransaction(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("CommitTransaction", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginCopyDataFromDB(string DocumentNo, string Posizione, AsyncCallback callback, object asyncState)
		{
			object[] documentNo = new object[] { DocumentNo, Posizione };
			IAsyncResult asyncResult = this.BeginInvoke("CopyDataFromDB", documentNo, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginCreateNoForWorkInProgress(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("CreateNoForWorkInProgress", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginCreateNoForWorkInProgressNC(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("CreateNoForWorkInProgressNC", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginDeleteFinishedEquipmentScrum(string Job, string Item, string Core, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal };
			IAsyncResult asyncResult = this.BeginInvoke("DeleteFinishedEquipmentScrum", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginDeleteItemInWP(string Job, string Item, string Core, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal };
			IAsyncResult asyncResult = this.BeginInvoke("DeleteItemInWP", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginDeletequery(string Job, string Item, string Core, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal };
			IAsyncResult asyncResult = this.BeginInvoke("Deletequery", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginDoingEquipmentScrum(string Job, string Item, string Core, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal };
			IAsyncResult asyncResult = this.BeginInvoke("DoingEquipmentScrum", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginDoingQuery(string Job, string Item, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, CoreTotal };
			IAsyncResult asyncResult = this.BeginInvoke("DoingQuery", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginDonequery(string Job, string Item, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, CoreTotal };
			IAsyncResult asyncResult = this.BeginInvoke("Donequery", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginGetCustomDate(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("GetCustomDate", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginGetServerDateTime(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("GetServerDateTime", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginHelloWorld(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("HelloWorld", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginInitializeTransaction(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("InitializeTransaction", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginInsertEquipmentScrum(string EquipmentNo, string Job, string Item, int Core, int CoreTotal, string Phases, string Status, AsyncCallback callback, object asyncState)
		{
			object[] equipmentNo = new object[] { EquipmentNo, Job, Item, Core, CoreTotal, Phases, Status };
			IAsyncResult asyncResult = this.BeginInvoke("InsertEquipmentScrum", equipmentNo, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginInsertInNetwork(string Job, string Item, string CustomerNo, string CustomerDescription, string CoreDescription, int Core, int CoreTotal, string Location, string Operation, string BadgeStart, DateTime myStartDate, decimal NoOfOperator, string DepartmentCode, decimal Weight, decimal Thickness, decimal Stackmm, decimal Column1MeasureInmm, decimal CentralMeasuremm, decimal Column2MeasureInmm, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, CustomerNo, CustomerDescription, CoreDescription, Core, CoreTotal, Location, Operation, BadgeStart, myStartDate, NoOfOperator, DepartmentCode, Weight, Thickness, Stackmm, Column1MeasureInmm, CentralMeasuremm, Column2MeasureInmm };
			IAsyncResult asyncResult = this.BeginInvoke("InsertInNetwork", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginInsertScrumTable(string Job, string Item, int CoreTotal, int ToDo, int Doing, int Done, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, CoreTotal, ToDo, Doing, Done };
			IAsyncResult asyncResult = this.BeginInvoke("InsertScrumTable", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginInsertWorkInProgress(string Job, string Item, int Core, int CoreTotal, string Location, string Operation, string BadgeStart, DateTime myStartDate, decimal NoOfOperator, string DepartmentCode, decimal Stackmm, decimal Column1MeasureInmm, decimal CentralMeasuremm, decimal Column2MeasureInmm, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal, Location, Operation, BadgeStart, myStartDate, NoOfOperator, DepartmentCode, Stackmm, Column1MeasureInmm, CentralMeasuremm, Column2MeasureInmm };
			IAsyncResult asyncResult = this.BeginInvoke("InsertWorkInProgress", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginInsertWorkInProgressNC(string Job, string Item, int Core, string SubOperation, string BadgeStart, DateTime myStartDate, string DepartmentCode, string DescriptionStart, string DescriptionEnd, string Block, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, Core, SubOperation, BadgeStart, myStartDate, DepartmentCode, DescriptionStart, DescriptionEnd, Block };
			IAsyncResult asyncResult = this.BeginInvoke("InsertWorkInProgressNC", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginOnGoingCount(string Job, string Item, int Core, int CoreTotal, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal };
			IAsyncResult asyncResult = this.BeginInvoke("OnGoingCount", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginopenMK500Connection(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("openMK500Connection", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginQryCustomerName(string Job, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job };
			IAsyncResult asyncResult = this.BeginInvoke("QryCustomerName", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginRollbackTransaction(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("RollbackTransaction", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginTestFirstDBConnection(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("TestFirstDBConnection", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginTestSecondDBConnection(AsyncCallback callback, object asyncState)
		{
			IAsyncResult asyncResult = this.BeginInvoke("TestSecondDBConnection", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginToDoquery(string Job, string Item, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, CoreTotal };
			IAsyncResult asyncResult = this.BeginInvoke("ToDoquery", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginUpdateEquipmentScrum(string EquipmentNo, string Job, string Item, string Core, string CoreTotal, string Phases, string Status, AsyncCallback callback, object asyncState)
		{
			object[] equipmentNo = new object[] { EquipmentNo, Job, Item, Core, CoreTotal, Phases, Status };
			IAsyncResult asyncResult = this.BeginInvoke("UpdateEquipmentScrum", equipmentNo, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginUpdateScrumTable(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, CoreTotal, ToDo, Doing, Done };
			IAsyncResult asyncResult = this.BeginInvoke("UpdateScrumTable", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginUpdateScrumTableOnEndClosing(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, CoreTotal, ToDo, Doing, Done };
			IAsyncResult asyncResult = this.BeginInvoke("UpdateScrumTableOnEndClosing", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginUpdateScrumTableOnStartConformity(string Job, string Item, int ToDo, int Doing, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, ToDo, Doing, CoreTotal };
			IAsyncResult asyncResult = this.BeginInvoke("UpdateScrumTableOnStartConformity", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginUpdateScrumTableOnStartNonConformity(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, CoreTotal, ToDo, Doing, Done };
			IAsyncResult asyncResult = this.BeginInvoke("UpdateScrumTableOnStartNonConformity", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginUpdateWorkInNetwork(string BadgeEnd, DateTime DateEnd, string Job, string Item, int Core, int CoreTotal, string Location, decimal NoOfOperator, string Operation, AsyncCallback callback, object asyncState)
		{
			object[] badgeEnd = new object[] { BadgeEnd, DateEnd, Job, Item, Core, CoreTotal, Location, NoOfOperator, Operation };
			IAsyncResult asyncResult = this.BeginInvoke("UpdateWorkInNetwork", badgeEnd, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginUpdateWorkInProgress(string CustomerNo, string CoreDescription, string CustomerDescription, string Thickness, string Weight, string Job, string Item, string Core, string CoreTotal, string Location, string Operation, AsyncCallback callback, object asyncState)
		{
			object[] customerNo = new object[] { CustomerNo, CoreDescription, CustomerDescription, Thickness, Weight, Job, Item, Core, CoreTotal, Location, Operation };
			IAsyncResult asyncResult = this.BeginInvoke("UpdateWorkInProgress", customerNo, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginUpdateWorkInProgressNC(string BadgeEnd, DateTime DateEnd, string Job, string Item, int Core, string BadgeStart, DateTime DateStart, AsyncCallback callback, object asyncState)
		{
			object[] badgeEnd = new object[] { BadgeEnd, DateEnd, Job, Item, Core, BadgeStart, DateStart };
			IAsyncResult asyncResult = this.BeginInvoke("UpdateWorkInProgressNC", badgeEnd, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginValidateData(string DocumentNo, string Posizione, AsyncCallback callback, object asyncState)
		{
			object[] documentNo = new object[] { DocumentNo, Posizione };
			IAsyncResult asyncResult = this.BeginInvoke("ValidateData", documentNo, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		public IAsyncResult BeginValidateDuplicateEntry(string Job, string Item, string Core, string CoreTotal, string Operation, AsyncCallback callback, object asyncState)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal, Operation };
			IAsyncResult asyncResult = this.BeginInvoke("ValidateDuplicateEntry", job, callback, RuntimeHelpers.GetObjectValue(asyncState));
			return asyncResult;
		}

		[SoapDocumentMethod("http://tempuri.org/CheckRecords", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string CheckRecords(string Job, string Item, int CoreTotal)
		{
			object[] job = new object[] { Job, Item, CoreTotal };
			object[] objArray = this.Invoke("CheckRecords", job);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/CheckTableIsBusy", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string CheckTableIsBusy(string EquipmentNo)
		{
			object[] equipmentNo = new object[] { EquipmentNo };
			object[] objArray = this.Invoke("CheckTableIsBusy", equipmentNo);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/closeMK500Connection", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public void closeMK500Connection()
		{
			this.Invoke("closeMK500Connection", new object[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/CommitTransaction", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public void CommitTransaction()
		{
			this.Invoke("CommitTransaction", new object[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/CopyDataFromDB", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public DataTable CopyDataFromDB(string DocumentNo, string Posizione)
		{
			object[] documentNo = new object[] { DocumentNo, Posizione };
			return (DataTable)this.Invoke("CopyDataFromDB", documentNo)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/CreateNoForWorkInProgress", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string CreateNoForWorkInProgress()
		{
			object[] objArray = this.Invoke("CreateNoForWorkInProgress", new object[0]);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/CreateNoForWorkInProgressNC", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string CreateNoForWorkInProgressNC()
		{
			object[] objArray = this.Invoke("CreateNoForWorkInProgressNC", new object[0]);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/DeleteFinishedEquipmentScrum", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object DeleteFinishedEquipmentScrum(string Job, string Item, string Core, string CoreTotal)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal };
			return this.Invoke("DeleteFinishedEquipmentScrum", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/DeleteItemInWP", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object DeleteItemInWP(string Job, string Item, string Core, string CoreTotal)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal };
			return this.Invoke("DeleteItemInWP", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/Deletequery", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object Deletequery(string Job, string Item, string Core, string CoreTotal)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal };
			return this.Invoke("Deletequery", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/DoingEquipmentScrum", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string DoingEquipmentScrum(string Job, string Item, string Core, string CoreTotal)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal };
			object[] objArray = this.Invoke("DoingEquipmentScrum", job);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/DoingQuery", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string DoingQuery(string Job, string Item, string CoreTotal)
		{
			object[] job = new object[] { Job, Item, CoreTotal };
			object[] objArray = this.Invoke("DoingQuery", job);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/Donequery", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string Donequery(string Job, string Item, string CoreTotal)
		{
			object[] job = new object[] { Job, Item, CoreTotal };
			object[] objArray = this.Invoke("Donequery", job);
			return Conversions.ToString(objArray[0]);
		}

		public string EndCheckRecords(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public string EndCheckTableIsBusy(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public void EndcloseMK500Connection(IAsyncResult asyncResult)
		{
			this.EndInvoke(asyncResult);
		}

		public void EndCommitTransaction(IAsyncResult asyncResult)
		{
			this.EndInvoke(asyncResult);
		}

		public DataTable EndCopyDataFromDB(IAsyncResult asyncResult)
		{
			return (DataTable)this.EndInvoke(asyncResult)[0];
		}

		public string EndCreateNoForWorkInProgress(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public string EndCreateNoForWorkInProgressNC(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public object EndDeleteFinishedEquipmentScrum(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndDeleteItemInWP(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndDeletequery(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public string EndDoingEquipmentScrum(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public string EndDoingQuery(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public string EndDonequery(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public string EndGetCustomDate(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public string EndGetServerDateTime(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public string EndHelloWorld(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public void EndInitializeTransaction(IAsyncResult asyncResult)
		{
			this.EndInvoke(asyncResult);
		}

		public object EndInsertEquipmentScrum(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndInsertInNetwork(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndInsertScrumTable(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndInsertWorkInProgress(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndInsertWorkInProgressNC(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndOnGoingCount(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public void EndopenMK500Connection(IAsyncResult asyncResult)
		{
			this.EndInvoke(asyncResult);
		}

		public string EndQryCustomerName(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public void EndRollbackTransaction(IAsyncResult asyncResult)
		{
			this.EndInvoke(asyncResult);
		}

		public bool EndTestFirstDBConnection(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToBoolean(objArray[0]);
		}

		public bool EndTestSecondDBConnection(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToBoolean(objArray[0]);
		}

		public string EndToDoquery(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public object EndUpdateEquipmentScrum(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndUpdateScrumTable(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndUpdateScrumTableOnEndClosing(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndUpdateScrumTableOnStartConformity(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndUpdateScrumTableOnStartNonConformity(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndUpdateWorkInNetwork(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndUpdateWorkInProgress(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public object EndUpdateWorkInProgressNC(IAsyncResult asyncResult)
		{
			return this.EndInvoke(asyncResult)[0];
		}

		public string EndValidateData(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		public string EndValidateDuplicateEntry(IAsyncResult asyncResult)
		{
			object[] objArray = this.EndInvoke(asyncResult);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/GetCustomDate", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string GetCustomDate()
		{
			object[] objArray = this.Invoke("GetCustomDate", new object[0]);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/GetServerDateTime", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string GetServerDateTime()
		{
			object[] objArray = this.Invoke("GetServerDateTime", new object[0]);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/HelloWorld", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string HelloWorld()
		{
			object[] objArray = this.Invoke("HelloWorld", new object[0]);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/InitializeTransaction", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public void InitializeTransaction()
		{
			this.Invoke("InitializeTransaction", new object[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/InsertEquipmentScrum", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object InsertEquipmentScrum(string EquipmentNo, string Job, string Item, int Core, int CoreTotal, string Phases, string Status)
		{
			object[] equipmentNo = new object[] { EquipmentNo, Job, Item, Core, CoreTotal, Phases, Status };
			return this.Invoke("InsertEquipmentScrum", equipmentNo)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/InsertInNetwork", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object InsertInNetwork(string Job, string Item, string CustomerNo, string CustomerDescription, string CoreDescription, int Core, int CoreTotal, string Location, string Operation, string BadgeStart, DateTime myStartDate, decimal NoOfOperator, string DepartmentCode, decimal Weight, decimal Thickness, decimal Stackmm, decimal Column1MeasureInmm, decimal CentralMeasuremm, decimal Column2MeasureInmm)
		{
			object[] job = new object[] { Job, Item, CustomerNo, CustomerDescription, CoreDescription, Core, CoreTotal, Location, Operation, BadgeStart, myStartDate, NoOfOperator, DepartmentCode, Weight, Thickness, Stackmm, Column1MeasureInmm, CentralMeasuremm, Column2MeasureInmm };
			return this.Invoke("InsertInNetwork", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/InsertScrumTable", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object InsertScrumTable(string Job, string Item, int CoreTotal, int ToDo, int Doing, int Done)
		{
			object[] job = new object[] { Job, Item, CoreTotal, ToDo, Doing, Done };
			return this.Invoke("InsertScrumTable", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/InsertWorkInProgress", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object InsertWorkInProgress(string Job, string Item, int Core, int CoreTotal, string Location, string Operation, string BadgeStart, DateTime myStartDate, decimal NoOfOperator, string DepartmentCode, decimal Stackmm, decimal Column1MeasureInmm, decimal CentralMeasuremm, decimal Column2MeasureInmm)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal, Location, Operation, BadgeStart, myStartDate, NoOfOperator, DepartmentCode, Stackmm, Column1MeasureInmm, CentralMeasuremm, Column2MeasureInmm };
			return this.Invoke("InsertWorkInProgress", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/InsertWorkInProgressNC", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object InsertWorkInProgressNC(string Job, string Item, int Core, string SubOperation, string BadgeStart, DateTime myStartDate, string DepartmentCode, string DescriptionStart, string DescriptionEnd, string Block)
		{
			object[] job = new object[] { Job, Item, Core, SubOperation, BadgeStart, myStartDate, DepartmentCode, DescriptionStart, DescriptionEnd, Block };
			return this.Invoke("InsertWorkInProgressNC", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/OnGoingCount", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object OnGoingCount(string Job, string Item, int Core, int CoreTotal)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal };
			return this.Invoke("OnGoingCount", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/openMK500Connection", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public void openMK500Connection()
		{
			this.Invoke("openMK500Connection", new object[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/QryCustomerName", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string QryCustomerName(string Job)
		{
			object[] job = new object[] { Job };
			object[] objArray = this.Invoke("QryCustomerName", job);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/RollbackTransaction", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public void RollbackTransaction()
		{
			this.Invoke("RollbackTransaction", new object[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/TestFirstDBConnection", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public bool TestFirstDBConnection()
		{
			object[] objArray = this.Invoke("TestFirstDBConnection", new object[0]);
			return Conversions.ToBoolean(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/TestSecondDBConnection", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public bool TestSecondDBConnection()
		{
			object[] objArray = this.Invoke("TestSecondDBConnection", new object[0]);
			return Conversions.ToBoolean(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/ToDoquery", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string ToDoquery(string Job, string Item, string CoreTotal)
		{
			object[] job = new object[] { Job, Item, CoreTotal };
			object[] objArray = this.Invoke("ToDoquery", job);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/UpdateEquipmentScrum", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object UpdateEquipmentScrum(string EquipmentNo, string Job, string Item, string Core, string CoreTotal, string Phases, string Status)
		{
			object[] equipmentNo = new object[] { EquipmentNo, Job, Item, Core, CoreTotal, Phases, Status };
			return this.Invoke("UpdateEquipmentScrum", equipmentNo)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/UpdateScrumTable", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object UpdateScrumTable(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done)
		{
			object[] job = new object[] { Job, Item, CoreTotal, ToDo, Doing, Done };
			return this.Invoke("UpdateScrumTable", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/UpdateScrumTableOnEndClosing", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object UpdateScrumTableOnEndClosing(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done)
		{
			object[] job = new object[] { Job, Item, CoreTotal, ToDo, Doing, Done };
			return this.Invoke("UpdateScrumTableOnEndClosing", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/UpdateScrumTableOnStartConformity", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object UpdateScrumTableOnStartConformity(string Job, string Item, int ToDo, int Doing, string CoreTotal)
		{
			object[] job = new object[] { Job, Item, ToDo, Doing, CoreTotal };
			return this.Invoke("UpdateScrumTableOnStartConformity", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/UpdateScrumTableOnStartNonConformity", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object UpdateScrumTableOnStartNonConformity(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done)
		{
			object[] job = new object[] { Job, Item, CoreTotal, ToDo, Doing, Done };
			return this.Invoke("UpdateScrumTableOnStartNonConformity", job)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/UpdateWorkInNetwork", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object UpdateWorkInNetwork(string BadgeEnd, DateTime DateEnd, string Job, string Item, int Core, int CoreTotal, string Location, decimal NoOfOperator, string Operation)
		{
			object[] badgeEnd = new object[] { BadgeEnd, DateEnd, Job, Item, Core, CoreTotal, Location, NoOfOperator, Operation };
			return this.Invoke("UpdateWorkInNetwork", badgeEnd)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/UpdateWorkInProgress", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object UpdateWorkInProgress(string CustomerNo, string CoreDescription, string CustomerDescription, string Thickness, string Weight, string Job, string Item, string Core, string CoreTotal, string Location, string Operation)
		{
			object[] customerNo = new object[] { CustomerNo, CoreDescription, CustomerDescription, Thickness, Weight, Job, Item, Core, CoreTotal, Location, Operation };
			return this.Invoke("UpdateWorkInProgress", customerNo)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/UpdateWorkInProgressNC", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public object UpdateWorkInProgressNC(string BadgeEnd, DateTime DateEnd, string Job, string Item, int Core, string BadgeStart, DateTime DateStart)
		{
			object[] badgeEnd = new object[] { BadgeEnd, DateEnd, Job, Item, Core, BadgeStart, DateStart };
			return this.Invoke("UpdateWorkInProgressNC", badgeEnd)[0];
		}

		[SoapDocumentMethod("http://tempuri.org/ValidateData", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string ValidateData(string DocumentNo, string Posizione)
		{
			object[] documentNo = new object[] { DocumentNo, Posizione };
			object[] objArray = this.Invoke("ValidateData", documentNo);
			return Conversions.ToString(objArray[0]);
		}

		[SoapDocumentMethod("http://tempuri.org/ValidateDuplicateEntry", RequestNamespace="http://tempuri.org/", ResponseNamespace="http://tempuri.org/", Use=SoapBindingUse.Literal, ParameterStyle=SoapParameterStyle.Wrapped)]
		public string ValidateDuplicateEntry(string Job, string Item, string Core, string CoreTotal, string Operation)
		{
			object[] job = new object[] { Job, Item, Core, CoreTotal, Operation };
			object[] objArray = this.Invoke("ValidateDuplicateEntry", job);
			return Conversions.ToString(objArray[0]);
		}
	}
}