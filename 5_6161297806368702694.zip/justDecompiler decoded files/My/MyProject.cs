using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ScanApp;
using ScanApp.LegnanoService;
using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;

namespace ScanApp.My
{
	[GeneratedCode("MyTemplate", "8.0.0.0")]
	[HideModuleName]
	internal static class MyProject
	{
		private static MyProject.ThreadSafeObjectProvider<MyProject.MyForms> m_MyFormsObjectProvider;

		private readonly static MyProject.ThreadSafeObjectProvider<MyProject.MyWebServices> m_MyWebServicesObjectProvider;

		internal static MyProject.MyForms Forms
		{
			[DebuggerHidden]
			get
			{
				return MyProject.m_MyFormsObjectProvider.GetInstance;
			}
		}

		internal static MyProject.MyWebServices WebServices
		{
			[DebuggerHidden]
			get
			{
				return MyProject.m_MyWebServicesObjectProvider.GetInstance;
			}
		}

		[DebuggerNonUserCode]
		static MyProject()
		{
			MyProject.m_MyFormsObjectProvider = new MyProject.ThreadSafeObjectProvider<MyProject.MyForms>();
			MyProject.m_MyWebServicesObjectProvider = new MyProject.ThreadSafeObjectProvider<MyProject.MyWebServices>();
		}

		[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
		[MyGroupCollection("System.Windows.Forms.Form", "Create__Instance__", "Dispose__Instance__", "My.MyProject.Forms")]
		internal sealed class MyForms
		{
			public SmartApp m_SmartApp;

			private static Hashtable m_FormBeingCreated;

			public SmartApp SmartApp
			{
				[DebuggerNonUserCode]
				get
				{
					this.m_SmartApp = MyProject.MyForms.Create__Instance__<SmartApp>(this.m_SmartApp);
					return this.m_SmartApp;
				}
				[DebuggerNonUserCode]
				set
				{
					if ((object)value != (object)this.m_SmartApp)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.Dispose__Instance__<SmartApp>(ref this.m_SmartApp);
					}
				}
			}

			[DebuggerHidden]
			[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
			public MyForms()
			{
			}

			[DebuggerHidden]
			private static T Create__Instance__<T>(T Instance)
			where T : Form, new()
			{
				T instance;
				if (Instance != null)
				{
					instance = Instance;
				}
				else
				{
					if (MyProject.MyForms.m_FormBeingCreated == null)
					{
						MyProject.MyForms.m_FormBeingCreated = new Hashtable();
					}
					else if (MyProject.MyForms.m_FormBeingCreated.ContainsKey(typeof(T)))
					{
						throw new InvalidOperationException(Utils.GetResourceString("WinForms_RecursiveFormCreate", new string[0]));
					}
					MyProject.MyForms.m_FormBeingCreated.Add(typeof(T), null);
					try
					{
						try
						{
							instance = (T)Activator.CreateInstance(typeof(T));
						}
						catch (TargetInvocationException targetInvocationException) when (targetInvocationException.get_InnerException() != null)
						{
							string[] message = new string[] { targetInvocationException.get_InnerException().get_Message() };
							string resourceString = Utils.GetResourceString("WinForms_SeeInnerException", message);
							throw new InvalidOperationException(resourceString, targetInvocationException.get_InnerException());
						}
					}
					finally
					{
						MyProject.MyForms.m_FormBeingCreated.Remove(typeof(T));
					}
				}
				return instance;
			}

			[DebuggerHidden]
			private void Dispose__Instance__<T>(ref T instance)
			where T : Form
			{
				instance.Dispose();
				instance = default(T);
			}

			[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
			public override bool Equals(object o)
			{
				return this.Equals(RuntimeHelpers.GetObjectValue(o));
			}

			[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
			public override int GetHashCode()
			{
				return this.GetHashCode();
			}

			[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
			internal Type GetType()
			{
				return typeof(MyProject.MyForms);
			}

			[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
			public override string ToString()
			{
				return this.ToString();
			}
		}

		[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
		[MyGroupCollection("System.Web.Services.Protocols.SoapHttpClientProtocol", "Create__Instance__", "Dispose__Instance__", "")]
		internal sealed class MyWebServices
		{
			public Service1 m_Service1;

			public Service1 Service1
			{
				[DebuggerNonUserCode]
				get
				{
					this.m_Service1 = MyProject.MyWebServices.Create__Instance__<Service1>(this.m_Service1);
					return this.m_Service1;
				}
				[DebuggerNonUserCode]
				set
				{
					if ((object)value != (object)this.m_Service1)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.Dispose__Instance__<Service1>(ref this.m_Service1);
					}
				}
			}

			[DebuggerHidden]
			[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
			public MyWebServices()
			{
			}

			[DebuggerHidden]
			private static T Create__Instance__<T>(T instance)
			where T : new()
			{
				T t;
				t = (instance != null ? instance : (T)Activator.CreateInstance(typeof(T)));
				return t;
			}

			[DebuggerHidden]
			private void Dispose__Instance__<T>(ref T instance)
			{
				instance = default(T);
			}

			[DebuggerHidden]
			[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
			public override bool Equals(object o)
			{
				return this.Equals(RuntimeHelpers.GetObjectValue(o));
			}

			[DebuggerHidden]
			[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
			public override int GetHashCode()
			{
				return this.GetHashCode();
			}

			[DebuggerHidden]
			[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
			internal Type GetType()
			{
				return typeof(MyProject.MyWebServices);
			}

			[DebuggerHidden]
			[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
			public override string ToString()
			{
				return this.ToString();
			}
		}

		[ComVisible(false)]
		[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
		internal sealed class ThreadSafeObjectProvider<T>
		where T : new()
		{
			internal T GetInstance
			{
				get
				{
					if (this.$STATIC$get_GetInstance$200130$DataSlotName == null || this.$STATIC$get_GetInstance$200130$DataSlotName.get_Length() == 0)
					{
						Random random = new Random();
						CultureInfo currentCulture = CultureInfo.get_CurrentCulture();
						object[] objArray = new object[] { random.Next() };
						this.$STATIC$get_GetInstance$200130$DataSlotName = string.Format(currentCulture, "{0}.Microsoft.VisualBasic.CompilerServices.ProjectData", objArray);
					}
					LocalDataStoreSlot namedDataSlot = Thread.GetNamedDataSlot(this.$STATIC$get_GetInstance$200130$DataSlotName);
					object objectValue = RuntimeHelpers.GetObjectValue(Thread.GetData(namedDataSlot));
					T genericParameter = Conversions.ToGenericParameter<T>(RuntimeHelpers.GetObjectValue(objectValue));
					if (genericParameter == null)
					{
						genericParameter = (T)Activator.CreateInstance(typeof(T));
						Thread.SetData(namedDataSlot, genericParameter);
					}
					return genericParameter;
				}
			}

			[DebuggerHidden]
			[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
			public ThreadSafeObjectProvider()
			{
			}
		}
	}
}