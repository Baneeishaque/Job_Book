using Microsoft.VisualBasic.CompilerServices;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;

namespace ScanApp.My.Resources
{
	[DebuggerNonUserCode]
	internal static class Resources
	{
		private static System.Resources.ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		internal static string About
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("About", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string AboutMsg
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("AboutMsg", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string AimMode
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("AimMode", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string AimType
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("AimType", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string AppExitMsg
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("AppExitMsg", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Back
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Back", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Background
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Background", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Code128
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Code128", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Code39
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Code39", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
		internal static CultureInfo Culture
		{
			get
			{
				return ScanApp.My.Resources.Resources.resourceCulture;
			}
			set
			{
				ScanApp.My.Resources.Resources.resourceCulture = value;
			}
		}

		internal static string Data
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Data", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Decoders
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Decoders", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Disabled
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Disabled", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Dot
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Dot", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Enabled
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Enabled", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string ExitApp
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("ExitApp", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Failure
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Failure", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Foreground
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Foreground", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Hold
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Hold", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string InitReader
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("InitReader", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string InvalidIndexer
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("InvalidIndexer", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string InvalidRequest
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("InvalidRequest", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Item
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Item", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string ItemNotSelected
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("ItemNotSelected", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Length
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Length", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Monitor
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Monitor", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string NoDeviceSelected
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("NoDeviceSelected", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string None
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("None", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string OperationFailure
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("OperationFailure", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Options
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Options", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Release
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Release", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		[EditorBrowsable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
		internal static System.Resources.ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(ScanApp.My.Resources.Resources.resourceMan, null))
				{
					ScanApp.My.Resources.Resources.resourceMan = new System.Resources.ResourceManager("ScanApp.Resources", typeof(ScanApp.My.Resources.Resources).get_Assembly());
				}
				return ScanApp.My.Resources.Resources.resourceMan;
			}
		}

		internal static string Result
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Result", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Reticle
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Reticle", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Scan
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Scan", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string ScanContinuous
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("ScanContinuous", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string ScanType
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("ScanType", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string SelectDevice
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("SelectDevice", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Slab
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Slab", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Source
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Source", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string StartRead
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("StartRead", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string StopRead
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("StopRead", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string TermReader
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("TermReader", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Time
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Time", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Trigger
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Trigger", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Type
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Type", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string Value
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("Value", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}

		internal static string VB_BarcodeSample1
		{
			get
			{
				return ScanApp.My.Resources.Resources.ResourceManager.GetString("VB_BarcodeSample1", ScanApp.My.Resources.Resources.resourceCulture);
			}
		}
	}
}