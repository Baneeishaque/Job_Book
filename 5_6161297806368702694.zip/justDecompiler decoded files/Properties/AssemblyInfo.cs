﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("ScanApp")]
[assembly: AssemblyTitle("ScanApp")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]
[assembly: Debuggable(,)]    // JustDecompile was unable to locate the assembly where attribute parameters types are defined. Generating parameters values is impossible.
[assembly: Guid("9ddc21c8-9be1-423d-9ff3-965e6d8b4e92")]
