using System;
using System.Diagnostics;
using System.Resources;

namespace ScanApp
{
	internal class Resources
	{
		private static ResourceManager m_rmNameValues;

		static Resources()
		{
			Resources.m_rmNameValues = new ResourceManager("VB_BarcodeSample1.Resources", typeof(Resources).get_Assembly());
		}

		[DebuggerNonUserCode]
		public Resources()
		{
		}

		public static string GetString(string name)
		{
			return Resources.m_rmNameValues.GetString(name);
		}
	}
}