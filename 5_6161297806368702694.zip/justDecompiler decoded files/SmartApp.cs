using Microsoft.VisualBasic.CompilerServices;
using ScanApp.LegnanoService;
using ScanApp.My;
using ScanApp.VB_BarcodeSample1;
using Symbol;
using Symbol.Barcode;
using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Web.Services.Protocols;
using System.Windows.Forms;
using System.Xml;

namespace ScanApp
{
	[DesignerGenerated]
	public class SmartApp : Form
	{
		private IContainer components;

		[AccessedThroughProperty("pnlMenu")]
		private Panel _pnlMenu;

		[AccessedThroughProperty("pcLegnano")]
		private PictureBox _pcLegnano;

		[AccessedThroughProperty("Label8")]
		private Label _Label8;

		[AccessedThroughProperty("lblSelectActivity")]
		private Label _lblSelectActivity;

		[AccessedThroughProperty("btnActivity6")]
		private Button _btnActivity6;

		[AccessedThroughProperty("btnActivity5")]
		private Button _btnActivity5;

		[AccessedThroughProperty("btnActivity4")]
		private Button _btnActivity4;

		[AccessedThroughProperty("btnActivity3")]
		private Button _btnActivity3;

		[AccessedThroughProperty("btnActivity2")]
		private Button _btnActivity2;

		[AccessedThroughProperty("btnActivity1")]
		private Button _btnActivity1;

		[AccessedThroughProperty("tbActivities")]
		private TabControl _tbActivities;

		[AccessedThroughProperty("tbSelectActivity")]
		private TabPage _tbSelectActivity;

		[AccessedThroughProperty("tbScanBarcodes")]
		private TabPage _tbScanBarcodes;

		[AccessedThroughProperty("tbSelectTasks")]
		private TabPage _tbSelectTasks;

		[AccessedThroughProperty("pcClose")]
		private PictureBox _pcClose;

		[AccessedThroughProperty("Label7")]
		private Label _Label7;

		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		[AccessedThroughProperty("Label2")]
		private Label _Label2;

		[AccessedThroughProperty("lblTime")]
		private Label _lblTime;

		[AccessedThroughProperty("Label3")]
		private Label _Label3;

		[AccessedThroughProperty("Label4")]
		private Label _Label4;

		[AccessedThroughProperty("btn3Activity")]
		private Button _btn3Activity;

		[AccessedThroughProperty("btn2Activity")]
		private Button _btn2Activity;

		[AccessedThroughProperty("btn1Activity")]
		private Button _btn1Activity;

		[AccessedThroughProperty("lblMessage")]
		private Label _lblMessage;

		[AccessedThroughProperty("txtCoreNo")]
		private TextBox _txtCoreNo;

		[AccessedThroughProperty("txtJobNo")]
		private TextBox _txtJobNo;

		[AccessedThroughProperty("btnEndJob")]
		private Button _btnEndJob;

		[AccessedThroughProperty("btnPauseJob")]
		private Button _btnPauseJob;

		[AccessedThroughProperty("Timer1")]
		private Timer _Timer1;

		[AccessedThroughProperty("lblActivity")]
		private Label _lblActivity;

		[AccessedThroughProperty("lblNoOfOperator")]
		private Label _lblNoOfOperator;

		[AccessedThroughProperty("Label9")]
		private Label _Label9;

		[AccessedThroughProperty("Label10")]
		private Label _Label10;

		[AccessedThroughProperty("Label11")]
		private Label _Label11;

		[AccessedThroughProperty("txtActivityName")]
		private TextBox _txtActivityName;

		[AccessedThroughProperty("btnResume")]
		private Button _btnResume;

		[AccessedThroughProperty("StatusName")]
		private TextBox _StatusName;

		[AccessedThroughProperty("statusCoreNo")]
		private TextBox _statusCoreNo;

		[AccessedThroughProperty("statusJobNo")]
		private TextBox _statusJobNo;

		[AccessedThroughProperty("statusBadgeId")]
		private TextBox _statusBadgeId;

		[AccessedThroughProperty("statusActivity")]
		private TextBox _statusActivity;

		[AccessedThroughProperty("Label15")]
		private Label _Label15;

		[AccessedThroughProperty("Label17")]
		private Label _Label17;

		[AccessedThroughProperty("Label16")]
		private Label _Label16;

		[AccessedThroughProperty("Label19")]
		private Label _Label19;

		[AccessedThroughProperty("Label18")]
		private Label _Label18;

		[AccessedThroughProperty("Label20")]
		private Label _Label20;

		[AccessedThroughProperty("txtBadgeId")]
		private TextBox _txtBadgeId;

		[AccessedThroughProperty("tbTableConfig")]
		private TabPage _tbTableConfig;

		[AccessedThroughProperty("txtConfigDepartmentCode")]
		private TextBox _txtConfigDepartmentCode;

		[AccessedThroughProperty("Label21")]
		private Label _Label21;

		[AccessedThroughProperty("txtConfigTableId")]
		private TextBox _txtConfigTableId;

		[AccessedThroughProperty("lblTable")]
		private Label _lblTable;

		[AccessedThroughProperty("btn4Activity")]
		private Button _btn4Activity;

		[AccessedThroughProperty("btnCancelConfig")]
		private Button _btnCancelConfig;

		[AccessedThroughProperty("btnSaveConfig")]
		private Button _btnSaveConfig;

		[AccessedThroughProperty("pcSettings")]
		private PictureBox _pcSettings;

		[AccessedThroughProperty("lblDepartmentCode")]
		private Label _lblDepartmentCode;

		[AccessedThroughProperty("lblTableId")]
		private Label _lblTableId;

		[AccessedThroughProperty("btnAdd")]
		private Button _btnAdd;

		[AccessedThroughProperty("btnSubtract")]
		private Button _btnSubtract;

		[AccessedThroughProperty("NoOfOperatorValue")]
		private NumericUpDown _NoOfOperatorValue;

		[AccessedThroughProperty("MsgIconConfig")]
		private PictureBox _MsgIconConfig;

		[AccessedThroughProperty("msgConfig")]
		private Label _msgConfig;

		[AccessedThroughProperty("Label12")]
		private Label _Label12;

		[AccessedThroughProperty("statusTime")]
		private TextBox _statusTime;

		[AccessedThroughProperty("buttonContinue")]
		private Button _buttonContinue;

		[AccessedThroughProperty("buttonBack")]
		private Button _buttonBack;

		[AccessedThroughProperty("btnClr2")]
		private Button _btnClr2;

		[AccessedThroughProperty("btnClr1")]
		private Button _btnClr1;

		[AccessedThroughProperty("Timer2")]
		private Timer _Timer2;

		[AccessedThroughProperty("msgIcon")]
		private PictureBox _msgIcon;

		[AccessedThroughProperty("StartJob")]
		private Button _StartJob;

		[AccessedThroughProperty("btnMinus")]
		private Button _btnMinus;

		[AccessedThroughProperty("btnPlus")]
		private Button _btnPlus;

		[AccessedThroughProperty("NumericNoOfOperator")]
		private NumericUpDown _NumericNoOfOperator;

		private string strBarcode;

		private System.Diagnostics.Stopwatch stopwatch;

		public DateTime myTime;

		private bool myconnection;

		private string NoOfOperator;

		public string activity;

		public string badgeid;

		public string CustomerNo;

		public string CustomerName;

		public string Description;

		public string NetWeight;

		public string NonConformityDoing;

		public string jobno;

		public string coreno;

		public string tableid;

		public string status;

		private SqlConnection connection;

		public string BadgeStart;

		public string StartDate;

		public string BadgeEnd;

		public string EndDate;

		public string ConfigDepartmentCode;

		public string CoreDescription;

		public decimal WeightForUnitKg;

		public string CustomerDescription;

		public decimal ThicknessInmm;

		public decimal StackInmm;

		public decimal Column1MeasureInmm;

		public decimal CentralMeasureInmm;

		public decimal Column2MeasureInmm;

		public string ConfigTableId;

		private string jobstatus;

		private bool IsClicked;

		private string temp;

		private int ToDo;

		private int Doing;

		private int Done;

		private EventHandler MyEventHandler;

		private bool NoOfOperatorValueIsFocused;

		private ScanApp.VB_BarcodeSample1.API myScanSampleAPI;

		private EventHandler myReadNotifyHandler;

		private EventHandler myStatusNotifyHandler;

		private EventHandler myFormActivatedEventHandler;

		private EventHandler myFormDeactivatedEventHandler;

		private bool isReaderInitiated;

		private States prevState;

		internal virtual Button btn1Activity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btn1Activity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btn1Activity_Click);
				if (this._btn1Activity != null)
				{
					this._btn1Activity.remove_Click(eventHandler);
				}
				this._btn1Activity = value;
				if (this._btn1Activity != null)
				{
					this._btn1Activity.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btn2Activity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btn2Activity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btn2Activity_Click);
				if (this._btn2Activity != null)
				{
					this._btn2Activity.remove_Click(eventHandler);
				}
				this._btn2Activity = value;
				if (this._btn2Activity != null)
				{
					this._btn2Activity.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btn3Activity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btn3Activity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btn3Activity_Click);
				if (this._btn3Activity != null)
				{
					this._btn3Activity.remove_Click(eventHandler);
				}
				this._btn3Activity = value;
				if (this._btn3Activity != null)
				{
					this._btn3Activity.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btn4Activity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btn4Activity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btn4Activity_Click);
				if (this._btn4Activity != null)
				{
					this._btn4Activity.remove_Click(eventHandler);
				}
				this._btn4Activity = value;
				if (this._btn4Activity != null)
				{
					this._btn4Activity.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btnActivity1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity1 = value;
			}
		}

		internal virtual Button btnActivity2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity2 = value;
			}
		}

		internal virtual Button btnActivity3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity3 = value;
			}
		}

		internal virtual Button btnActivity4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity4 = value;
			}
		}

		internal virtual Button btnActivity5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity5 = value;
			}
		}

		internal virtual Button btnActivity6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity6 = value;
			}
		}

		internal virtual Button btnAdd
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnAdd;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btnAdd_Click);
				if (this._btnAdd != null)
				{
					this._btnAdd.remove_Click(eventHandler);
				}
				this._btnAdd = value;
				if (this._btnAdd != null)
				{
					this._btnAdd.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btnCancelConfig
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnCancelConfig;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btnCancelConfig_Click);
				if (this._btnCancelConfig != null)
				{
					this._btnCancelConfig.remove_Click(eventHandler);
				}
				this._btnCancelConfig = value;
				if (this._btnCancelConfig != null)
				{
					this._btnCancelConfig.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btnClr1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnClr1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btnClr1_Click);
				if (this._btnClr1 != null)
				{
					this._btnClr1.remove_Click(eventHandler);
				}
				this._btnClr1 = value;
				if (this._btnClr1 != null)
				{
					this._btnClr1.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btnClr2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnClr2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btnClr2_Click);
				if (this._btnClr2 != null)
				{
					this._btnClr2.remove_Click(eventHandler);
				}
				this._btnClr2 = value;
				if (this._btnClr2 != null)
				{
					this._btnClr2.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btnEndJob
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnEndJob;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btnEndJob_Click);
				if (this._btnEndJob != null)
				{
					this._btnEndJob.remove_Click(eventHandler);
				}
				this._btnEndJob = value;
				if (this._btnEndJob != null)
				{
					this._btnEndJob.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btnMinus
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnMinus;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btnMinus_Click);
				if (this._btnMinus != null)
				{
					this._btnMinus.remove_Click(eventHandler);
				}
				this._btnMinus = value;
				if (this._btnMinus != null)
				{
					this._btnMinus.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btnPauseJob
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnPauseJob;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btnPauseJob_Click);
				if (this._btnPauseJob != null)
				{
					this._btnPauseJob.remove_Click(eventHandler);
				}
				this._btnPauseJob = value;
				if (this._btnPauseJob != null)
				{
					this._btnPauseJob.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btnPlus
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnPlus;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btnPlus_Click);
				if (this._btnPlus != null)
				{
					this._btnPlus.remove_Click(eventHandler);
				}
				this._btnPlus = value;
				if (this._btnPlus != null)
				{
					this._btnPlus.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btnResume
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnResume;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btnResume_Click);
				if (this._btnResume != null)
				{
					this._btnResume.remove_Click(eventHandler);
				}
				this._btnResume = value;
				if (this._btnResume != null)
				{
					this._btnResume.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btnSaveConfig
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnSaveConfig;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btnSaveConfig_Click);
				if (this._btnSaveConfig != null)
				{
					this._btnSaveConfig.remove_Click(eventHandler);
				}
				this._btnSaveConfig = value;
				if (this._btnSaveConfig != null)
				{
					this._btnSaveConfig.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button btnSubtract
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnSubtract;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.btnSubtract_Click);
				if (this._btnSubtract != null)
				{
					this._btnSubtract.remove_Click(eventHandler);
				}
				this._btnSubtract = value;
				if (this._btnSubtract != null)
				{
					this._btnSubtract.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button buttonBack
		{
			[DebuggerNonUserCode]
			get
			{
				return this._buttonBack;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.buttonBack_Click);
				if (this._buttonBack != null)
				{
					this._buttonBack.remove_Click(eventHandler);
				}
				this._buttonBack = value;
				if (this._buttonBack != null)
				{
					this._buttonBack.add_Click(eventHandler);
				}
			}
		}

		internal virtual Button buttonContinue
		{
			[DebuggerNonUserCode]
			get
			{
				return this._buttonContinue;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.buttonContinue_Click);
				if (this._buttonContinue != null)
				{
					this._buttonContinue.remove_Click(eventHandler);
				}
				this._buttonContinue = value;
				if (this._buttonContinue != null)
				{
					this._buttonContinue.add_Click(eventHandler);
				}
			}
		}

		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label1 = value;
			}
		}

		internal virtual Label Label10
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label10;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label10 = value;
			}
		}

		internal virtual Label Label11
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label11;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label11 = value;
			}
		}

		internal virtual Label Label12
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label12;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label12 = value;
			}
		}

		internal virtual Label Label15
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label15;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label15 = value;
			}
		}

		internal virtual Label Label16
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label16;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label16 = value;
			}
		}

		internal virtual Label Label17
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label17;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label17 = value;
			}
		}

		internal virtual Label Label18
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label18;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label18 = value;
			}
		}

		internal virtual Label Label19
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label19;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label19 = value;
			}
		}

		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label2 = value;
			}
		}

		internal virtual Label Label20
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label20;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label20 = value;
			}
		}

		internal virtual Label Label21
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label21;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label21 = value;
			}
		}

		internal virtual Label Label3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label3 = value;
			}
		}

		internal virtual Label Label4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label4 = value;
			}
		}

		internal virtual Label Label7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label7 = value;
			}
		}

		internal virtual Label Label8
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label8;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label8 = value;
			}
		}

		internal virtual Label Label9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label9 = value;
			}
		}

		internal virtual Label lblActivity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblActivity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblActivity = value;
			}
		}

		internal virtual Label lblDepartmentCode
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblDepartmentCode;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblDepartmentCode = value;
			}
		}

		internal virtual Label lblMessage
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblMessage;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblMessage = value;
			}
		}

		internal virtual Label lblNoOfOperator
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblNoOfOperator;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblNoOfOperator = value;
			}
		}

		internal virtual Label lblSelectActivity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblSelectActivity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblSelectActivity = value;
			}
		}

		internal virtual Label lblTable
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblTable;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblTable = value;
			}
		}

		internal virtual Label lblTableId
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblTableId;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblTableId = value;
			}
		}

		internal virtual Label lblTime
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblTime;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblTime = value;
			}
		}

		internal virtual Label msgConfig
		{
			[DebuggerNonUserCode]
			get
			{
				return this._msgConfig;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._msgConfig = value;
			}
		}

		private virtual PictureBox msgIcon
		{
			[DebuggerNonUserCode]
			get
			{
				return this._msgIcon;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._msgIcon = value;
			}
		}

		internal virtual PictureBox MsgIconConfig
		{
			[DebuggerNonUserCode]
			get
			{
				return this._MsgIconConfig;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._MsgIconConfig = value;
			}
		}

		public string Myactivity
		{
			get
			{
				return this.activity;
			}
		}

		public string MyBadgeEnd
		{
			get
			{
				return this.BadgeEnd;
			}
		}

		public string MyBadgeId
		{
			get
			{
				return this.badgeid;
			}
		}

		public string MyBadgeStart
		{
			get
			{
				return this.BadgeStart;
			}
		}

		public string MyConfigDepartmentCode
		{
			get
			{
				return this.ConfigDepartmentCode;
			}
		}

		public string MyConfigTableId
		{
			get
			{
				return this.ConfigTableId;
			}
		}

		public string MyCoreDescription
		{
			get
			{
				return this.CoreDescription;
			}
		}

		public string MyCoreNo
		{
			get
			{
				return this.coreno;
			}
		}

		public string MyCustomerDescription
		{
			get
			{
				return this.CustomerDescription;
			}
		}

		public string MyCustomerName
		{
			get
			{
				return this.CustomerName;
			}
		}

		public string MyCustomerNo
		{
			get
			{
				return this.CustomerNo;
			}
		}

		public string MyDepartmentCode
		{
			get
			{
				return this.tableid;
			}
		}

		public string MyDescription
		{
			get
			{
				return this.Description;
			}
		}

		public string MyDoing
		{
			get
			{
				return Conversions.ToString(this.Doing);
			}
		}

		public string MyDone
		{
			get
			{
				return Conversions.ToString(this.Done);
			}
		}

		public string MyEndDate
		{
			get
			{
				return this.EndDate;
			}
		}

		public string MyJobNo
		{
			get
			{
				return this.jobno;
			}
		}

		public string MyJobStatus
		{
			get
			{
				return this.jobstatus;
			}
		}

		public string MyNonConformityDoing
		{
			get
			{
				return this.NonConformityDoing;
			}
		}

		public string MyNoOfOperator
		{
			get
			{
				return this.NoOfOperator;
			}
		}

		public string MyStartDate
		{
			get
			{
				return this.StartDate;
			}
		}

		public string MyTableId
		{
			get
			{
				return this.tableid;
			}
		}

		public string MyThicknessmm
		{
			get
			{
				return Conversions.ToString(this.ThicknessInmm);
			}
		}

		public string MyTimeValue
		{
			get
			{
				return Conversions.ToString(this.myTime);
			}
		}

		public string MyToDo
		{
			get
			{
				return Conversions.ToString(this.ToDo);
			}
		}

		public string MyWeight
		{
			get
			{
				return this.NetWeight;
			}
		}

		public string MyWeightForUnitKg
		{
			get
			{
				return Conversions.ToString(this.WeightForUnitKg);
			}
		}

		internal virtual NumericUpDown NoOfOperatorValue
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NoOfOperatorValue;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.NoOfOperatorValue_ValueChanged);
				if (this._NoOfOperatorValue != null)
				{
					this._NoOfOperatorValue.remove_ValueChanged(eventHandler);
				}
				this._NoOfOperatorValue = value;
				if (this._NoOfOperatorValue != null)
				{
					this._NoOfOperatorValue.add_ValueChanged(eventHandler);
				}
			}
		}

		internal virtual NumericUpDown NumericNoOfOperator
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NumericNoOfOperator;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._NumericNoOfOperator = value;
			}
		}

		internal virtual PictureBox pcClose
		{
			[DebuggerNonUserCode]
			get
			{
				return this._pcClose;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.pcClose_Click);
				if (this._pcClose != null)
				{
					this._pcClose.remove_Click(eventHandler);
				}
				this._pcClose = value;
				if (this._pcClose != null)
				{
					this._pcClose.add_Click(eventHandler);
				}
			}
		}

		internal virtual PictureBox pcLegnano
		{
			[DebuggerNonUserCode]
			get
			{
				return this._pcLegnano;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.pcLegnano_Click);
				if (this._pcLegnano != null)
				{
					this._pcLegnano.remove_Click(eventHandler);
				}
				this._pcLegnano = value;
				if (this._pcLegnano != null)
				{
					this._pcLegnano.add_Click(eventHandler);
				}
			}
		}

		internal virtual PictureBox pcSettings
		{
			[DebuggerNonUserCode]
			get
			{
				return this._pcSettings;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.pcSettings_Click);
				if (this._pcSettings != null)
				{
					this._pcSettings.remove_Click(eventHandler);
				}
				this._pcSettings = value;
				if (this._pcSettings != null)
				{
					this._pcSettings.add_Click(eventHandler);
				}
			}
		}

		internal virtual Panel pnlMenu
		{
			[DebuggerNonUserCode]
			get
			{
				return this._pnlMenu;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._pnlMenu = value;
			}
		}

		internal virtual Button StartJob
		{
			[DebuggerNonUserCode]
			get
			{
				return this._StartJob;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.StartJob_Click);
				if (this._StartJob != null)
				{
					this._StartJob.remove_Click(eventHandler);
				}
				this._StartJob = value;
				if (this._StartJob != null)
				{
					this._StartJob.add_Click(eventHandler);
				}
			}
		}

		internal virtual TextBox statusActivity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._statusActivity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._statusActivity = value;
			}
		}

		internal virtual TextBox statusBadgeId
		{
			[DebuggerNonUserCode]
			get
			{
				return this._statusBadgeId;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.statusBadgeId_LostFocus);
				SmartApp smartApp1 = this;
				EventHandler eventHandler1 = new EventHandler(smartApp1, smartApp1.statusBadgeId_GotFocus);
				if (this._statusBadgeId != null)
				{
					this._statusBadgeId.remove_LostFocus(eventHandler);
					this._statusBadgeId.remove_GotFocus(eventHandler1);
				}
				this._statusBadgeId = value;
				if (this._statusBadgeId != null)
				{
					this._statusBadgeId.add_LostFocus(eventHandler);
					this._statusBadgeId.add_GotFocus(eventHandler1);
				}
			}
		}

		internal virtual TextBox statusCoreNo
		{
			[DebuggerNonUserCode]
			get
			{
				return this._statusCoreNo;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._statusCoreNo = value;
			}
		}

		internal virtual TextBox statusJobNo
		{
			[DebuggerNonUserCode]
			get
			{
				return this._statusJobNo;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._statusJobNo = value;
			}
		}

		internal virtual TextBox StatusName
		{
			[DebuggerNonUserCode]
			get
			{
				return this._StatusName;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._StatusName = value;
			}
		}

		internal virtual TextBox statusTime
		{
			[DebuggerNonUserCode]
			get
			{
				return this._statusTime;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._statusTime = value;
			}
		}

		internal virtual TabControl tbActivities
		{
			[DebuggerNonUserCode]
			get
			{
				return this._tbActivities;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._tbActivities = value;
			}
		}

		internal virtual TabPage tbScanBarcodes
		{
			[DebuggerNonUserCode]
			get
			{
				return this._tbScanBarcodes;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._tbScanBarcodes = value;
			}
		}

		internal virtual TabPage tbSelectActivity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._tbSelectActivity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._tbSelectActivity = value;
			}
		}

		internal virtual TabPage tbSelectTasks
		{
			[DebuggerNonUserCode]
			get
			{
				return this._tbSelectTasks;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._tbSelectTasks = value;
			}
		}

		internal virtual TabPage tbTableConfig
		{
			[DebuggerNonUserCode]
			get
			{
				return this._tbTableConfig;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._tbTableConfig = value;
			}
		}

		internal virtual Timer Timer1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Timer1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.Timer1_Tick);
				if (this._Timer1 != null)
				{
					this._Timer1.remove_Tick(eventHandler);
				}
				this._Timer1 = value;
				if (this._Timer1 != null)
				{
					this._Timer1.add_Tick(eventHandler);
				}
			}
		}

		internal virtual Timer Timer2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Timer2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.Timer2_Tick);
				if (this._Timer2 != null)
				{
					this._Timer2.remove_Tick(eventHandler);
				}
				this._Timer2 = value;
				if (this._Timer2 != null)
				{
					this._Timer2.add_Tick(eventHandler);
				}
			}
		}

		internal virtual TextBox txtActivityName
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtActivityName;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._txtActivityName = value;
			}
		}

		internal virtual TextBox txtBadgeId
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtBadgeId;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.txtBadgeId_TextChanged);
				SmartApp smartApp1 = this;
				KeyEventHandler keyEventHandler = new KeyEventHandler(smartApp1, smartApp1.txtBadgeId_KeyDown);
				SmartApp smartApp2 = this;
				EventHandler eventHandler1 = new EventHandler(smartApp2, smartApp2.txtBadgeId_LostFocus);
				SmartApp smartApp3 = this;
				EventHandler eventHandler2 = new EventHandler(smartApp3, smartApp3.txtBadgeId_GotFocus);
				if (this._txtBadgeId != null)
				{
					this._txtBadgeId.remove_TextChanged(eventHandler);
					this._txtBadgeId.remove_KeyDown(keyEventHandler);
					this._txtBadgeId.remove_LostFocus(eventHandler1);
					this._txtBadgeId.remove_GotFocus(eventHandler2);
				}
				this._txtBadgeId = value;
				if (this._txtBadgeId != null)
				{
					this._txtBadgeId.add_TextChanged(eventHandler);
					this._txtBadgeId.add_KeyDown(keyEventHandler);
					this._txtBadgeId.add_LostFocus(eventHandler1);
					this._txtBadgeId.add_GotFocus(eventHandler2);
				}
			}
		}

		internal virtual TextBox txtConfigDepartmentCode
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtConfigDepartmentCode;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.txtConfigDepartmentCode_LostFocus);
				SmartApp smartApp1 = this;
				EventHandler eventHandler1 = new EventHandler(smartApp1, smartApp1.txtConfigDepartmentCode_GotFocus);
				if (this._txtConfigDepartmentCode != null)
				{
					this._txtConfigDepartmentCode.remove_LostFocus(eventHandler);
					this._txtConfigDepartmentCode.remove_GotFocus(eventHandler1);
				}
				this._txtConfigDepartmentCode = value;
				if (this._txtConfigDepartmentCode != null)
				{
					this._txtConfigDepartmentCode.add_LostFocus(eventHandler);
					this._txtConfigDepartmentCode.add_GotFocus(eventHandler1);
				}
			}
		}

		internal virtual TextBox txtConfigTableId
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtConfigTableId;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				EventHandler eventHandler = new EventHandler(smartApp, smartApp.txtConfigTableId_LostFocus);
				SmartApp smartApp1 = this;
				EventHandler eventHandler1 = new EventHandler(smartApp1, smartApp1.txtConfigTableId_GotFocus);
				if (this._txtConfigTableId != null)
				{
					this._txtConfigTableId.remove_LostFocus(eventHandler);
					this._txtConfigTableId.remove_GotFocus(eventHandler1);
				}
				this._txtConfigTableId = value;
				if (this._txtConfigTableId != null)
				{
					this._txtConfigTableId.add_LostFocus(eventHandler);
					this._txtConfigTableId.add_GotFocus(eventHandler1);
				}
			}
		}

		internal virtual TextBox txtCoreNo
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtCoreNo;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				KeyEventHandler keyEventHandler = new KeyEventHandler(smartApp, smartApp.txtCoreNo_KeyDown);
				SmartApp smartApp1 = this;
				EventHandler eventHandler = new EventHandler(smartApp1, smartApp1.txtCoreNo_LostFocus);
				SmartApp smartApp2 = this;
				EventHandler eventHandler1 = new EventHandler(smartApp2, smartApp2.txtCoreNo_GotFocus);
				if (this._txtCoreNo != null)
				{
					this._txtCoreNo.remove_KeyDown(keyEventHandler);
					this._txtCoreNo.remove_LostFocus(eventHandler);
					this._txtCoreNo.remove_GotFocus(eventHandler1);
				}
				this._txtCoreNo = value;
				if (this._txtCoreNo != null)
				{
					this._txtCoreNo.add_KeyDown(keyEventHandler);
					this._txtCoreNo.add_LostFocus(eventHandler);
					this._txtCoreNo.add_GotFocus(eventHandler1);
				}
			}
		}

		internal virtual TextBox txtJobNo
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtJobNo;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				SmartApp smartApp = this;
				KeyEventHandler keyEventHandler = new KeyEventHandler(smartApp, smartApp.txtJobNo_KeyDown);
				SmartApp smartApp1 = this;
				EventHandler eventHandler = new EventHandler(smartApp1, smartApp1.txtJobNo_LostFocus);
				SmartApp smartApp2 = this;
				EventHandler eventHandler1 = new EventHandler(smartApp2, smartApp2.txtJobNo_GotFocus);
				if (this._txtJobNo != null)
				{
					this._txtJobNo.remove_KeyDown(keyEventHandler);
					this._txtJobNo.remove_LostFocus(eventHandler);
					this._txtJobNo.remove_GotFocus(eventHandler1);
				}
				this._txtJobNo = value;
				if (this._txtJobNo != null)
				{
					this._txtJobNo.add_KeyDown(keyEventHandler);
					this._txtJobNo.add_LostFocus(eventHandler);
					this._txtJobNo.add_GotFocus(eventHandler1);
				}
			}
		}

		public SmartApp()
		{
			SmartApp smartApp = this;
			base.add_Load(new EventHandler(smartApp, smartApp.SmartApp_Load));
			SmartApp smartApp1 = this;
			base.add_Closing(new CancelEventHandler(smartApp1, smartApp1.SmartApp_Closing));
			this.strBarcode = string.Empty;
			this.stopwatch = new System.Diagnostics.Stopwatch();
			this.myconnection = false;
			this.NoOfOperator = string.Empty;
			this.activity = string.Empty;
			this.badgeid = string.Empty;
			this.CustomerNo = string.Empty;
			this.CustomerName = string.Empty;
			this.Description = string.Empty;
			this.NetWeight = string.Empty;
			this.NonConformityDoing = string.Empty;
			this.jobno = string.Empty;
			this.coreno = string.Empty;
			this.tableid = string.Empty;
			this.status = string.Empty;
			this.BadgeStart = string.Empty;
			this.StartDate = string.Empty;
			this.BadgeEnd = string.Empty;
			this.EndDate = string.Empty;
			this.ConfigDepartmentCode = string.Empty;
			this.CoreDescription = string.Empty;
			this.WeightForUnitKg = new decimal();
			this.CustomerDescription = string.Empty;
			this.ThicknessInmm = new decimal();
			this.StackInmm = new decimal();
			this.Column1MeasureInmm = new decimal();
			this.CentralMeasureInmm = new decimal();
			this.Column2MeasureInmm = new decimal();
			this.ConfigTableId = string.Empty;
			this.IsClicked = false;
			this.ToDo = 0;
			this.Doing = 0;
			this.Done = 0;
			this.MyEventHandler = null;
			this.NoOfOperatorValueIsFocused = false;
			this.myScanSampleAPI = null;
			this.myReadNotifyHandler = null;
			this.myStatusNotifyHandler = null;
			this.myFormActivatedEventHandler = null;
			this.myFormDeactivatedEventHandler = null;
			this.isReaderInitiated = false;
			this.prevState = States.ERROR;
			this.InitializeComponent();
		}

		private void btn1Activity_Click(object sender, EventArgs e)
		{
			try
			{
				if (!this.ValidateBusyTable())
				{
					MessageBox.Show("The table is busy", string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				}
				else
				{
					this.activity = "SETUP";
					this.txtActivityName.set_Text(this.activity);
					this.ClearScanData();
					this.txtBadgeId.Focus();
					this.tbActivities.set_SelectedIndex(2);
					this.pcSettings.set_Enabled(false);
					this.pcSettings.set_Visible(false);
					this.CheckConnectionSettings();
				}
			}
			catch (Exception exception1)
			{
				ProjectData.SetProjectError(exception1);
				Exception exception = exception1;
				MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
			}
		}

		private void btn2Activity_Click(object sender, EventArgs e)
		{
			try
			{
				this.activity = "ASSEMBLY";
				this.txtActivityName.set_Text(this.activity);
				this.ClearScanData();
				this.txtBadgeId.Focus();
				this.tbActivities.set_SelectedIndex(2);
				this.pcSettings.set_Enabled(false);
				this.pcSettings.set_Visible(false);
				this.CheckConnectionSettings();
			}
			catch (Exception exception1)
			{
				ProjectData.SetProjectError(exception1);
				Exception exception = exception1;
				MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
			}
		}

		private void btn3Activity_Click(object sender, EventArgs e)
		{
			try
			{
				this.activity = "CLOSING";
				this.txtActivityName.set_Text(this.activity);
				this.ClearScanData();
				this.txtBadgeId.Focus();
				this.tbActivities.set_SelectedIndex(2);
				this.pcSettings.set_Enabled(false);
				this.pcSettings.set_Visible(false);
				this.CheckConnectionSettings();
			}
			catch (Exception exception1)
			{
				ProjectData.SetProjectError(exception1);
				Exception exception = exception1;
				MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
			}
		}

		private void btn4Activity_Click(object sender, EventArgs e)
		{
			try
			{
				if (!this.ValidateBusyTable())
				{
					MessageBox.Show("The table is busy", string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				}
				else
				{
					this.activity = "NON CONFORMITY";
					this.txtActivityName.set_Text(this.activity);
					this.ClearScanData();
					this.txtBadgeId.Focus();
					this.tbActivities.set_SelectedIndex(2);
					this.pcSettings.set_Enabled(false);
					this.pcSettings.set_Visible(false);
					this.CheckConnectionSettings();
				}
			}
			catch (Exception exception1)
			{
				ProjectData.SetProjectError(exception1);
				Exception exception = exception1;
				MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
			}
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			decimal value = this.NoOfOperatorValue.get_Value();
			if (Convert.ToDouble(value) == Conversions.ToDouble("100"))
			{
				this.msgIcon.set_Visible(Conversions.ToBoolean("True"));
				this.lblMessage.set_Text("You have reached maximum operator limit");
				this.lblMessage.set_Visible(Conversions.ToBoolean("True"));
			}
			else if (Convert.ToDouble(value) != Conversions.ToDouble("2"))
			{
				this.NoOfOperatorValue.set_Value(decimal.Add(this.NoOfOperatorValue.get_Value(), decimal.One));
			}
			else
			{
				this.msgIcon.set_Visible(Conversions.ToBoolean("False"));
				this.lblMessage.set_Visible(Conversions.ToBoolean("False"));
				this.NoOfOperatorValue.set_Value(decimal.Add(this.NoOfOperatorValue.get_Value(), decimal.One));
			}
		}

		private void btnBack_Click(object sender, EventArgs e)
		{
			this.ClearScanData();
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
			this.tbActivities.set_SelectedIndex(1);
		}

		private void btnCancelConfig_Click(object sender, EventArgs e)
		{
			this.txtConfigTableId.set_Text("");
			this.txtConfigDepartmentCode.set_Text("");
			this.MsgIconConfig.set_Visible(false);
			this.msgConfig.set_Visible(false);
			this.msgConfig.set_Text("");
			this.CheckConnectionSettings();
			this.tbActivities.set_SelectedIndex(1);
		}

		private void btnClr1_Click(object sender, EventArgs e)
		{
			this.txtConfigTableId.set_Text("");
			this.txtConfigTableId.Focus();
		}

		private void btnClr2_Click(object sender, EventArgs e)
		{
			this.txtConfigDepartmentCode.set_Text("");
			this.txtConfigDepartmentCode.Focus();
		}

		private void btnEndJob_Click(object sender, EventArgs e)
		{
			if (Operators.CompareString(this.statusBadgeId.get_Text(), "", false) != 0)
			{
				this.BadgeEnd = this.statusBadgeId.get_Text();
				this.EndDate = this.lblTime.get_Text();
				this.Timer2.set_Enabled(false);
				this.stopwatch.Reset();
				this.CheckConnectionSettings();
				this.jobstatus = "END";
				this.StatusName.set_Text(this.jobstatus);
				if (Operators.CompareString(this.Myactivity, "NON CONFORMITY", false) != 0)
				{
					this.UpdateInNetwork();
				}
				else
				{
					this.UpdateInNetworkForNonConformity();
				}
				this.MonitoringAndCounterCalculation();
				this.StartJob.set_Enabled(false);
				this.pcSettings.set_Enabled(true);
				this.pcSettings.set_Visible(true);
				this.tbActivities.set_SelectedIndex(1);
				this.statusTime.set_Text("00:00:00");
				if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "END", false) == 0)
				{
					this.txtJobNo.set_Text("");
					this.txtJobNo.set_Enabled(true);
					this.txtCoreNo.set_Text("");
					this.txtCoreNo.set_Enabled(true);
				}
				if (Operators.CompareString(this.Myactivity, "NON CONFORMITY", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "END", false) == 0)
				{
					this.txtJobNo.set_Text("");
					this.txtJobNo.set_Enabled(true);
					this.txtCoreNo.set_Text("");
					this.txtCoreNo.set_Enabled(true);
				}
			}
			else
			{
				MessageBox.Show("Scan the Badge Id", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
				this.statusBadgeId.Focus();
			}
		}

		private void btnMinus_Click(object sender, EventArgs e)
		{
			decimal value = this.NumericNoOfOperator.get_Value();
			if (Convert.ToDouble(value) == Conversions.ToDouble("1"))
			{
				this.NumericNoOfOperator.set_Value(decimal.One);
			}
			else if (Convert.ToDouble(value) != Conversions.ToDouble("99"))
			{
				this.NumericNoOfOperator.set_Value(decimal.Subtract(this.NumericNoOfOperator.get_Value(), decimal.One));
			}
			else
			{
				this.NumericNoOfOperator.set_Value(decimal.Subtract(this.NumericNoOfOperator.get_Value(), decimal.One));
			}
		}

		private void btnPauseJob_Click(object sender, EventArgs e)
		{
			this.CheckConnectionSettings();
			this.jobstatus = "PAUSE";
			this.Timer2.set_Enabled(Conversions.ToBoolean("False"));
			this.stopwatch.Stop();
			this.StatusName.set_Text(this.jobstatus);
			this.StartJob.set_Enabled(false);
			this.btnPauseJob.set_Enabled(false);
			this.btnResume.set_Enabled(true);
			this.btnResume.Focus();
			this.btnEndJob.set_Enabled(false);
			this.tbActivities.set_SelectedIndex(0);
		}

		private void btnPlus_Click(object sender, EventArgs e)
		{
			decimal value = this.NumericNoOfOperator.get_Value();
			if (Convert.ToDouble(value) == Conversions.ToDouble("100"))
			{
				this.NumericNoOfOperator.set_Value(new decimal((long)100));
			}
			else if (Convert.ToDouble(value) != Conversions.ToDouble("2"))
			{
				this.NumericNoOfOperator.set_Value(decimal.Add(this.NumericNoOfOperator.get_Value(), decimal.One));
			}
			else
			{
				this.NumericNoOfOperator.set_Value(decimal.Add(this.NumericNoOfOperator.get_Value(), decimal.One));
			}
		}

		private void btnResume_Click(object sender, EventArgs e)
		{
			this.CheckConnectionSettings();
			this.Timer2.set_Enabled(Conversions.ToBoolean("True"));
			this.stopwatch.Start();
			this.jobstatus = "RESUME";
			this.StatusName.set_Text(this.jobstatus);
			this.btnPauseJob.set_Enabled(true);
			this.btnPauseJob.Focus();
			this.btnEndJob.set_Enabled(true);
			this.StartJob.set_Enabled(false);
			this.btnResume.set_Enabled(false);
			this.tbActivities.set_SelectedIndex(0);
		}

		private void btnSaveConfig_Click(object sender, EventArgs e)
		{
			try
			{
				if (Operators.CompareString(this.txtConfigTableId.get_Text(), "", false) == 0)
				{
					this.msgConfig.set_Visible(true);
					this.MsgIconConfig.set_Visible(true);
					this.msgConfig.set_Text("Error ! Please provide Table Id");
					this.txtConfigTableId.Focus();
				}
				else if (Operators.CompareString(this.txtConfigDepartmentCode.get_Text(), "", false) == 0)
				{
					this.msgConfig.set_Visible(true);
					this.MsgIconConfig.set_Visible(true);
					this.msgConfig.set_Text("Error ! Please provide Department Code");
					this.txtConfigDepartmentCode.Focus();
				}
				else if (Operators.CompareString(this.txtConfigTableId.get_Text(), "", false) != 0 & Operators.CompareString(this.txtConfigDepartmentCode.get_Text(), "", false) != 0)
				{
					this.writeConfigValuesinXml();
					this.CheckConnectionSettings();
					this.readSettingsFromXML();
				}
			}
			catch (Exception exception)
			{
				ProjectData.SetProjectError(exception);
				throw exception;
			}
		}

		private void btnSubtract_Click(object sender, EventArgs e)
		{
			decimal value = this.NoOfOperatorValue.get_Value();
			if (Convert.ToDouble(value) == Conversions.ToDouble("1"))
			{
				this.msgIcon.set_Visible(Conversions.ToBoolean("True"));
				this.lblMessage.set_Text("You have reached minimum operator limit");
				this.lblMessage.set_Visible(Conversions.ToBoolean("True"));
			}
			else if (Convert.ToDouble(value) != Conversions.ToDouble("99"))
			{
				this.NoOfOperatorValue.set_Value(decimal.Subtract(this.NoOfOperatorValue.get_Value(), decimal.One));
			}
			else
			{
				this.msgIcon.set_Visible(Conversions.ToBoolean("False"));
				this.lblMessage.set_Visible(Conversions.ToBoolean("False"));
				this.NoOfOperatorValue.set_Value(decimal.Subtract(this.NoOfOperatorValue.get_Value(), decimal.One));
			}
		}

		private void buttonBack_Click(object sender, EventArgs e)
		{
			this.tbActivities.set_SelectedIndex(1);
			this.ClearScanData();
			if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0)
			{
				this.txtJobNo.set_Text("");
				this.txtJobNo.set_Enabled(true);
			}
			if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0)
			{
				this.txtCoreNo.set_Text("");
				this.txtCoreNo.set_Enabled(true);
			}
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
			this.pcSettings.set_Enabled(true);
			this.pcSettings.set_Visible(true);
		}

		private void buttonContinue_Click(object sender, EventArgs e)
		{
			if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) == 0)
			{
				this.txtBadgeId.Focus();
				this.msgIcon.set_Visible(true);
				this.lblMessage.set_Text("Provide Badge Id");
				this.lblMessage.set_Visible(true);
			}
			else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) == 0)
			{
				this.txtJobNo.Focus();
				this.msgIcon.set_Visible(true);
				this.lblMessage.set_Text("Provide Job No.");
				this.lblMessage.set_Visible(true);
			}
			else if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) == 0)
			{
				this.txtCoreNo.Focus();
				this.msgIcon.set_Visible(true);
				this.lblMessage.set_Text("Provide Core No.");
				this.lblMessage.set_Visible(true);
				this.NoOfOperator = this.MyNoOfOperator;
			}
			else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0)
			{
				this.NumericNoOfOperator.set_Value(this.NoOfOperatorValue.get_Value());
				this.NoOfOperator = Conversions.ToString(this.NumericNoOfOperator.get_Value());
				if (this.Validate())
				{
					this.ValidateSteps();
					this.pcSettings.set_Enabled(false);
					this.pcSettings.set_Visible(false);
					this.tbActivities.set_SelectedIndex(0);
					this.CheckConnectionSettings();
					this.GetDetailsForStatus();
					this.StartJob.Focus();
					if (this.lblMessage.get_Visible())
					{
						this.msgIcon.set_Visible(false);
						this.lblMessage.set_Visible(false);
					}
				}
			}
		}

		private void CheckConnectionSettings()
		{
			this.readConfigValues();
			try
			{
				string str = GlobalVariables.strNetworkAddress;
				string str1 = GlobalVariables.strNetworkUsername;
				string str2 = GlobalVariables.strNetworkPassword;
				string str3 = GlobalVariables.strNetworkDB;
				if (!(SmartApp.createWebService().TestFirstDBConnection() & SmartApp.createWebService().TestSecondDBConnection()))
				{
					DateTime now = DateTime.get_Now();
					this.myTime = Conversions.ToDate(now.ToString("dd/MM/yyyy HH:mm:ss"));
					this.myconnection = false;
				}
				else
				{
					this.SyncServerTime();
					this.myconnection = true;
				}
			}
			catch (Exception exception1)
			{
				ProjectData.SetProjectError(exception1);
				Exception exception = exception1;
				MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
			}
		}

		public void CheckToDo()
		{
			string text = this.statusJobNo.get_Text();
			char[] chrArray = new char[] { '/' };
			string[] strArray = text.Split(chrArray);
			string str = this.statusCoreNo.get_Text();
			chrArray = new char[] { '/' };
			string[] strArray1 = str.Split(chrArray);
			this.lblTableId.get_Text();
			string str1 = strArray[0];
			string str2 = strArray[1];
			string str3 = strArray1[0];
			string str4 = strArray1[1];
			string myactivity = this.Myactivity;
			this.StatusName.get_Text().Trim();
			try
			{
				short num = Convert.ToInt16(SmartApp.createWebService().ToDoquery(str1, str2, str4));
				this.ToDo = num;
			}
			catch (Exception exception)
			{
				ProjectData.SetProjectError(exception);
				throw new Exception("Check connection with machine");
			}
			try
			{
				short num1 = Convert.ToInt16(SmartApp.createWebService().Donequery(str1, str2, str4));
				this.Done = num1;
				if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "END", false) == 0)
				{
					this.Done = checked(this.Done + 1);
				}
			}
			catch (Exception exception1)
			{
				ProjectData.SetProjectError(exception1);
				throw new Exception("Check connection with machine");
			}
			try
			{
				short num2 = Convert.ToInt16(SmartApp.createWebService().DoingQuery(str1, str2, str4));
				this.Doing = num2;
				if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "END", false) == 0)
				{
					this.Doing = checked(this.Doing - 1);
				}
			}
			catch (SqlException sqlException)
			{
				ProjectData.SetProjectError((Exception)sqlException);
				throw new Exception("Check connection with machine");
			}
			if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "END", false) == 0)
			{
				this.ToDo = checked((int)Math.Round(Conversions.ToDouble(str4) - (double)(checked(this.Doing + this.Done))));
				SmartApp.createWebService().UpdateScrumTableOnEndClosing(str1, str2, str4, this.ToDo, this.Doing, this.Done);
			}
			else if (!(Operators.CompareString(this.Myactivity, "NON CONFORMITY", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "START", false) == 0))
			{
				this.ToDo = checked((int)Math.Round(Conversions.ToDouble(str4) - (double)(checked(this.Doing + this.Done))));
				SmartApp.createWebService().UpdateScrumTable(str1, str2, str4, this.ToDo, this.Doing, this.Done);
			}
			else if (this.Doing >= 1)
			{
				this.Doing = checked(this.Doing - 1);
				this.ToDo = checked(this.ToDo + 1);
				SmartApp.createWebService().UpdateScrumTableOnStartConformity(str1, str2, this.ToDo, this.Doing, str4);
			}
		}

		public void ClearScanData()
		{
			this.txtBadgeId.set_Text("");
			this.txtBadgeId.set_Enabled(true);
			this.NoOfOperatorValue.set_Value(Conversions.ToDecimal("1"));
			this.msgIcon.set_Visible(false);
			this.lblMessage.set_Visible(false);
			this.lblMessage.set_Text("");
		}

		private static Service1 createWebService()
		{
			Service1 service1 = new Service1();
			string webServiceURL = GlobalVariables.WebServiceURL;
			if (!string.IsNullOrEmpty(webServiceURL))
			{
				service1.Url = webServiceURL;
			}
			return service1;
		}

		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		public void GetDetailsForStatus()
		{
			this.statusActivity.set_Text(this.Myactivity);
			this.statusBadgeId.set_Text(this.MyBadgeId);
			this.statusBadgeId.set_Enabled(false);
			this.statusJobNo.set_Text(this.MyJobNo);
			this.statusCoreNo.set_Text(this.MyCoreNo);
			this.StatusName.set_Text("");
			this.statusTime.set_Text("");
			this.StartJob.set_Enabled(true);
			this.btnPauseJob.set_Enabled(false);
			this.btnEndJob.set_Enabled(false);
			this.btnResume.set_Enabled(false);
		}

		private void HandleContinuousData(ReaderData TheReaderData)
		{
			int length;
			if (this.txtBadgeId.get_Focused())
			{
				this.txtBadgeId.set_Text(TheReaderData.Text.Replace("/O", "/"));
				length = this.txtBadgeId.get_Text().get_Length();
				string str = length.ToString();
				if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
				}
				else if (this.txtBadgeId.get_Text().Contains("/"))
				{
					MessageBox.Show("Check Scanned Badge Id", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
					this.txtBadgeId.set_Text("");
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtJobNo.get_Text(), this.txtBadgeId.get_Text(), false) == 0)
				{
					this.txtBadgeId.set_Text("");
					this.lblMessage.set_Text("Job No. already scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), this.txtBadgeId.get_Text(), false) == 0)
				{
					this.txtBadgeId.set_Text("");
					this.lblMessage.set_Text("Core No. already scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (!(Conversions.ToDouble(str) > 9 | Conversions.ToDouble(str) < 8))
				{
					this.badgeid = this.txtBadgeId.get_Text();
					this.txtBadgeId.set_Enabled(false);
					if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) == 0)
					{
						this.txtJobNo.Focus();
					}
					else if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) == 0)
					{
						this.txtCoreNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0)
					{
						this.tbActivities.set_SelectedIndex(2);
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.get_Visible())
					{
						this.msgIcon.set_Visible(false);
						this.lblMessage.set_Visible(false);
					}
				}
				else
				{
					this.txtBadgeId.set_Text("");
					MessageBox.Show("Check Scanned Badge Id", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
			}
			else if (this.txtJobNo.get_Focused())
			{
				this.txtJobNo.set_Text(TheReaderData.Text.Replace("/O", "/"));
				length = this.txtJobNo.get_Text().get_Length();
				string str1 = length.ToString();
				if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
				}
				else if (this.txtJobNo.get_Text().Contains("-"))
				{
					MessageBox.Show("Check Scanned Job Number", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
					this.txtJobNo.set_Text("");
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), this.txtJobNo.get_Text(), false) == 0)
				{
					this.txtJobNo.set_Text("");
					this.lblMessage.set_Text("Operator Id has been scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), this.txtJobNo.get_Text(), false) == 0)
				{
					this.txtJobNo.set_Text("");
					this.lblMessage.set_Text("Core No. has been scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (!(Conversions.ToDouble(str1) > 11 | Conversions.ToDouble(str1) < 9))
				{
					this.jobno = this.txtJobNo.get_Text();
					this.txtJobNo.set_Enabled(false);
					if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) == 0)
					{
						this.txtBadgeId.Focus();
					}
					else if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) == 0)
					{
						this.txtCoreNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0)
					{
						this.tbActivities.set_SelectedIndex(2);
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.get_Visible())
					{
						this.msgIcon.set_Visible(false);
						this.lblMessage.set_Visible(false);
					}
				}
				else
				{
					this.txtJobNo.set_Text("");
					MessageBox.Show("Check Scanned Job No", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
			}
			else if (this.txtCoreNo.get_Focused())
			{
				string str2 = TheReaderData.Text.Replace("/O", "/");
				this.txtCoreNo.set_Text(str2.Replace(" ", ""));
				length = this.txtCoreNo.get_Text().get_Length();
				string str3 = length.ToString();
				if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (this.txtCoreNo.get_Text().Contains("-"))
				{
					MessageBox.Show("Check Scanned Core Number", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
					this.txtCoreNo.set_Text("");
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtJobNo.get_Text(), this.txtCoreNo.get_Text(), false) == 0)
				{
					this.txtCoreNo.set_Text("");
					this.lblMessage.set_Text("Job No. already scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), this.txtCoreNo.get_Text(), false) == 0)
				{
					this.txtCoreNo.set_Text("");
					this.lblMessage.set_Text("Operator Badge Id already scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (!(Conversions.ToDouble(str3) > 7 | Conversions.ToDouble(str3) < 3))
				{
					this.coreno = this.txtCoreNo.get_Text();
					this.txtCoreNo.set_Enabled(false);
					if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) == 0)
					{
						this.txtBadgeId.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) == 0)
					{
						this.txtJobNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0)
					{
						this.tbActivities.set_SelectedIndex(2);
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.get_Visible())
					{
						this.msgIcon.set_Visible(false);
						this.lblMessage.set_Visible(false);
					}
				}
				else
				{
					this.txtCoreNo.set_Text("");
					MessageBox.Show("Check Scanned Core No", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
			}
			else if (this.statusBadgeId.get_Focused() == Conversions.ToBoolean("True"))
			{
				this.statusBadgeId.set_Text(TheReaderData.Text.Replace("/O", "/"));
				length = this.statusBadgeId.get_Text().get_Length();
				string str4 = length.ToString();
				if (Operators.CompareString(this.statusBadgeId.get_Text(), "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
				}
				else if (!(Conversions.ToDouble(str4) > 9 | Conversions.ToDouble(str4) < 8))
				{
					this.badgeid = this.statusBadgeId.get_Text();
					this.statusBadgeId.set_Enabled(Conversions.ToBoolean("False"));
					if (this.lblMessage.get_Visible())
					{
						this.msgIcon.set_Visible(false);
						this.lblMessage.set_Visible(false);
					}
				}
				else
				{
					this.statusBadgeId.set_Text("");
					MessageBox.Show("Check Scanned Badge Id", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
			}
			else if (this.txtConfigTableId.get_Focused() == Conversions.ToBoolean("True"))
			{
				this.txtConfigTableId.set_Text(TheReaderData.Text.Replace("/O", "/"));
				length = this.txtConfigTableId.get_Text().get_Length();
				length.ToString();
				if (Operators.CompareString(this.txtConfigTableId.get_Text(), "", false) != 0)
				{
					this.ConfigTableId = this.txtConfigTableId.get_Text();
					this.txtConfigTableId.set_Enabled(Conversions.ToBoolean("False"));
				}
				else
				{
					MessageBox.Show("Scan Barcode to Continue", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
					this.txtConfigTableId.set_Text("");
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
			}
			else if (this.txtConfigDepartmentCode.get_Focused() == Conversions.ToBoolean("True"))
			{
				this.txtConfigDepartmentCode.set_Text(TheReaderData.Text.Replace("/O", "/"));
				length = this.txtConfigDepartmentCode.get_Text().get_Length();
				length.ToString();
				if (Operators.CompareString(this.txtConfigDepartmentCode.get_Text(), "", false) != 0)
				{
					this.ConfigDepartmentCode = this.txtConfigDepartmentCode.get_Text();
					this.txtConfigDepartmentCode.set_Enabled(Conversions.ToBoolean("False"));
				}
				else
				{
					MessageBox.Show("Scan Barcode to Continue", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
					this.txtConfigTableId.set_Text("");
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
			}
		}

		private void HandleData(ReaderData TheReaderData)
		{
			this.txtBadgeId.set_Text(TheReaderData.Text);
		}

		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(SmartApp));
			this.pnlMenu = new Panel();
			this.pcClose = new PictureBox();
			this.pcLegnano = new PictureBox();
			this.Label8 = new Label();
			this.lblSelectActivity = new Label();
			this.btnActivity6 = new Button();
			this.btnActivity5 = new Button();
			this.btnActivity4 = new Button();
			this.btnActivity3 = new Button();
			this.btnActivity2 = new Button();
			this.btnActivity1 = new Button();
			this.tbActivities = new TabControl();
			this.tbSelectTasks = new TabPage();
			this.btnPlus = new Button();
			this.btnMinus = new Button();
			this.StartJob = new Button();
			this.statusTime = new TextBox();
			this.Label19 = new Label();
			this.Label15 = new Label();
			this.StatusName = new TextBox();
			this.statusCoreNo = new TextBox();
			this.statusJobNo = new TextBox();
			this.statusBadgeId = new TextBox();
			this.statusActivity = new TextBox();
			this.btnResume = new Button();
			this.btnEndJob = new Button();
			this.btnPauseJob = new Button();
			this.Label18 = new Label();
			this.Label17 = new Label();
			this.Label16 = new Label();
			this.Label12 = new Label();
			this.Label20 = new Label();
			this.NumericNoOfOperator = new NumericUpDown();
			this.tbSelectActivity = new TabPage();
			this.btn4Activity = new Button();
			this.Label3 = new Label();
			this.Label4 = new Label();
			this.btn3Activity = new Button();
			this.btn2Activity = new Button();
			this.btn1Activity = new Button();
			this.tbScanBarcodes = new TabPage();
			this.btnAdd = new Button();
			this.btnSubtract = new Button();
			this.buttonContinue = new Button();
			this.buttonBack = new Button();
			this.txtBadgeId = new TextBox();
			this.txtActivityName = new TextBox();
			this.msgIcon = new PictureBox();
			this.lblMessage = new Label();
			this.txtCoreNo = new TextBox();
			this.txtJobNo = new TextBox();
			this.Label9 = new Label();
			this.lblActivity = new Label();
			this.Label10 = new Label();
			this.Label11 = new Label();
			this.lblNoOfOperator = new Label();
			this.NoOfOperatorValue = new NumericUpDown();
			this.tbTableConfig = new TabPage();
			this.btnClr2 = new Button();
			this.btnClr1 = new Button();
			this.MsgIconConfig = new PictureBox();
			this.msgConfig = new Label();
			this.btnCancelConfig = new Button();
			this.btnSaveConfig = new Button();
			this.txtConfigDepartmentCode = new TextBox();
			this.txtConfigTableId = new TextBox();
			this.Label21 = new Label();
			this.lblTable = new Label();
			this.pcSettings = new PictureBox();
			this.lblDepartmentCode = new Label();
			this.lblTableId = new Label();
			this.Label7 = new Label();
			this.Label1 = new Label();
			this.Label2 = new Label();
			this.lblTime = new Label();
			this.Timer1 = new Timer();
			this.Timer2 = new Timer();
			this.pnlMenu.SuspendLayout();
			this.tbActivities.SuspendLayout();
			this.tbSelectTasks.SuspendLayout();
			this.tbSelectActivity.SuspendLayout();
			this.tbScanBarcodes.SuspendLayout();
			this.tbTableConfig.SuspendLayout();
			this.SuspendLayout();
			this.pnlMenu.set_BackColor(Color.get_Navy());
			this.pnlMenu.get_Controls().Add(this.pcClose);
			this.pnlMenu.get_Controls().Add(this.pcLegnano);
			Panel panel = this.pnlMenu;
			Point point = new Point(0, 0);
			panel.set_Location(point);
			this.pnlMenu.set_Name("pnlMenu");
			Panel panel1 = this.pnlMenu;
			Size size = new Size(320, 26);
			panel1.set_Size(size);
			this.pcClose.set_Enabled(false);
			this.pcClose.set_Image((Image)componentResourceManager.GetObject("pcClose.Image"));
			PictureBox pictureBox = this.pcClose;
			point = new Point(292, 1);
			pictureBox.set_Location(point);
			this.pcClose.set_Name("pcClose");
			PictureBox pictureBox1 = this.pcClose;
			size = new Size(25, 22);
			pictureBox1.set_Size(size);
			this.pcClose.set_SizeMode(1);
			this.pcClose.set_Visible(false);
			this.pcLegnano.set_Image((Image)componentResourceManager.GetObject("pcLegnano.Image"));
			PictureBox pictureBox2 = this.pcLegnano;
			point = new Point(4, 1);
			pictureBox2.set_Location(point);
			this.pcLegnano.set_Name("pcLegnano");
			PictureBox pictureBox3 = this.pcLegnano;
			size = new Size(79, 22);
			pictureBox3.set_Size(size);
			this.pcLegnano.set_SizeMode(1);
			this.Label8.set_BackColor(Color.get_Black());
			Label label8 = this.Label8;
			point = new Point(1, 19);
			label8.set_Location(point);
			this.Label8.set_Name("Label8");
			Label label = this.Label8;
			size = new Size(147, 1);
			label.set_Size(size);
			this.Label8.set_Text("Label8");
			this.lblSelectActivity.set_BackColor(Color.FromArgb(192, 224, 255));
			this.lblSelectActivity.set_Font(new Font("Tahoma", 10f, 1));
			Label label1 = this.lblSelectActivity;
			point = new Point(16, 0);
			label1.set_Location(point);
			this.lblSelectActivity.set_Name("lblSelectActivity");
			Label label2 = this.lblSelectActivity;
			size = new Size(111, 20);
			label2.set_Size(size);
			this.lblSelectActivity.set_Text("Select Activity");
			Button button = this.btnActivity6;
			point = new Point(209, 106);
			button.set_Location(point);
			this.btnActivity6.set_Name("btnActivity6");
			Button button1 = this.btnActivity6;
			size = new Size(72, 50);
			button1.set_Size(size);
			this.btnActivity6.set_TabIndex(5);
			this.btnActivity6.set_Text("Activity 6");
			Button button2 = this.btnActivity5;
			point = new Point(116, 106);
			button2.set_Location(point);
			this.btnActivity5.set_Name("btnActivity5");
			Button button3 = this.btnActivity5;
			size = new Size(72, 48);
			button3.set_Size(size);
			this.btnActivity5.set_TabIndex(4);
			this.btnActivity5.set_Text("Activity 5");
			Button button4 = this.btnActivity4;
			point = new Point(25, 106);
			button4.set_Location(point);
			this.btnActivity4.set_Name("btnActivity4");
			Button button5 = this.btnActivity4;
			size = new Size(72, 49);
			button5.set_Size(size);
			this.btnActivity4.set_TabIndex(3);
			this.btnActivity4.set_Text("Activity 4");
			Button button6 = this.btnActivity3;
			point = new Point(209, 38);
			button6.set_Location(point);
			this.btnActivity3.set_Name("btnActivity3");
			Button button7 = this.btnActivity3;
			size = new Size(72, 49);
			button7.set_Size(size);
			this.btnActivity3.set_TabIndex(2);
			this.btnActivity3.set_Text("Activity 3");
			Button button8 = this.btnActivity2;
			point = new Point(116, 38);
			button8.set_Location(point);
			this.btnActivity2.set_Name("btnActivity2");
			Button button9 = this.btnActivity2;
			size = new Size(72, 49);
			button9.set_Size(size);
			this.btnActivity2.set_TabIndex(1);
			this.btnActivity2.set_Text("Activity 2");
			Button button10 = this.btnActivity1;
			point = new Point(25, 38);
			button10.set_Location(point);
			this.btnActivity1.set_Name("btnActivity1");
			Button button11 = this.btnActivity1;
			size = new Size(72, 49);
			button11.set_Size(size);
			this.btnActivity1.set_TabIndex(0);
			this.btnActivity1.set_Text("Activity 1");
			this.tbActivities.get_Controls().Add(this.tbSelectTasks);
			this.tbActivities.get_Controls().Add(this.tbSelectActivity);
			this.tbActivities.get_Controls().Add(this.tbScanBarcodes);
			this.tbActivities.get_Controls().Add(this.tbTableConfig);
			TabControl tabControl = this.tbActivities;
			point = new Point(0, 0);
			tabControl.set_Location(point);
			this.tbActivities.set_Name("tbActivities");
			this.tbActivities.set_SelectedIndex(0);
			TabControl tabControl1 = this.tbActivities;
			size = new Size(320, 208);
			tabControl1.set_Size(size);
			this.tbActivities.set_TabIndex(2);
			this.tbSelectTasks.set_BackColor(Color.FromArgb(192, 224, 255));
			this.tbSelectTasks.get_Controls().Add(this.btnPlus);
			this.tbSelectTasks.get_Controls().Add(this.btnMinus);
			this.tbSelectTasks.get_Controls().Add(this.StartJob);
			this.tbSelectTasks.get_Controls().Add(this.statusTime);
			this.tbSelectTasks.get_Controls().Add(this.Label19);
			this.tbSelectTasks.get_Controls().Add(this.Label15);
			this.tbSelectTasks.get_Controls().Add(this.StatusName);
			this.tbSelectTasks.get_Controls().Add(this.statusCoreNo);
			this.tbSelectTasks.get_Controls().Add(this.statusJobNo);
			this.tbSelectTasks.get_Controls().Add(this.statusBadgeId);
			this.tbSelectTasks.get_Controls().Add(this.statusActivity);
			this.tbSelectTasks.get_Controls().Add(this.btnResume);
			this.tbSelectTasks.get_Controls().Add(this.btnEndJob);
			this.tbSelectTasks.get_Controls().Add(this.btnPauseJob);
			this.tbSelectTasks.get_Controls().Add(this.Label18);
			this.tbSelectTasks.get_Controls().Add(this.Label17);
			this.tbSelectTasks.get_Controls().Add(this.Label16);
			this.tbSelectTasks.get_Controls().Add(this.Label12);
			this.tbSelectTasks.get_Controls().Add(this.Label20);
			this.tbSelectTasks.get_Controls().Add(this.NumericNoOfOperator);
			TabPage tabPage = this.tbSelectTasks;
			point = new Point(4, 25);
			tabPage.set_Location(point);
			this.tbSelectTasks.set_Name("tbSelectTasks");
			TabPage tabPage1 = this.tbSelectTasks;
			size = new Size(312, 179);
			tabPage1.set_Size(size);
			this.tbSelectTasks.set_Text("TabPage3");
			this.btnPlus.set_BackColor(Color.get_Khaki());
			Button button12 = this.btnPlus;
			point = new Point(263, 87);
			button12.set_Location(point);
			this.btnPlus.set_Name("btnPlus");
			Button button13 = this.btnPlus;
			size = new Size(31, 21);
			button13.set_Size(size);
			this.btnPlus.set_TabIndex(49);
			this.btnPlus.set_Text("+");
			this.btnMinus.set_BackColor(Color.get_Khaki());
			Button button14 = this.btnMinus;
			point = new Point(141, 87);
			button14.set_Location(point);
			this.btnMinus.set_Name("btnMinus");
			Button button15 = this.btnMinus;
			size = new Size(31, 21);
			button15.set_Size(size);
			this.btnMinus.set_TabIndex(48);
			this.btnMinus.set_Text("-");
			this.StartJob.set_BackColor(Color.get_LimeGreen());
			this.StartJob.set_Font(new Font("Tahoma", 10f, 1));
			this.StartJob.set_ForeColor(SystemColors.get_ActiveCaption());
			Button startJob = this.StartJob;
			point = new Point(3, 154);
			startJob.set_Location(point);
			this.StartJob.set_Name("StartJob");
			Button startJob1 = this.StartJob;
			size = new Size(72, 24);
			startJob1.set_Size(size);
			this.StartJob.set_TabIndex(40);
			this.StartJob.set_Text("START");
			this.statusTime.set_BackColor(Color.get_Khaki());
			this.statusTime.set_Enabled(false);
			this.statusTime.set_Font(new Font("Tahoma", 9f, 0));
			this.statusTime.set_ForeColor(SystemColors.get_HotTrack());
			TextBox textBox = this.statusTime;
			point = new Point(141, 130);
			textBox.set_Location(point);
			this.statusTime.set_Name("statusTime");
			TextBox textBox1 = this.statusTime;
			size = new Size(153, 21);
			textBox1.set_Size(size);
			this.statusTime.set_TabIndex(32);
			this.statusTime.set_Text("00:00:00");
			this.Label19.set_Font(new Font("Tahoma", 9f, 1));
			Label label19 = this.Label19;
			point = new Point(30, 89);
			label19.set_Location(point);
			this.Label19.set_Name("Label19");
			Label label191 = this.Label19;
			size = new Size(108, 20);
			label191.set_Size(size);
			this.Label19.set_Text("No. Of Operator");
			this.Label15.set_Font(new Font("Tahoma", 9f, 1));
			Label label15 = this.Label15;
			point = new Point(80, 5);
			label15.set_Location(point);
			this.Label15.set_Name("Label15");
			Label label151 = this.Label15;
			size = new Size(58, 20);
			label151.set_Size(size);
			this.Label15.set_Text("Activity");
			this.StatusName.set_BackColor(Color.get_Khaki());
			this.StatusName.set_Enabled(false);
			this.StatusName.set_Font(new Font("Tahoma", 8f, 0));
			TextBox statusName = this.StatusName;
			point = new Point(141, 109);
			statusName.set_Location(point);
			this.StatusName.set_Name("StatusName");
			TextBox statusName1 = this.StatusName;
			size = new Size(153, 19);
			statusName1.set_Size(size);
			this.StatusName.set_TabIndex(16);
			this.statusCoreNo.set_Enabled(false);
			this.statusCoreNo.set_Font(new Font("Tahoma", 8f, 0));
			TextBox textBox2 = this.statusCoreNo;
			point = new Point(141, 67);
			textBox2.set_Location(point);
			this.statusCoreNo.set_Name("statusCoreNo");
			TextBox textBox3 = this.statusCoreNo;
			size = new Size(153, 19);
			textBox3.set_Size(size);
			this.statusCoreNo.set_TabIndex(15);
			this.statusJobNo.set_Enabled(false);
			this.statusJobNo.set_Font(new Font("Tahoma", 8f, 0));
			TextBox textBox4 = this.statusJobNo;
			point = new Point(141, 46);
			textBox4.set_Location(point);
			this.statusJobNo.set_Name("statusJobNo");
			TextBox textBox5 = this.statusJobNo;
			size = new Size(153, 19);
			textBox5.set_Size(size);
			this.statusJobNo.set_TabIndex(13);
			this.statusBadgeId.set_Enabled(false);
			this.statusBadgeId.set_Font(new Font("Tahoma", 8f, 0));
			TextBox textBox6 = this.statusBadgeId;
			point = new Point(141, 25);
			textBox6.set_Location(point);
			this.statusBadgeId.set_Name("statusBadgeId");
			TextBox textBox7 = this.statusBadgeId;
			size = new Size(153, 19);
			textBox7.set_Size(size);
			this.statusBadgeId.set_TabIndex(12);
			this.statusActivity.set_BackColor(Color.get_Khaki());
			this.statusActivity.set_Enabled(false);
			this.statusActivity.set_Font(new Font("Tahoma", 8f, 0));
			TextBox textBox8 = this.statusActivity;
			point = new Point(141, 4);
			textBox8.set_Location(point);
			this.statusActivity.set_Name("statusActivity");
			TextBox textBox9 = this.statusActivity;
			size = new Size(153, 19);
			textBox9.set_Size(size);
			this.statusActivity.set_TabIndex(11);
			this.btnResume.set_BackColor(Color.get_Yellow());
			this.btnResume.set_Font(new Font("Tahoma", 10f, 1));
			this.btnResume.set_ForeColor(SystemColors.get_ActiveCaption());
			Button button16 = this.btnResume;
			point = new Point(159, 154);
			button16.set_Location(point);
			this.btnResume.set_Name("btnResume");
			Button button17 = this.btnResume;
			size = new Size(72, 24);
			button17.set_Size(size);
			this.btnResume.set_TabIndex(8);
			this.btnResume.set_Text("RESUME");
			this.btnEndJob.set_BackColor(Color.get_Red());
			this.btnEndJob.set_Font(new Font("Tahoma", 10f, 1));
			this.btnEndJob.set_ForeColor(SystemColors.get_ActiveCaption());
			Button button18 = this.btnEndJob;
			point = new Point(237, 154);
			button18.set_Location(point);
			this.btnEndJob.set_Name("btnEndJob");
			Button button19 = this.btnEndJob;
			size = new Size(72, 24);
			button19.set_Size(size);
			this.btnEndJob.set_TabIndex(7);
			this.btnEndJob.set_Text("END");
			this.btnPauseJob.set_BackColor(Color.get_Yellow());
			this.btnPauseJob.set_Font(new Font("Tahoma", 10f, 1));
			this.btnPauseJob.set_ForeColor(SystemColors.get_ActiveCaption());
			Button button20 = this.btnPauseJob;
			point = new Point(81, 154);
			button20.set_Location(point);
			this.btnPauseJob.set_Name("btnPauseJob");
			Button button21 = this.btnPauseJob;
			size = new Size(72, 24);
			button21.set_Size(size);
			this.btnPauseJob.set_TabIndex(5);
			this.btnPauseJob.set_Text("PAUSE");
			this.Label18.set_Font(new Font("Tahoma", 9f, 1));
			Label label18 = this.Label18;
			point = new Point(75, 67);
			label18.set_Location(point);
			this.Label18.set_Name("Label18");
			Label label181 = this.Label18;
			size = new Size(64, 20);
			label181.set_Size(size);
			this.Label18.set_Text("Core No.");
			this.Label17.set_Font(new Font("Tahoma", 9f, 1));
			Label label17 = this.Label17;
			point = new Point(81, 47);
			label17.set_Location(point);
			this.Label17.set_Name("Label17");
			Label label171 = this.Label17;
			size = new Size(58, 20);
			label171.set_Size(size);
			this.Label17.set_Text("Job No.");
			this.Label16.set_Font(new Font("Tahoma", 9f, 1));
			Label label16 = this.Label16;
			point = new Point(12, 27);
			label16.set_Location(point);
			this.Label16.set_Name("Label16");
			Label label161 = this.Label16;
			size = new Size(136, 20);
			label161.set_Size(size);
			this.Label16.set_Text("Operator Badge ID");
			this.Label12.set_Font(new Font("Tahoma", 9f, 1));
			Label label12 = this.Label12;
			point = new Point(95, 131);
			label12.set_Location(point);
			this.Label12.set_Name("Label12");
			Label label121 = this.Label12;
			size = new Size(40, 20);
			label121.set_Size(size);
			this.Label12.set_Text("Time");
			this.Label20.set_Font(new Font("Tahoma", 9f, 1));
			Label label20 = this.Label20;
			point = new Point(85, 111);
			label20.set_Location(point);
			this.Label20.set_Name("Label20");
			Label label201 = this.Label20;
			size = new Size(58, 20);
			label201.set_Size(size);
			this.Label20.set_Text("Status");
			this.NumericNoOfOperator.set_Font(new Font("Tahoma", 8f, 0));
			NumericUpDown numericNoOfOperator = this.NumericNoOfOperator;
			point = new Point(171, 88);
			numericNoOfOperator.set_Location(point);
			NumericUpDown numericUpDown = this.NumericNoOfOperator;
			int[] numArray = new int[] { 1, 0, 0, 0 };
			decimal num = new decimal(numArray);
			numericUpDown.set_Minimum(num);
			this.NumericNoOfOperator.set_Name("NumericNoOfOperator");
			NumericUpDown numericNoOfOperator1 = this.NumericNoOfOperator;
			size = new Size(115, 20);
			numericNoOfOperator1.set_Size(size);
			this.NumericNoOfOperator.set_TabIndex(50);
			NumericUpDown numericUpDown1 = this.NumericNoOfOperator;
			numArray = new int[] { 1, 0, 0, 0 };
			num = new decimal(numArray);
			numericUpDown1.set_Value(num);
			this.tbSelectActivity.set_BackColor(Color.FromArgb(192, 224, 255));
			this.tbSelectActivity.get_Controls().Add(this.btn4Activity);
			this.tbSelectActivity.get_Controls().Add(this.Label3);
			this.tbSelectActivity.get_Controls().Add(this.Label4);
			this.tbSelectActivity.get_Controls().Add(this.btn3Activity);
			this.tbSelectActivity.get_Controls().Add(this.btn2Activity);
			this.tbSelectActivity.get_Controls().Add(this.btn1Activity);
			TabPage tabPage2 = this.tbSelectActivity;
			point = new Point(4, 25);
			tabPage2.set_Location(point);
			this.tbSelectActivity.set_Name("tbSelectActivity");
			TabPage tabPage3 = this.tbSelectActivity;
			size = new Size(312, 179);
			tabPage3.set_Size(size);
			this.tbSelectActivity.set_Tag(" ");
			this.tbSelectActivity.set_Text("TabPage1");
			this.btn4Activity.set_Anchor(15);
			this.btn4Activity.set_BackColor(Color.get_Khaki());
			this.btn4Activity.set_ForeColor(SystemColors.get_ControlDarkDark());
			Button button22 = this.btn4Activity;
			point = new Point(166, 105);
			button22.set_Location(point);
			this.btn4Activity.set_Name("btn4Activity");
			Button button23 = this.btn4Activity;
			size = new Size(124, 49);
			button23.set_Size(size);
			this.btn4Activity.set_TabIndex(11);
			this.btn4Activity.set_Text("NON CONFORMITY");
			this.Label3.set_BackColor(Color.get_Black());
			Label label3 = this.Label3;
			point = new Point(16, 23);
			label3.set_Location(point);
			this.Label3.set_Name("Label3");
			Label label31 = this.Label3;
			size = new Size(147, 1);
			label31.set_Size(size);
			this.Label3.set_Text("Label3");
			this.Label4.set_BackColor(Color.FromArgb(192, 224, 255));
			this.Label4.set_Font(new Font("Tahoma", 10f, 1));
			Label label4 = this.Label4;
			point = new Point(16, 4);
			label4.set_Location(point);
			this.Label4.set_Name("Label4");
			Label label41 = this.Label4;
			size = new Size(129, 20);
			label41.set_Size(size);
			this.Label4.set_Text("Select Operation");
			this.btn3Activity.set_Anchor(15);
			this.btn3Activity.set_BackColor(Color.get_Khaki());
			this.btn3Activity.set_Enabled(false);
			this.btn3Activity.set_ForeColor(SystemColors.get_ControlDarkDark());
			Button button24 = this.btn3Activity;
			point = new Point(21, 105);
			button24.set_Location(point);
			this.btn3Activity.set_Name("btn3Activity");
			Button button25 = this.btn3Activity;
			size = new Size(124, 49);
			button25.set_Size(size);
			this.btn3Activity.set_TabIndex(10);
			this.btn3Activity.set_Text("CLOSING");
			this.btn2Activity.set_Anchor(15);
			this.btn2Activity.set_BackColor(Color.get_Khaki());
			this.btn2Activity.set_Enabled(false);
			this.btn2Activity.set_ForeColor(SystemColors.get_ControlDarkDark());
			Button button26 = this.btn2Activity;
			point = new Point(166, 31);
			button26.set_Location(point);
			this.btn2Activity.set_Name("btn2Activity");
			Button button27 = this.btn2Activity;
			size = new Size(124, 49);
			button27.set_Size(size);
			this.btn2Activity.set_TabIndex(8);
			this.btn2Activity.set_Text("ASSEMBLY");
			this.btn1Activity.set_Anchor(15);
			this.btn1Activity.set_BackColor(Color.get_Khaki());
			this.btn1Activity.set_ForeColor(SystemColors.get_ControlDarkDark());
			Button button28 = this.btn1Activity;
			point = new Point(21, 31);
			button28.set_Location(point);
			this.btn1Activity.set_Name("btn1Activity");
			Button button29 = this.btn1Activity;
			size = new Size(124, 49);
			button29.set_Size(size);
			this.btn1Activity.set_TabIndex(6);
			this.btn1Activity.set_Text("SETUP");
			this.tbScanBarcodes.set_BackColor(Color.FromArgb(192, 224, 255));
			this.tbScanBarcodes.get_Controls().Add(this.btnAdd);
			this.tbScanBarcodes.get_Controls().Add(this.btnSubtract);
			this.tbScanBarcodes.get_Controls().Add(this.buttonContinue);
			this.tbScanBarcodes.get_Controls().Add(this.buttonBack);
			this.tbScanBarcodes.get_Controls().Add(this.txtBadgeId);
			this.tbScanBarcodes.get_Controls().Add(this.txtActivityName);
			this.tbScanBarcodes.get_Controls().Add(this.msgIcon);
			this.tbScanBarcodes.get_Controls().Add(this.lblMessage);
			this.tbScanBarcodes.get_Controls().Add(this.txtCoreNo);
			this.tbScanBarcodes.get_Controls().Add(this.txtJobNo);
			this.tbScanBarcodes.get_Controls().Add(this.Label9);
			this.tbScanBarcodes.get_Controls().Add(this.lblActivity);
			this.tbScanBarcodes.get_Controls().Add(this.Label10);
			this.tbScanBarcodes.get_Controls().Add(this.Label11);
			this.tbScanBarcodes.get_Controls().Add(this.lblNoOfOperator);
			this.tbScanBarcodes.get_Controls().Add(this.NoOfOperatorValue);
			TabPage tabPage4 = this.tbScanBarcodes;
			point = new Point(4, 25);
			tabPage4.set_Location(point);
			this.tbScanBarcodes.set_Name("tbScanBarcodes");
			TabPage tabPage5 = this.tbScanBarcodes;
			size = new Size(312, 179);
			tabPage5.set_Size(size);
			this.tbScanBarcodes.set_Text("TabPage2");
			this.btnAdd.set_BackColor(Color.get_Khaki());
			this.btnAdd.set_Font(new Font("Tahoma", 10f, 1));
			Button button30 = this.btnAdd;
			point = new Point(249, 106);
			button30.set_Location(point);
			this.btnAdd.set_Name("btnAdd");
			Button button31 = this.btnAdd;
			size = new Size(42, 26);
			button31.set_Size(size);
			this.btnAdd.set_TabIndex(48);
			this.btnAdd.set_Text("+");
			this.btnSubtract.set_BackColor(Color.get_Khaki());
			this.btnSubtract.set_Font(new Font("Tahoma", 10f, 1));
			Button button32 = this.btnSubtract;
			point = new Point(128, 106);
			button32.set_Location(point);
			this.btnSubtract.set_Name("btnSubtract");
			Button button33 = this.btnSubtract;
			size = new Size(42, 26);
			button33.set_Size(size);
			this.btnSubtract.set_TabIndex(49);
			this.btnSubtract.set_Text("-");
			this.buttonContinue.set_Anchor(15);
			this.buttonContinue.set_BackColor(Color.get_Khaki());
			Button button34 = this.buttonContinue;
			point = new Point(217, 150);
			button34.set_Location(point);
			this.buttonContinue.set_Name("buttonContinue");
			Button button35 = this.buttonContinue;
			size = new Size(92, 28);
			button35.set_Size(size);
			this.buttonContinue.set_TabIndex(63);
			this.buttonContinue.set_Text("Continue >>");
			this.buttonBack.set_BackColor(Color.get_Khaki());
			Button button36 = this.buttonBack;
			point = new Point(1, 150);
			button36.set_Location(point);
			this.buttonBack.set_Name("buttonBack");
			Button button37 = this.buttonBack;
			size = new Size(92, 28);
			button37.set_Size(size);
			this.buttonBack.set_TabIndex(62);
			this.buttonBack.set_Text("<< Back");
			this.txtBadgeId.set_Anchor(15);
			TextBox textBox10 = this.txtBadgeId;
			point = new Point(128, 30);
			textBox10.set_Location(point);
			this.txtBadgeId.set_Name("txtBadgeId");
			TextBox textBox11 = this.txtBadgeId;
			size = new Size(172, 23);
			textBox11.set_Size(size);
			this.txtBadgeId.set_TabIndex(37);
			this.txtActivityName.set_Anchor(15);
			this.txtActivityName.set_Enabled(false);
			TextBox textBox12 = this.txtActivityName;
			point = new Point(128, 4);
			textBox12.set_Location(point);
			this.txtActivityName.set_Name("txtActivityName");
			TextBox textBox13 = this.txtActivityName;
			size = new Size(172, 23);
			textBox13.set_Size(size);
			this.txtActivityName.set_TabIndex(25);
			this.msgIcon.set_BackColor(Color.get_Transparent());
			this.msgIcon.set_Image((Image)componentResourceManager.GetObject("msgIcon.Image"));
			PictureBox pictureBox4 = this.msgIcon;
			point = new Point(7, 133);
			pictureBox4.set_Location(point);
			this.msgIcon.set_Name("msgIcon");
			PictureBox pictureBox5 = this.msgIcon;
			size = new Size(16, 16);
			pictureBox5.set_Size(size);
			this.msgIcon.set_SizeMode(1);
			this.msgIcon.set_Visible(false);
			this.lblMessage.set_Font(new Font("Tahoma", 8f, 0));
			Label label5 = this.lblMessage;
			point = new Point(25, 133);
			label5.set_Location(point);
			this.lblMessage.set_Name("lblMessage");
			Label label6 = this.lblMessage;
			size = new Size(275, 17);
			label6.set_Size(size);
			this.lblMessage.set_Text("Message is here");
			this.lblMessage.set_Visible(false);
			this.txtCoreNo.set_Anchor(15);
			TextBox textBox14 = this.txtCoreNo;
			point = new Point(128, 81);
			textBox14.set_Location(point);
			this.txtCoreNo.set_Name("txtCoreNo");
			TextBox textBox15 = this.txtCoreNo;
			size = new Size(172, 23);
			textBox15.set_Size(size);
			this.txtCoreNo.set_TabIndex(11);
			this.txtJobNo.set_Anchor(15);
			TextBox textBox16 = this.txtJobNo;
			point = new Point(128, 55);
			textBox16.set_Location(point);
			this.txtJobNo.set_Name("txtJobNo");
			TextBox textBox17 = this.txtJobNo;
			size = new Size(172, 23);
			textBox17.set_Size(size);
			this.txtJobNo.set_TabIndex(8);
			this.Label9.set_Font(new Font("Tahoma", 9f, 1));
			Label label9 = this.Label9;
			point = new Point(3, 32);
			label9.set_Location(point);
			this.Label9.set_Name("Label9");
			Label label91 = this.Label9;
			size = new Size(145, 20);
			label91.set_Size(size);
			this.Label9.set_Text("Operator Badge Id ");
			this.lblActivity.set_Font(new Font("Tahoma", 9f, 1));
			Label label7 = this.lblActivity;
			point = new Point(70, 7);
			label7.set_Location(point);
			this.lblActivity.set_Name("lblActivity");
			Label label10 = this.lblActivity;
			size = new Size(71, 20);
			label10.set_Size(size);
			this.lblActivity.set_Text("Activity ");
			this.Label10.set_Font(new Font("Tahoma", 9f, 1));
			Label label101 = this.Label10;
			point = new Point(74, 58);
			label101.set_Location(point);
			this.Label10.set_Name("Label10");
			Label label102 = this.Label10;
			size = new Size(52, 20);
			label102.set_Size(size);
			this.Label10.set_Text("Job No");
			this.Label11.set_Font(new Font("Tahoma", 9f, 1));
			Label label11 = this.Label11;
			point = new Point(68, 83);
			label11.set_Location(point);
			this.Label11.set_Name("Label11");
			Label label111 = this.Label11;
			size = new Size(56, 20);
			label111.set_Size(size);
			this.Label11.set_Text("Core No");
			this.lblNoOfOperator.set_Font(new Font("Tahoma", 9f, 1));
			Label label13 = this.lblNoOfOperator;
			point = new Point(26, 108);
			label13.set_Location(point);
			this.lblNoOfOperator.set_Name("lblNoOfOperator");
			Label label14 = this.lblNoOfOperator;
			size = new Size(99, 20);
			label14.set_Size(size);
			this.lblNoOfOperator.set_Text("No of Operator");
			this.NoOfOperatorValue.set_Anchor(15);
			NumericUpDown noOfOperatorValue = this.NoOfOperatorValue;
			point = new Point(170, 107);
			noOfOperatorValue.set_Location(point);
			NumericUpDown noOfOperatorValue1 = this.NoOfOperatorValue;
			numArray = new int[] { 1, 0, 0, 0 };
			num = new decimal(numArray);
			noOfOperatorValue1.set_Minimum(num);
			this.NoOfOperatorValue.set_Name("NoOfOperatorValue");
			NumericUpDown noOfOperatorValue2 = this.NoOfOperatorValue;
			size = new Size(100, 24);
			noOfOperatorValue2.set_Size(size);
			this.NoOfOperatorValue.set_TabIndex(61);
			NumericUpDown numericUpDown2 = this.NoOfOperatorValue;
			numArray = new int[] { 1, 0, 0, 0 };
			num = new decimal(numArray);
			numericUpDown2.set_Value(num);
			this.tbTableConfig.set_BackColor(Color.FromArgb(192, 224, 255));
			this.tbTableConfig.get_Controls().Add(this.btnClr2);
			this.tbTableConfig.get_Controls().Add(this.btnClr1);
			this.tbTableConfig.get_Controls().Add(this.MsgIconConfig);
			this.tbTableConfig.get_Controls().Add(this.msgConfig);
			this.tbTableConfig.get_Controls().Add(this.btnCancelConfig);
			this.tbTableConfig.get_Controls().Add(this.btnSaveConfig);
			this.tbTableConfig.get_Controls().Add(this.txtConfigDepartmentCode);
			this.tbTableConfig.get_Controls().Add(this.txtConfigTableId);
			this.tbTableConfig.get_Controls().Add(this.Label21);
			this.tbTableConfig.get_Controls().Add(this.lblTable);
			TabPage tabPage6 = this.tbTableConfig;
			point = new Point(4, 25);
			tabPage6.set_Location(point);
			this.tbTableConfig.set_Name("tbTableConfig");
			TabPage tabPage7 = this.tbTableConfig;
			size = new Size(312, 179);
			tabPage7.set_Size(size);
			this.tbTableConfig.set_Text("TabPage1");
			this.btnClr2.set_BackColor(Color.get_Khaki());
			Button button38 = this.btnClr2;
			point = new Point(254, 67);
			button38.set_Location(point);
			this.btnClr2.set_Name("btnClr2");
			Button button39 = this.btnClr2;
			size = new Size(45, 23);
			button39.set_Size(size);
			this.btnClr2.set_TabIndex(8);
			this.btnClr2.set_Text("X");
			this.btnClr1.set_Anchor(15);
			this.btnClr1.set_BackColor(Color.get_Khaki());
			Button button40 = this.btnClr1;
			point = new Point(254, 23);
			button40.set_Location(point);
			this.btnClr1.set_Name("btnClr1");
			Button button41 = this.btnClr1;
			size = new Size(45, 23);
			button41.set_Size(size);
			this.btnClr1.set_TabIndex(7);
			this.btnClr1.set_Text("X");
			this.MsgIconConfig.set_BackColor(Color.get_Transparent());
			this.MsgIconConfig.set_Image((Image)componentResourceManager.GetObject("MsgIconConfig.Image"));
			PictureBox msgIconConfig = this.MsgIconConfig;
			point = new Point(6, 154);
			msgIconConfig.set_Location(point);
			this.MsgIconConfig.set_Name("MsgIconConfig");
			PictureBox msgIconConfig1 = this.MsgIconConfig;
			size = new Size(16, 16);
			msgIconConfig1.set_Size(size);
			this.MsgIconConfig.set_SizeMode(1);
			this.MsgIconConfig.set_Visible(false);
			this.msgConfig.set_Font(new Font("Tahoma", 8f, 0));
			Label label21 = this.msgConfig;
			point = new Point(24, 154);
			label21.set_Location(point);
			this.msgConfig.set_Name("msgConfig");
			Label label22 = this.msgConfig;
			size = new Size(275, 17);
			label22.set_Size(size);
			this.msgConfig.set_Text("Message is here");
			this.msgConfig.set_Visible(false);
			this.btnCancelConfig.set_BackColor(Color.get_Khaki());
			this.btnCancelConfig.set_ForeColor(SystemColors.get_ActiveCaption());
			Button button42 = this.btnCancelConfig;
			point = new Point(222, 109);
			button42.set_Location(point);
			this.btnCancelConfig.set_Name("btnCancelConfig");
			Button button43 = this.btnCancelConfig;
			size = new Size(75, 31);
			button43.set_Size(size);
			this.btnCancelConfig.set_TabIndex(4);
			this.btnCancelConfig.set_Text("Cancel");
			this.btnSaveConfig.set_BackColor(Color.get_Khaki());
			this.btnSaveConfig.set_ForeColor(SystemColors.get_ActiveCaption());
			Button button44 = this.btnSaveConfig;
			point = new Point(136, 109);
			button44.set_Location(point);
			this.btnSaveConfig.set_Name("btnSaveConfig");
			Button button45 = this.btnSaveConfig;
			size = new Size(75, 31);
			button45.set_Size(size);
			this.btnSaveConfig.set_TabIndex(3);
			this.btnSaveConfig.set_Text("Save");
			TextBox textBox18 = this.txtConfigDepartmentCode;
			point = new Point(136, 67);
			textBox18.set_Location(point);
			this.txtConfigDepartmentCode.set_Name("txtConfigDepartmentCode");
			TextBox textBox19 = this.txtConfigDepartmentCode;
			size = new Size(112, 23);
			textBox19.set_Size(size);
			this.txtConfigDepartmentCode.set_TabIndex(0);
			TextBox textBox20 = this.txtConfigTableId;
			point = new Point(136, 23);
			textBox20.set_Location(point);
			this.txtConfigTableId.set_Name("txtConfigTableId");
			TextBox textBox21 = this.txtConfigTableId;
			size = new Size(112, 23);
			textBox21.set_Size(size);
			this.txtConfigTableId.set_TabIndex(1);
			this.Label21.set_Font(new Font("Tahoma", 10f, 1));
			Label label211 = this.Label21;
			point = new Point(7, 70);
			label211.set_Location(point);
			this.Label21.set_Name("Label21");
			Label label212 = this.Label21;
			size = new Size(127, 20);
			label212.set_Size(size);
			this.Label21.set_Text("Department Code");
			this.lblTable.set_Font(new Font("Tahoma", 10f, 1));
			Label label23 = this.lblTable;
			point = new Point(66, 26);
			label23.set_Location(point);
			this.lblTable.set_Name("lblTable");
			Label label24 = this.lblTable;
			size = new Size(72, 20);
			label24.set_Size(size);
			this.lblTable.set_Text("Table Id");
			this.pcSettings.set_Anchor(15);
			this.pcSettings.set_Image((Image)componentResourceManager.GetObject("pcSettings.Image"));
			PictureBox pictureBox6 = this.pcSettings;
			point = new Point(1, 208);
			pictureBox6.set_Location(point);
			this.pcSettings.set_Name("pcSettings");
			PictureBox pictureBox7 = this.pcSettings;
			size = new Size(31, 31);
			pictureBox7.set_Size(size);
			this.pcSettings.set_SizeMode(1);
			this.lblDepartmentCode.set_Font(new Font("Tahoma", 10f, 1));
			Label label25 = this.lblDepartmentCode;
			point = new Point(33, 214);
			label25.set_Location(point);
			this.lblDepartmentCode.set_Name("lblDepartmentCode");
			Label label26 = this.lblDepartmentCode;
			size = new Size(78, 20);
			label26.set_Size(size);
			this.lblDepartmentCode.set_Text("Dept Code");
			this.lblTableId.set_Font(new Font("Tahoma", 10f, 1));
			Label label27 = this.lblTableId;
			point = new Point(104, 214);
			label27.set_Location(point);
			this.lblTableId.set_Name("lblTableId");
			Label label28 = this.lblTableId;
			size = new Size(63, 20);
			label28.set_Size(size);
			this.lblTableId.set_Text("Table Id");
			this.Label7.set_BackColor(Color.get_Black());
			Label label71 = this.Label7;
			point = new Point(0, 239);
			label71.set_Location(point);
			this.Label7.set_Name("Label7");
			Label label72 = this.Label7;
			size = new Size(320, 1);
			label72.set_Size(size);
			this.Label7.set_Text("Label7");
			this.Label1.set_BackColor(Color.get_Black());
			Label label110 = this.Label1;
			point = new Point(0, 204);
			label110.set_Location(point);
			this.Label1.set_Name("Label1");
			Label label112 = this.Label1;
			size = new Size(1, 36);
			label112.set_Size(size);
			this.Label1.set_Text("Label1");
			this.Label2.set_BackColor(Color.get_Black());
			Label label29 = this.Label2;
			point = new Point(319, 204);
			label29.set_Location(point);
			this.Label2.set_Name("Label2");
			Label label210 = this.Label2;
			size = new Size(1, 36);
			label210.set_Size(size);
			this.Label2.set_Text("Label2");
			this.lblTime.set_Anchor(15);
			this.lblTime.set_Font(new Font("Tahoma", 9f, 1));
			Label label30 = this.lblTime;
			point = new Point(169, 215);
			label30.set_Location(point);
			this.lblTime.set_Name("lblTime");
			Label label32 = this.lblTime;
			size = new Size(148, 20);
			label32.set_Size(size);
			this.lblTime.set_Text("TIME 00 : 00 : 00 ");
			this.lblTime.set_Visible(false);
			this.Timer1.set_Interval(1000);
			this.Timer2.set_Interval(1000);
			this.set_AutoScaleDimensions(new SizeF(96f, 96f));
			this.set_AutoScaleMode(2);
			this.set_AutoScroll(true);
			this.set_BackColor(SystemColors.get_ControlLightLight());
			size = new Size(320, 240);
			this.set_ClientSize(size);
			this.set_ControlBox(false);
			this.get_Controls().Add(this.pcSettings);
			this.get_Controls().Add(this.lblTime);
			this.get_Controls().Add(this.Label2);
			this.get_Controls().Add(this.Label1);
			this.get_Controls().Add(this.Label7);
			this.get_Controls().Add(this.pnlMenu);
			this.get_Controls().Add(this.tbActivities);
			this.get_Controls().Add(this.lblTableId);
			this.get_Controls().Add(this.lblDepartmentCode);
			this.set_FormBorderStyle(0);
			this.set_Icon((Icon)componentResourceManager.GetObject("$this.Icon"));
			this.set_MaximizeBox(false);
			this.set_MinimizeBox(false);
			this.set_Name("SmartApp");
			this.set_Text("SmartApp");
			this.set_TopMost(true);
			this.pnlMenu.ResumeLayout(false);
			this.tbActivities.ResumeLayout(false);
			this.tbSelectTasks.ResumeLayout(false);
			this.tbSelectActivity.ResumeLayout(false);
			this.tbScanBarcodes.ResumeLayout(false);
			this.tbTableConfig.ResumeLayout(false);
			this.ResumeLayout(false);
		}

		public void InsertInEquipmentScrum()
		{
			string text = this.statusJobNo.get_Text();
			char[] chrArray = new char[] { '/' };
			string[] strArray = text.Split(chrArray);
			string str = this.statusCoreNo.get_Text();
			chrArray = new char[] { '/' };
			string[] strArray1 = str.Split(chrArray);
			string text1 = this.lblTableId.get_Text();
			string str1 = strArray[0];
			string str2 = strArray[1];
			string str3 = strArray1[0];
			string str4 = strArray1[1];
			this.statusActivity.get_Text();
			this.StatusName.get_Text().Trim();
			try
			{
				try
				{
					if (Convert.ToInt16(SmartApp.createWebService().DoingEquipmentScrum(str1, str2, str3, str4)) > 0)
					{
						SmartApp.createWebService().UpdateEquipmentScrum(text1, str1, str2, str3, str4, this.Myactivity, this.StatusName.get_Text());
					}
					else
					{
						SmartApp.createWebService().InsertEquipmentScrum(text1, str1, str2, Conversions.ToInteger(str3), Conversions.ToInteger(str4), this.Myactivity, this.StatusName.get_Text());
					}
				}
				catch (SqlException sqlException)
				{
					ProjectData.SetProjectError((Exception)sqlException);
					throw new Exception("Check connection with machine");
				}
			}
			catch (Exception exception)
			{
				ProjectData.SetProjectError(exception);
				throw new Exception("Check connection with machine");
			}
		}

		public void InsertInScrumTable()
		{
			string text = this.statusJobNo.get_Text();
			char[] chrArray = new char[] { '/' };
			string[] strArray = text.Split(chrArray);
			string str = this.statusCoreNo.get_Text();
			chrArray = new char[] { '/' };
			string[] strArray1 = str.Split(chrArray);
			this.lblTableId.get_Text();
			string str1 = strArray[0];
			string str2 = strArray[1];
			string str3 = strArray1[0];
			string str4 = strArray1[1];
			string myactivity = this.Myactivity;
			this.StatusName.get_Text().Trim();
			int num = 0;
			int num1 = 0;
			int num2 = 0;
			string str5 = GlobalVariables.strNetworkAddress;
			string str6 = GlobalVariables.strNetworkUsername;
			string str7 = GlobalVariables.strNetworkPassword;
			string str8 = GlobalVariables.strNetworkDB;
			string str9 = SmartApp.createWebService().CheckRecords(str1, str2, Conversions.ToInteger(str4));
			try
			{
				if (Conversions.ToShort(str9) > 0)
				{
					this.CheckToDo();
				}
				else
				{
					num = checked((int)Math.Round(Conversions.ToDouble(str4) - 1));
					num1 = 1;
					num2 = 0;
					SmartApp.createWebService().InsertScrumTable(str1, str2, Conversions.ToInteger(str4), num, num1, num2);
				}
			}
			catch (SqlException sqlException)
			{
				ProjectData.SetProjectError((Exception)sqlException);
				throw new Exception("Check connection with machine");
			}
		}

		public static void Main()
		{
			Application.Run(MyProject.Forms.SmartApp);
		}

		public void MonitoringAndCounterCalculation()
		{
			string text = this.statusJobNo.get_Text();
			char[] chrArray = new char[] { '/' };
			string[] strArray = text.Split(chrArray);
			string str = this.statusCoreNo.get_Text();
			chrArray = new char[] { '/' };
			string[] strArray1 = str.Split(chrArray);
			this.lblTableId.get_Text();
			string str1 = strArray[0];
			string str2 = strArray[1];
			string str3 = strArray1[0];
			string str4 = strArray1[1];
			string myactivity = this.Myactivity;
			this.StatusName.get_Text().Trim();
			string str5 = GlobalVariables.strNetworkAddress;
			string str6 = GlobalVariables.strNetworkUsername;
			string str7 = GlobalVariables.strNetworkPassword;
			string str8 = GlobalVariables.strNetworkDB;
			if (Operators.CompareString(this.Myactivity, "SETUP", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "START", false) == 0)
			{
				this.InsertInEquipmentScrum();
				this.InsertInScrumTable();
			}
			else if (Operators.CompareString(this.Myactivity, "SETUP", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "END", false) == 0)
			{
				this.InsertInEquipmentScrum();
			}
			else if (Operators.CompareString(this.Myactivity, "ASSEMBLY", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "START", false) == 0)
			{
				this.InsertInEquipmentScrum();
			}
			else if (Operators.CompareString(this.Myactivity, "ASSEMBLY", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "END", false) == 0)
			{
				this.InsertInEquipmentScrum();
			}
			else if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "START", false) == 0)
			{
				this.InsertInEquipmentScrum();
			}
			else if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "END", false) == 0)
			{
				this.CheckToDo();
				if (Operators.CompareString(this.statusActivity.get_Text(), "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "END", false) == 0)
				{
					try
					{
						SmartApp.createWebService().DeleteFinishedEquipmentScrum(str1, str2, str3, str4);
					}
					catch (Exception exception1)
					{
						ProjectData.SetProjectError(exception1);
						Exception exception = exception1;
						MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
						Application.Exit();
						ProjectData.ClearProjectError();
					}
				}
			}
			else if (Operators.CompareString(this.Myactivity, "NON CONFORMITY", false) == 0 & Operators.CompareString(this.StatusName.get_Text(), "START", false) == 0)
			{
				try
				{
					SmartApp.createWebService().DeleteFinishedEquipmentScrum(str1, str2, str3, str4);
				}
				catch (Exception exception3)
				{
					ProjectData.SetProjectError(exception3);
					Exception exception2 = exception3;
					MessageBox.Show(string.Concat("Error!", exception2.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
					Application.Exit();
					ProjectData.ClearProjectError();
				}
				try
				{
					SmartApp.createWebService().DeleteItemInWP(str1, str2, str3, str4);
				}
				catch (Exception exception5)
				{
					ProjectData.SetProjectError(exception5);
					Exception exception4 = exception5;
					MessageBox.Show(string.Concat("Error!", exception4.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
					Application.Exit();
					ProjectData.ClearProjectError();
				}
			}
		}

		private void myReader_ReadNotify(object Sender, EventArgs e)
		{
			if (!this.get_InvokeRequired())
			{
				ReaderData nextReaderData = this.myScanSampleAPI.Reader.GetNextReaderData();
				Results result = nextReaderData.Result;
				if (result == Results.SUCCESS)
				{
					this.HandleContinuousData(nextReaderData);
				}
				else if (result == Results.E_SCN_READTIMEOUT)
				{
					this.myScanSampleAPI.StartRead(true);
				}
				else if (result != Results.CANCELED)
				{
					if (result != Results.E_SCN_DEVICEFAILURE)
					{
						string str = string.Concat("Read Failed\nResult = ", nextReaderData.Result.ToString());
						this.lblMessage.set_Text(str);
						if (nextReaderData.Result == Results.E_SCN_READINCOMPATIBLE)
						{
							MessageBox.Show(ScanApp.Resources.GetString("AppExitMsg"), ScanApp.Resources.GetString("Failure"));
							this.Close();
							return;
						}
					}
					else
					{
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.StartRead(true);
					}
				}
			}
			else
			{
				EventHandler eventHandler = this.myReadNotifyHandler;
				object[] objectValue = new object[] { RuntimeHelpers.GetObjectValue(Sender), e };
				this.Invoke(eventHandler, objectValue);
			}
		}

		private void myReader_StatusNotify(object Sender, EventArgs e)
		{
			if (!this.get_InvokeRequired())
			{
				BarcodeStatus nextStatus = this.myScanSampleAPI.Reader.GetNextStatus();
				switch (nextStatus.State)
				{
					case States.IDLE:
					{
						break;
					}
					case States.WAITING:
					{
						if (this.prevState == States.READY)
						{
							this.myScanSampleAPI.StopRead();
							this.myScanSampleAPI.StartRead(true);
						}
						break;
					}
					case States.READY:
					{
						break;
					}
					default:
					{
						this.lblMessage.set_Text(nextStatus.Text);
						break;
					}
				}
				this.prevState = nextStatus.State;
			}
			else
			{
				EventHandler eventHandler = this.myStatusNotifyHandler;
				object[] objectValue = new object[] { RuntimeHelpers.GetObjectValue(Sender), e };
				this.Invoke(eventHandler, objectValue);
			}
		}

		private void NoOfOperatorValue_ValueChanged(object sender, EventArgs e)
		{
			if (decimal.Compare(this.NoOfOperatorValue.get_Value(), decimal.One) < 0)
			{
				this.msgIcon.set_Visible(Conversions.ToBoolean("True"));
				this.lblMessage.set_Text("You have reached minimum operator limit");
				this.lblMessage.set_Visible(Conversions.ToBoolean("True"));
			}
			else if (decimal.Compare(this.NoOfOperatorValue.get_Value(), new decimal((long)100)) <= 0)
			{
				this.msgIcon.set_Visible(Conversions.ToBoolean("False"));
				this.lblMessage.set_Visible(Conversions.ToBoolean("False"));
			}
			else
			{
				this.msgIcon.set_Visible(Conversions.ToBoolean("True"));
				this.lblMessage.set_Text("You have reached maximum operator limit");
				this.lblMessage.set_Visible(Conversions.ToBoolean("True"));
			}
		}

		private void pcClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void pcContinue_Click(object sender, EventArgs e)
		{
			if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) == 0)
			{
				this.txtBadgeId.Focus();
				this.msgIcon.set_Visible(true);
				this.lblMessage.set_Text("Provide Badge Id");
				this.lblMessage.set_Visible(true);
			}
			else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) == 0)
			{
				this.txtJobNo.Focus();
				this.msgIcon.set_Visible(true);
				this.lblMessage.set_Text("Provide Job No.");
				this.lblMessage.set_Visible(true);
			}
			else if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) == 0)
			{
				this.txtCoreNo.Focus();
				this.msgIcon.set_Visible(true);
				this.lblMessage.set_Text("Provide Core No.");
				this.lblMessage.set_Visible(true);
				this.NoOfOperator = this.MyNoOfOperator;
			}
			else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0)
			{
				this.NumericNoOfOperator.set_Value(this.NoOfOperatorValue.get_Value());
				this.NoOfOperator = Conversions.ToString(this.NumericNoOfOperator.get_Value());
				if (this.Validate())
				{
					this.tbActivities.set_SelectedIndex(0);
					this.GetDetailsForStatus();
					if (this.lblMessage.get_Visible())
					{
						this.msgIcon.set_Visible(false);
						this.lblMessage.set_Visible(false);
					}
				}
			}
		}

		private void pcLegnano_Click(object sender, EventArgs e)
		{
			if (!this.pcClose.get_Visible())
			{
				this.pcClose.set_Enabled(true);
				this.pcClose.set_Visible(true);
			}
			else if (this.pcClose.get_Visible())
			{
				this.pcClose.set_Enabled(false);
				this.pcClose.set_Visible(false);
			}
		}

		private void pcSettings_Click(object sender, EventArgs e)
		{
			this.tbActivities.set_SelectedIndex(3);
			this.txtConfigTableId.set_Enabled(Conversions.ToBoolean("True"));
			this.txtConfigDepartmentCode.set_Enabled(Conversions.ToBoolean("True"));
			this.readSettingsFromXML();
		}

		public void readConfigValues()
		{
			try
			{
				DataSet dataSet = new DataSet();
				dataSet.ReadXml("\\Platform\\Barcode Gulf\\Config.xml");
				if (dataSet.get_Tables().get_Item(0).get_Rows().get_Count() > 0)
				{
					GlobalVariables.strNetworkAddress = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("NetAddress").ToString().Trim();
					GlobalVariables.strNetworkDB = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("DB").ToString().Trim();
					GlobalVariables.strNetworkUsername = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("UName").ToString().Trim();
					GlobalVariables.strNetworkPassword = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("Pwd").ToString().Trim();
					GlobalVariables.strDepartmentCode = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("DepartmentCode").ToString().Trim();
					GlobalVariables.strTableId = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("TableId").ToString().Trim();
					GlobalVariables.VerifyServer = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("VerifyServer").ToString().Trim();
					GlobalVariables.VerifyUser = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("VerifyUser").ToString().Trim();
					GlobalVariables.VerifyPwd = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("VerifyPwd").ToString().Trim();
					GlobalVariables.VerifyDB = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("VerifyDB").ToString().Trim();
					GlobalVariables.VerifyTable = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("VerifyTable").ToString().Trim();
					GlobalVariables.CopyTable = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("CopyTable").ToString().Trim();
					GlobalVariables.WebServiceURL = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("WebServiceURL").ToString().Trim();
				}
			}
			catch (Exception exception)
			{
				ProjectData.SetProjectError(exception);
				throw exception;
			}
		}

		public void readSettingsFromXML()
		{
			try
			{
				DataSet dataSet = new DataSet();
				dataSet.ReadXml("\\Platform\\Barcode Gulf\\Config.xml");
				if (dataSet.get_Tables().get_Item(0).get_Rows().get_Count() > 0)
				{
					GlobalVariables.strDepartmentCode = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("DepartmentCode").ToString().Trim();
					GlobalVariables.strTableId = dataSet.get_Tables().get_Item(0).get_Rows().get_Item(0).get_Item("TableId").ToString().Trim();
					this.lblDepartmentCode.set_Text(GlobalVariables.strDepartmentCode);
					this.lblTableId.set_Text(GlobalVariables.strTableId);
					this.txtConfigDepartmentCode.set_Text(GlobalVariables.strDepartmentCode);
					this.txtConfigTableId.set_Text(GlobalVariables.strTableId);
				}
			}
			catch (Exception exception)
			{
				ProjectData.SetProjectError(exception);
				throw new Exception("Check Configuration Settings");
			}
		}

		public string RemoveWhitespace(string fullString)
		{
			string str = new string(Enumerable.ToArray<char>(Enumerable.Where<char>(fullString, new Func<char, bool>(null, (char x) => !char.IsWhiteSpace(x)))));
			return str;
		}

		private bool SearchTheTextValues()
		{
			return true;
		}

		private void SmartApp_Closing(object sender, CancelEventArgs e)
		{
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.DetachReadNotify();
				this.myScanSampleAPI.DetachStatusNotify();
				this.myScanSampleAPI.TermReader();
				this.remove_Activated(this.myFormActivatedEventHandler);
				this.remove_Deactivate(this.myFormDeactivatedEventHandler);
			}
		}

		private void SmartApp_Load(object sender, EventArgs e)
		{
			try
			{
				this.CheckConnectionSettings();
				this.readSettingsFromXML();
				if (!this.myconnection)
				{
					MessageBox.Show("Check Connection Settings");
					Application.Exit();
				}
				else
				{
					this.tbActivities.set_SelectedIndex(1);
					this.Timer1.set_Enabled(true);
					this.readConfigValues();
					this.myScanSampleAPI = new ScanApp.VB_BarcodeSample1.API();
					this.isReaderInitiated = this.myScanSampleAPI.InitReader();
					if (this.isReaderInitiated)
					{
						this.lblMessage.set_Text("");
						SmartApp smartApp = this;
						this.myStatusNotifyHandler = new EventHandler(smartApp, smartApp.myReader_StatusNotify);
						this.myScanSampleAPI.AttachStatusNotify(this.myStatusNotifyHandler);
					}
					else
					{
						MessageBox.Show(ScanApp.Resources.GetString("AppExitMsg"));
						Application.Exit();
					}
				}
			}
			catch (Exception exception1)
			{
				ProjectData.SetProjectError(exception1);
				Exception exception = exception1;
				MessageBox.Show(exception.get_Message(), string.Concat(GlobalVariables.strMessagePrefixError.Trim(), "Settings"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
			}
		}

		private void StartJob_Click(object sender, EventArgs e)
		{
			try
			{
				this.BadgeStart = this.statusBadgeId.get_Text();
				this.StartDate = this.lblTime.get_Text();
				this.Timer2.set_Enabled(true);
				this.stopwatch.Start();
				this.CheckConnectionSettings();
				this.jobstatus = "START";
				this.StatusName.set_Text(this.jobstatus);
				if (Operators.CompareString(this.Myactivity, "NON CONFORMITY", false) != 0)
				{
					this.WriteInNetwork();
				}
				else
				{
					this.WriteInNetworkForNonConformity();
				}
				this.MonitoringAndCounterCalculation();
				this.StartJob.set_Enabled(false);
				this.btnPauseJob.set_Enabled(true);
				this.btnResume.set_Enabled(false);
				this.btnEndJob.set_Enabled(true);
				this.tbActivities.set_SelectedIndex(0);
				this.statusBadgeId.set_Enabled(Conversions.ToBoolean("True"));
				this.statusBadgeId.set_Text("");
			}
			catch (Exception exception1)
			{
				ProjectData.SetProjectError(exception1);
				Exception exception = exception1;
				MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
			}
		}

		private void statusBadgeId_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				SmartApp smartApp = this;
				this.myReadNotifyHandler = new EventHandler(smartApp, smartApp.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		private void statusBadgeId_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		private void SyncServerTime()
		{
			try
			{
				this.myTime = Convert.ToDateTime(SmartApp.createWebService().GetCustomDate(), new CultureInfo("fr-FR"));
			}
			catch (Exception exception1)
			{
				ProjectData.SetProjectError(exception1);
				Exception exception = exception1;
				MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
			}
		}

		private void Timer1_Tick(object sender, EventArgs e)
		{
			DateTime date = Conversions.ToDate(this.MyTimeValue);
			DateTime dateTime = date.AddSeconds(1);
			this.lblTime.set_Text(dateTime.ToString("dd/MM/yyyy HH:mm:ss"));
			this.lblTime.set_Visible(true);
			this.myTime = dateTime;
		}

		private void Timer2_Tick(object sender, EventArgs e)
		{
			TimeSpan elapsed = this.stopwatch.get_Elapsed();
			this.statusTime.set_Text(string.Format("{0:00}:{1:00}:{2:00}", Math.Floor(elapsed.get_TotalHours()), elapsed.get_Minutes(), elapsed.get_Seconds()));
		}

		private void txtBadgeId_GotFocus(object sender, EventArgs e)
		{
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				SmartApp smartApp = this;
				this.myReadNotifyHandler = new EventHandler(smartApp, smartApp.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		private void txtBadgeId_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.get_KeyCode() == 13)
			{
				int length = this.txtBadgeId.get_Text().get_Length();
				string str = length.ToString();
				if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
				}
				else if (this.txtBadgeId.get_Text().Contains("/"))
				{
					MessageBox.Show("Scan Badge Id to Continue", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
					this.txtBadgeId.set_Text("");
				}
				else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtJobNo.get_Text(), this.txtBadgeId.get_Text(), false) == 0)
				{
					this.txtBadgeId.set_Text("");
					this.lblMessage.set_Text("Job No. already scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
				}
				else if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), this.txtBadgeId.get_Text(), false) == 0)
				{
					this.txtBadgeId.set_Text("");
					this.lblMessage.set_Text("Core No. already scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
				}
				else if (!(Conversions.ToDouble(str) > 9 | Conversions.ToDouble(str) < 8))
				{
					this.badgeid = this.txtBadgeId.get_Text();
					this.txtBadgeId.set_Enabled(false);
					if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) == 0)
					{
						this.txtJobNo.Focus();
					}
					else if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) == 0)
					{
						this.txtCoreNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0)
					{
						this.tbActivities.set_SelectedIndex(2);
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.get_Visible())
					{
						this.msgIcon.set_Visible(false);
						this.lblMessage.set_Visible(false);
					}
				}
				else
				{
					this.txtBadgeId.set_Text("");
					MessageBox.Show("Check Scanned Badge Id", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
				}
			}
		}

		private void txtBadgeId_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		private void txtBadgeId_TextChanged(object sender, EventArgs e)
		{
		}

		private void txtConfigDepartmentCode_GotFocus(object sender, EventArgs e)
		{
			this.txtConfigDepartmentCode.SelectAll();
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				SmartApp smartApp = this;
				this.myReadNotifyHandler = new EventHandler(smartApp, smartApp.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		private void txtConfigDepartmentCode_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		private void txtConfigTableId_GotFocus(object sender, EventArgs e)
		{
			this.txtConfigTableId.SelectAll();
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				SmartApp smartApp = this;
				this.myReadNotifyHandler = new EventHandler(smartApp, smartApp.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		private void txtConfigTableId_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		private void txtCoreNo_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				SmartApp smartApp = this;
				this.myReadNotifyHandler = new EventHandler(smartApp, smartApp.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		private void txtCoreNo_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.get_KeyCode() == 13)
			{
				int length = this.txtCoreNo.get_Text().get_Length();
				string str = length.ToString();
				if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
				}
				else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtJobNo.get_Text(), this.txtCoreNo.get_Text(), false) == 0)
				{
					this.txtCoreNo.set_Text("");
					this.lblMessage.set_Text("Job No. already scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
				}
				else if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), this.txtCoreNo.get_Text(), false) == 0)
				{
					this.txtCoreNo.set_Text("");
					this.lblMessage.set_Text("Operator Badge Id already scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
				}
				else if (!(Conversions.ToDouble(str) > 7 | Conversions.ToDouble(str) < 3))
				{
					this.coreno = this.txtCoreNo.get_Text();
					this.txtCoreNo.set_Enabled(false);
					if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) == 0)
					{
						this.txtBadgeId.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) == 0)
					{
						this.txtJobNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0)
					{
						this.tbActivities.set_SelectedIndex(2);
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.get_Visible())
					{
						this.msgIcon.set_Visible(false);
						this.lblMessage.set_Visible(false);
					}
				}
				else
				{
					this.txtCoreNo.set_Text("");
					MessageBox.Show("Check Scanned Core No", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
				}
			}
		}

		private void txtCoreNo_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		private void txtJobNo_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				SmartApp smartApp = this;
				this.myReadNotifyHandler = new EventHandler(smartApp, smartApp.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		private void txtJobNo_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.get_KeyCode() == 13)
			{
				int length = this.txtJobNo.get_Text().get_Length();
				string str = length.ToString();
				if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
				}
				else if (this.txtJobNo.get_Text().Contains("-"))
				{
					MessageBox.Show("Check scanned barcode", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
				}
				else if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), this.txtJobNo.get_Text(), false) == 0)
				{
					this.txtJobNo.set_Text("");
					this.lblMessage.set_Text("Operator Id has been scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
				}
				else if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), this.txtJobNo.get_Text(), false) == 0)
				{
					this.txtJobNo.set_Text("");
					this.lblMessage.set_Text("Core No. has been scanned");
					this.msgIcon.set_Visible(true);
					this.lblMessage.set_Visible(true);
				}
				else if (!(Conversions.ToDouble(str) > 11 | Conversions.ToDouble(str) < 7))
				{
					this.jobno = this.txtJobNo.get_Text();
					this.txtJobNo.set_Enabled(false);
					if (Operators.CompareString(this.txtBadgeId.get_Text(), "", false) == 0)
					{
						this.txtBadgeId.Focus();
					}
					else if (Operators.CompareString(this.txtCoreNo.get_Text(), "", false) == 0)
					{
						this.txtCoreNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtCoreNo.get_Text(), "", false) != 0 & Operators.CompareString(this.txtBadgeId.get_Text(), "", false) != 0)
					{
						this.tbActivities.set_SelectedIndex(2);
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.get_Visible())
					{
						this.msgIcon.set_Visible(false);
						this.lblMessage.set_Visible(false);
					}
				}
				else
				{
					this.txtJobNo.set_Text("");
					MessageBox.Show("Check Scanned Job No. Details", string.Concat(GlobalVariables.strMessagePrefixError, " Scan"), 0, 16, 0);
				}
			}
		}

		private void txtJobNo_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		private void txtScanOperator_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				SmartApp smartApp = this;
				this.myReadNotifyHandler = new EventHandler(smartApp, smartApp.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		private void txtScanOperator_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		private void txtSerialNo_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				SmartApp smartApp = this;
				this.myReadNotifyHandler = new EventHandler(smartApp, smartApp.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		private void txtSerialNo_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		private void txtStationId_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				SmartApp smartApp = this;
				this.myReadNotifyHandler = new EventHandler(smartApp, smartApp.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		private void txtStationId_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		private void UpdateInNetwork()
		{
			try
			{
				try
				{
					try
					{
						string str = GlobalVariables.strNetworkAddress;
						string str1 = GlobalVariables.strNetworkUsername;
						string str2 = GlobalVariables.strNetworkPassword;
						string str3 = GlobalVariables.strNetworkDB;
						string text = this.statusJobNo.get_Text();
						char[] chrArray = new char[] { '/' };
						string[] strArray = text.Split(chrArray);
						string str4 = strArray[0];
						string str5 = strArray[1];
						string text1 = this.statusCoreNo.get_Text();
						chrArray = new char[] { '/' };
						string[] strArray1 = text1.Split(chrArray);
						string str6 = strArray1[0];
						string str7 = strArray1[1];
						string str8 = this.EndDate.ToString();
						DateTime dateTime = DateTime.ParseExact(str8, "dd/MM/yyyy HH:mm:ss", DateTimeFormatInfo.get_InvariantInfo());
						SmartApp.createWebService().UpdateWorkInNetwork(this.BadgeEnd, dateTime, str4, str5, Conversions.ToInteger(str6), Conversions.ToInteger(str7), this.lblTableId.get_Text(), this.NumericNoOfOperator.get_Value(), this.statusActivity.get_Text());
					}
					catch (Exception exception1)
					{
						ProjectData.SetProjectError(exception1);
						Exception exception = exception1;
						MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
						Application.Exit();
						ProjectData.ClearProjectError();
					}
				}
				finally
				{
				}
				if (Operators.CompareString(this.jobstatus, "START", false) == 0)
				{
					this.StartJob.set_Enabled(false);
					this.tbActivities.set_SelectedIndex(0);
				}
				else if (Operators.CompareString(this.jobstatus, "END", false) == 0)
				{
					this.StartJob.set_Enabled(false);
					this.pcSettings.set_Enabled(true);
					this.pcSettings.set_Visible(true);
					this.tbActivities.set_SelectedIndex(1);
				}
			}
			catch (Exception exception2)
			{
				ProjectData.SetProjectError(exception2);
				throw exception2;
			}
		}

		private void UpdateInNetworkForNonConformity()
		{
			try
			{
				try
				{
					try
					{
						string str = GlobalVariables.strNetworkAddress;
						string str1 = GlobalVariables.strNetworkUsername;
						string str2 = GlobalVariables.strNetworkPassword;
						string str3 = GlobalVariables.strNetworkDB;
						string text = this.statusJobNo.get_Text();
						char[] chrArray = new char[] { '/' };
						string[] strArray = text.Split(chrArray);
						string str4 = strArray[0];
						string str5 = strArray[1];
						string text1 = this.statusCoreNo.get_Text();
						chrArray = new char[] { '/' };
						string[] strArray1 = text1.Split(chrArray);
						string str6 = strArray1[0];
						string str7 = strArray1[1];
						string str8 = this.StartDate.ToString();
						string str9 = this.EndDate.ToString();
						DateTime dateTime = DateTime.ParseExact(str8, "dd/MM/yyyy HH:mm:ss", DateTimeFormatInfo.get_InvariantInfo());
						DateTime dateTime1 = DateTime.ParseExact(str9, "dd/MM/yyyy HH:mm:ss", DateTimeFormatInfo.get_InvariantInfo());
						SmartApp.createWebService().UpdateWorkInProgressNC(this.BadgeEnd, dateTime1, str4, str5, Conversions.ToInteger(str6), this.BadgeStart, dateTime);
					}
					catch (Exception exception1)
					{
						ProjectData.SetProjectError(exception1);
						Exception exception = exception1;
						MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
						Application.Exit();
						ProjectData.ClearProjectError();
					}
				}
				finally
				{
				}
				if (Operators.CompareString(this.jobstatus, "START", false) == 0)
				{
					this.StartJob.set_Enabled(false);
					this.tbActivities.set_SelectedIndex(0);
				}
				else if (Operators.CompareString(this.jobstatus, "END", false) == 0)
				{
					this.StartJob.set_Enabled(false);
					this.pcSettings.set_Enabled(true);
					this.pcSettings.set_Visible(true);
					this.tbActivities.set_SelectedIndex(1);
				}
			}
			catch (Exception exception3)
			{
				ProjectData.SetProjectError(exception3);
				Exception exception2 = exception3;
				MessageBox.Show(string.Concat("Error!", exception2.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
			}
		}

		private bool Validate()
		{
			bool flag = false;
			string text = this.txtJobNo.get_Text();
			char[] chrArray = new char[] { '/' };
			string[] strArray = text.Split(chrArray);
			string str = this.txtCoreNo.get_Text();
			chrArray = new char[] { '/' };
			string[] strArray1 = str.Split(chrArray);
			this.lblTableId.get_Text();
			string str1 = strArray[0];
			string str2 = strArray[1];
			string str3 = strArray1[0];
			string str4 = strArray1[1];
			string myactivity = this.Myactivity;
			this.StatusName.get_Text().Trim();
			this.readConfigValues();
			string verifyServer = GlobalVariables.VerifyServer;
			string verifyUser = GlobalVariables.VerifyUser;
			string verifyPwd = GlobalVariables.VerifyPwd;
			string verifyDB = GlobalVariables.VerifyDB;
			string verifyTable = GlobalVariables.VerifyTable;
			try
			{
				if (Convert.ToInt16(SmartApp.createWebService().ValidateData(str1, str2)) != 0)
				{
					flag = (!this.ValidateDuplicateEntry() ? false : true);
				}
				else
				{
					MessageBox.Show("Job is not registered", string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
					this.txtJobNo.set_Text("");
					this.txtJobNo.set_Enabled(Conversions.ToBoolean("True"));
					this.txtJobNo.Focus();
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
					flag = false;
				}
			}
			catch (Exception exception1)
			{
				ProjectData.SetProjectError(exception1);
				Exception exception = exception1;
				MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
				return flag;
			}
			return flag;
		}

		private bool ValidateBusyTable()
		{
			bool flag;
			string text = this.lblTableId.get_Text();
			flag = (Convert.ToInt32(SmartApp.createWebService().CheckTableIsBusy(text)) < 1 ? true : false);
			return flag;
		}

		private bool ValidateDuplicateEntry()
		{
			bool flag = false;
			string text = this.txtJobNo.get_Text();
			char[] chrArray = new char[] { '/' };
			string[] strArray = text.Split(chrArray);
			string str = this.txtCoreNo.get_Text();
			chrArray = new char[] { '/' };
			string[] strArray1 = str.Split(chrArray);
			this.lblTableId.get_Text();
			string str1 = strArray[0];
			string str2 = strArray[1];
			string str3 = strArray1[0];
			string str4 = strArray1[1];
			string myactivity = this.Myactivity;
			this.StatusName.get_Text().Trim();
			this.readConfigValues();
			string str5 = GlobalVariables.strNetworkAddress;
			string str6 = GlobalVariables.strNetworkUsername;
			string str7 = GlobalVariables.strNetworkPassword;
			string str8 = GlobalVariables.strNetworkDB;
			try
			{
				short num = Convert.ToInt16(SmartApp.createWebService().ValidateDuplicateEntry(str1, str2, str3, str4, myactivity));
				short num1 = Convert.ToInt16(SmartApp.createWebService().DoingEquipmentScrum(str1, str2, str3, str4));
				this.NonConformityDoing = Conversions.ToString(num1);
				if (num > 0)
				{
					MessageBox.Show("Duplicate Entry not allowed", string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
					this.txtJobNo.set_Text("");
					this.txtJobNo.set_Enabled(Conversions.ToBoolean("True"));
					this.txtJobNo.Focus();
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
					flag = false;
				}
				else if (Operators.CompareString(myactivity, "NON CONFORMITY", false) == 0 & Conversions.ToDouble(this.NonConformityDoing) == 0)
				{
					flag = false;
				}
				else if (Operators.CompareString(myactivity, "ASSEMBLY", false) == 0 & Conversions.ToDouble(this.NonConformityDoing) == 0)
				{
					MessageBox.Show("Job is not yet started", string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
					this.txtJobNo.set_Text("");
					this.txtJobNo.set_Enabled(Conversions.ToBoolean("True"));
					this.txtCoreNo.set_Text("");
					this.txtCoreNo.set_Enabled(Conversions.ToBoolean("True"));
					this.txtJobNo.Focus();
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
					flag = false;
				}
				else if (!(Operators.CompareString(myactivity, "CLOSING", false) == 0 & Conversions.ToDouble(this.NonConformityDoing) == 0))
				{
					flag = true;
				}
				else
				{
					MessageBox.Show("Job is not yet started", string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
					this.txtJobNo.set_Text("");
					this.txtJobNo.set_Enabled(Conversions.ToBoolean("True"));
					this.txtCoreNo.set_Text("");
					this.txtCoreNo.set_Enabled(Conversions.ToBoolean("True"));
					this.txtJobNo.Focus();
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
					flag = false;
				}
			}
			catch (Exception exception1)
			{
				ProjectData.SetProjectError(exception1);
				Exception exception = exception1;
				MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
				return flag;
			}
			return flag;
		}

		public void ValidateSteps()
		{
			if (Operators.CompareString(this.activity, "SETUP", false) == 0)
			{
				this.btn2Activity.set_Enabled(Conversions.ToBoolean("True"));
				this.btn1Activity.set_Enabled(false);
			}
			else if (Operators.CompareString(this.activity, "ASSEMBLY", false) == 0)
			{
				this.btn3Activity.set_Enabled(Conversions.ToBoolean("True"));
				this.btn2Activity.set_Enabled(Conversions.ToBoolean("False"));
			}
			else if (Operators.CompareString(this.activity, "CLOSING", false) == 0)
			{
				this.btn3Activity.set_Enabled(Conversions.ToBoolean("False"));
				this.btn1Activity.set_Enabled(Conversions.ToBoolean("True"));
			}
			else if (Operators.CompareString(this.activity, "NON CONFORMITY", false) == 0)
			{
				this.btn2Activity.set_Enabled(Conversions.ToBoolean("False"));
				this.btn3Activity.set_Enabled(Conversions.ToBoolean("False"));
				this.btn1Activity.set_Enabled(Conversions.ToBoolean("True"));
			}
		}

		public void writeConfigValuesinXml()
		{
			try
			{
				XmlDocument xmlDocument = new XmlDocument();
				xmlDocument.Load("\\Platform\\Barcode Gulf\\Config.xml");
				XmlNode xmlNode = xmlDocument.SelectSingleNode("Configurations/DepartmentCode");
				XmlNode xmlNode1 = xmlDocument.SelectSingleNode("Configurations/TableId");
				if (xmlNode != null)
				{
					this.txtConfigDepartmentCode.get_Text().Trim();
					xmlNode.set_InnerText(string.Concat("", this.txtConfigDepartmentCode.get_Text().Trim(), ""));
					xmlDocument.Save("\\Platform\\Barcode Gulf\\Config.xml");
				}
				if (xmlNode1 != null)
				{
					this.txtConfigTableId.get_Text().Trim();
					xmlNode1.set_InnerText(string.Concat("", this.txtConfigTableId.get_Text().Trim(), ""));
					xmlDocument.Save("\\Platform\\Barcode Gulf\\Config.xml");
					this.msgConfig.set_Visible(true);
					this.MsgIconConfig.set_Visible(true);
					this.msgConfig.set_Text("Saved Settings Successfully");
				}
			}
			catch (Exception exception)
			{
				ProjectData.SetProjectError(exception);
				throw new Exception("Check Configuration Settings");
			}
		}

		private void WriteInNetwork()
		{
			try
			{
				try
				{
					try
					{
						string str = GlobalVariables.strNetworkAddress;
						string str1 = GlobalVariables.strNetworkUsername;
						string str2 = GlobalVariables.strNetworkPassword;
						string str3 = GlobalVariables.strNetworkDB;
						string text = this.statusJobNo.get_Text();
						char[] chrArray = new char[] { '/' };
						string[] strArray = text.Split(chrArray);
						string str4 = strArray[0];
						string str5 = strArray[1];
						string text1 = this.statusCoreNo.get_Text();
						chrArray = new char[] { '/' };
						string[] strArray1 = text1.Split(chrArray);
						string str6 = strArray1[0];
						string str7 = strArray1[1];
						string str8 = this.StartDate.ToString();
						this.EndDate.ToString();
						DateTime dateTime = DateTime.ParseExact(str8, "dd/MM/yyyy HH:mm:ss", DateTimeFormatInfo.get_InvariantInfo());
						DataTable dataTable = SmartApp.createWebService().CopyDataFromDB(str4, str5);
						if (dataTable.get_Rows().get_Count() > 0)
						{
							this.CustomerNo = Convert.ToString(RuntimeHelpers.GetObjectValue(dataTable.get_Rows().get_Item(0).get_Item("Sell-to Customer No_")));
							this.Description = Convert.ToString(RuntimeHelpers.GetObjectValue(dataTable.get_Rows().get_Item(0).get_Item("Description")));
							this.NetWeight = Convert.ToString(RuntimeHelpers.GetObjectValue(dataTable.get_Rows().get_Item(0).get_Item("Net Weight")));
						}
						this.CustomerName = SmartApp.createWebService().QryCustomerName(str4);
						SmartApp.createWebService().InsertInNetwork(str4, str5, this.CustomerNo, this.CustomerName, this.Description, Conversions.ToInteger(str6), Conversions.ToInteger(str7), this.lblTableId.get_Text(), this.statusActivity.get_Text(), this.BadgeStart, dateTime, Conversions.ToDecimal(this.NoOfOperator), this.lblDepartmentCode.get_Text(), Conversions.ToDecimal(this.NetWeight), this.ThicknessInmm, this.StackInmm, this.Column1MeasureInmm, this.CentralMeasureInmm, this.Column2MeasureInmm);
					}
					catch (Exception exception1)
					{
						ProjectData.SetProjectError(exception1);
						Exception exception = exception1;
						MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
						Application.Exit();
						ProjectData.ClearProjectError();
					}
				}
				finally
				{
				}
				if (Operators.CompareString(this.jobstatus, "START", false) == 0)
				{
					this.StartJob.set_Enabled(false);
					this.tbActivities.set_SelectedIndex(0);
				}
				else if (Operators.CompareString(this.jobstatus, "END", false) == 0)
				{
					this.StartJob.set_Enabled(false);
					this.pcSettings.set_Enabled(true);
					this.pcSettings.set_Visible(true);
					this.tbActivities.set_SelectedIndex(1);
				}
			}
			catch (Exception exception3)
			{
				ProjectData.SetProjectError(exception3);
				Exception exception2 = exception3;
				MessageBox.Show(string.Concat("Error!", exception2.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
				Application.Exit();
				ProjectData.ClearProjectError();
			}
		}

		private void WriteInNetworkForNonConformity()
		{
			this.CheckToDo();
			if (Conversions.ToDouble(this.NonConformityDoing) >= 1)
			{
				try
				{
					try
					{
						string str = GlobalVariables.strNetworkAddress;
						string str1 = GlobalVariables.strNetworkUsername;
						string str2 = GlobalVariables.strNetworkPassword;
						string str3 = GlobalVariables.strNetworkDB;
						string text = this.statusJobNo.get_Text();
						char[] chrArray = new char[] { '/' };
						string[] strArray = text.Split(chrArray);
						string str4 = strArray[0];
						string str5 = strArray[1];
						string text1 = this.statusCoreNo.get_Text();
						chrArray = new char[] { '/' };
						string[] strArray1 = text1.Split(chrArray);
						string str6 = strArray1[0];
						string str7 = strArray1[1];
						string str8 = this.StartDate.ToString();
						this.EndDate.ToString();
						DateTime dateTime = DateTime.ParseExact(str8, "dd/MM/yyyy HH:mm:ss", CultureInfo.get_InvariantCulture());
						string str9 = "0";
						string str10 = "0";
						string str11 = "0";
						string str12 = "0";
						SmartApp.createWebService().InsertWorkInProgressNC(str4, str5, Conversions.ToInteger(str6), str9, this.BadgeStart, dateTime, this.lblDepartmentCode.get_Text(), str10, str11, str12);
					}
					catch (Exception exception1)
					{
						ProjectData.SetProjectError(exception1);
						Exception exception = exception1;
						MessageBox.Show(string.Concat("Error!", exception.ToString()), string.Concat(GlobalVariables.strMessagePrefixWarning, " Scan"), 0, 48, 0);
						Application.Exit();
						ProjectData.ClearProjectError();
					}
				}
				finally
				{
				}
				if (Operators.CompareString(this.jobstatus, "START", false) == 0)
				{
					this.StartJob.set_Enabled(false);
					this.tbActivities.set_SelectedIndex(0);
				}
				else if (Operators.CompareString(this.jobstatus, "END", false) == 0)
				{
					this.StartJob.set_Enabled(false);
					this.pcSettings.set_Enabled(true);
					this.pcSettings.set_Visible(true);
					this.tbActivities.set_SelectedIndex(1);
				}
			}
		}
	}
}