using Microsoft.VisualBasic.CompilerServices;
using ScanApp;
using Symbol;
using Symbol.Barcode;
using Symbol.Exceptions;
using Symbol.Generic;
using Symbol.StandardForms;
using System;
using System.Windows.Forms;

namespace ScanApp.VB_BarcodeSample1
{
	internal class API
	{
		private Symbol.Barcode.Reader myReader;

		private Symbol.Barcode.ReaderData myReaderData;

		private EventHandler myReadNotifyHandler;

		private EventHandler myStatusNotifyHandler;

		public bool isBackground;

		public Symbol.Barcode.Reader Reader
		{
			get
			{
				return this.myReader;
			}
		}

		public API()
		{
			this.myReader = null;
			this.myReaderData = null;
			this.myReadNotifyHandler = null;
			this.myStatusNotifyHandler = null;
			this.isBackground = false;
		}

		public void AttachReadNotify(EventHandler ReadNotifyHandler)
		{
			if (this.myReader != null)
			{
				this.myReader.ReadNotify += ReadNotifyHandler;
				this.myReadNotifyHandler = ReadNotifyHandler;
			}
		}

		public void AttachStatusNotify(EventHandler StatusNotifyHandler)
		{
			if (this.myReader != null)
			{
				this.myReader.StatusNotify += StatusNotifyHandler;
				this.myStatusNotifyHandler = StatusNotifyHandler;
			}
		}

		public void DetachReadNotify()
		{
			if (this.myReader != null & this.myReadNotifyHandler != null)
			{
				this.myReader.ReadNotify -= this.myReadNotifyHandler;
				this.myReadNotifyHandler = null;
			}
		}

		public void DetachStatusNotify()
		{
			if (this.myReader != null & this.myStatusNotifyHandler != null)
			{
				this.myReader.StatusNotify -= this.myStatusNotifyHandler;
				this.myStatusNotifyHandler = null;
			}
		}

		public bool InitReader()
		{
			bool flag;
			string[] str;
			if (this.myReader == null)
			{
				try
				{
					Symbol.Generic.Device device = SelectDevice.Select(Symbol.Barcode.Device.Title, Symbol.Barcode.Device.AvailableDevices);
					if (device != null)
					{
						this.myReader = new Symbol.Barcode.Reader(device);
						this.myReaderData = new Symbol.Barcode.ReaderData(ReaderDataTypes.Text, ReaderDataLengths.MaximumLabel);
						this.myReader.Actions.Enable();
						switch (this.myReader.ReaderParameters.ReaderType)
						{
							case READER_TYPE.READER_TYPE_LASER:
							{
								this.myReader.ReaderParameters.ReaderSpecific.LaserSpecific.AimType = AIM_TYPE.AIM_TYPE_TRIGGER;
								break;
							}
							case READER_TYPE.READER_TYPE_IMAGER:
							{
								this.myReader.ReaderParameters.ReaderSpecific.ImagerSpecific.AimType = AIM_TYPE.AIM_TYPE_TRIGGER;
								break;
							}
						}
						this.myReader.Actions.SetParameters();
					}
					else
					{
						MessageBox.Show(ScanApp.Resources.GetString("NoDeviceSelected"), ScanApp.Resources.GetString("SelectDevice"));
						flag = false;
						return flag;
					}
				}
				catch (OperationFailureException operationFailureException1)
				{
					ProjectData.SetProjectError((Exception)operationFailureException1);
					OperationFailureException operationFailureException = operationFailureException1;
					str = new string[] { ScanApp.Resources.GetString("InitReader"), "\r\n", ScanApp.Resources.GetString("OperationFailure"), "\r\n", operationFailureException.get_Message(), "\r\n", ScanApp.Resources.GetString("Result"), " = ", (Results)((void*)(checked((int)(checked((uint)operationFailureException.Result))))).ToString() };
					MessageBox.Show(string.Concat(str));
					flag = false;
					ProjectData.ClearProjectError();
					return flag;
				}
				catch (InvalidRequestException invalidRequestException1)
				{
					ProjectData.SetProjectError((Exception)invalidRequestException1);
					InvalidRequestException invalidRequestException = invalidRequestException1;
					str = new string[] { ScanApp.Resources.GetString("InitReader"), "\r\n", ScanApp.Resources.GetString("InvalidRequest"), "\r\n", invalidRequestException.get_Message() };
					MessageBox.Show(string.Concat(str));
					flag = false;
					ProjectData.ClearProjectError();
					return flag;
				}
				catch (InvalidIndexerException invalidIndexerException1)
				{
					ProjectData.SetProjectError((Exception)invalidIndexerException1);
					InvalidIndexerException invalidIndexerException = invalidIndexerException1;
					str = new string[] { ScanApp.Resources.GetString("InitReader"), "\r\n", ScanApp.Resources.GetString("InvalidIndexer"), "\r\n", invalidIndexerException.get_Message() };
					MessageBox.Show(string.Concat(str));
					flag = false;
					ProjectData.ClearProjectError();
					return flag;
				}
				flag = true;
			}
			else
			{
				flag = false;
			}
			return flag;
		}

		public void StartRead(bool toggleSoftTrigger)
		{
			string[] str;
			if (this.myReader != null & this.myReaderData != null & !this.isBackground)
			{
				try
				{
					if (!this.myReaderData.IsPending)
					{
						this.myReader.Actions.Read(this.myReaderData);
						if (toggleSoftTrigger & !this.myReader.Info.SoftTrigger)
						{
							this.myReader.Info.SoftTrigger = true;
						}
					}
				}
				catch (OperationFailureException operationFailureException1)
				{
					ProjectData.SetProjectError((Exception)operationFailureException1);
					OperationFailureException operationFailureException = operationFailureException1;
					str = new string[] { ScanApp.Resources.GetString("StartRead"), "\r\n", ScanApp.Resources.GetString("OperationFailure"), "\r\n", operationFailureException.get_Message(), "\r\n", ScanApp.Resources.GetString("Result"), " = ", (Results)((void*)(checked((int)(checked((uint)operationFailureException.Result))))).ToString() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
				catch (InvalidRequestException invalidRequestException1)
				{
					ProjectData.SetProjectError((Exception)invalidRequestException1);
					InvalidRequestException invalidRequestException = invalidRequestException1;
					str = new string[] { ScanApp.Resources.GetString("StartRead"), "\r\n", ScanApp.Resources.GetString("InvalidRequest"), "\r\n", invalidRequestException.get_Message() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
				catch (InvalidIndexerException invalidIndexerException1)
				{
					ProjectData.SetProjectError((Exception)invalidIndexerException1);
					InvalidIndexerException invalidIndexerException = invalidIndexerException1;
					str = new string[] { ScanApp.Resources.GetString("StartRead"), "\r\n", ScanApp.Resources.GetString("InvalidIndexer"), "\r\n", invalidIndexerException.get_Message() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
			}
		}

		public void StopRead()
		{
			string[] str;
			if (this.myReader != null)
			{
				try
				{
					if (this.myReader.Info.SoftTrigger)
					{
						this.myReader.Info.SoftTrigger = false;
					}
					this.myReader.Actions.Flush();
				}
				catch (OperationFailureException operationFailureException1)
				{
					ProjectData.SetProjectError((Exception)operationFailureException1);
					OperationFailureException operationFailureException = operationFailureException1;
					str = new string[] { ScanApp.Resources.GetString("StopRead"), "\r\n", ScanApp.Resources.GetString("OperationFailure"), "\r\n", operationFailureException.get_Message(), "\r\n", ScanApp.Resources.GetString("Result"), " = ", (Results)((void*)(checked((int)(checked((uint)operationFailureException.Result))))).ToString() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
				catch (InvalidRequestException invalidRequestException1)
				{
					ProjectData.SetProjectError((Exception)invalidRequestException1);
					InvalidRequestException invalidRequestException = invalidRequestException1;
					str = new string[] { ScanApp.Resources.GetString("StopRead"), "\r\n", ScanApp.Resources.GetString("InvalidRequest"), "\r\n", invalidRequestException.get_Message() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
				catch (InvalidIndexerException invalidIndexerException1)
				{
					ProjectData.SetProjectError((Exception)invalidIndexerException1);
					InvalidIndexerException invalidIndexerException = invalidIndexerException1;
					str = new string[] { ScanApp.Resources.GetString("StopRead"), "\r\n", ScanApp.Resources.GetString("InvalidIndexer"), "\r\n", invalidIndexerException.get_Message() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
			}
		}

		public void TermReader()
		{
			string[] str;
			if (this.myReader != null)
			{
				try
				{
					this.StopRead();
					this.DetachReadNotify();
					this.DetachStatusNotify();
					this.myReader.Actions.Disable();
					this.myReader.Dispose();
					this.myReader = null;
				}
				catch (OperationFailureException operationFailureException1)
				{
					ProjectData.SetProjectError((Exception)operationFailureException1);
					OperationFailureException operationFailureException = operationFailureException1;
					str = new string[] { ScanApp.Resources.GetString("TermReader"), "\r\n", ScanApp.Resources.GetString("OperationFailure"), "\r\n", operationFailureException.get_Message(), "\r\n", ScanApp.Resources.GetString("Result"), " = ", (Results)((void*)(checked((int)(checked((uint)operationFailureException.Result))))).ToString() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
				catch (InvalidRequestException invalidRequestException1)
				{
					ProjectData.SetProjectError((Exception)invalidRequestException1);
					InvalidRequestException invalidRequestException = invalidRequestException1;
					str = new string[] { ScanApp.Resources.GetString("TermReader"), "\r\n", ScanApp.Resources.GetString("InvalidRequest"), "\r\n", invalidRequestException.get_Message() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
				catch (InvalidIndexerException invalidIndexerException1)
				{
					ProjectData.SetProjectError((Exception)invalidIndexerException1);
					InvalidIndexerException invalidIndexerException = invalidIndexerException1;
					str = new string[] { ScanApp.Resources.GetString("TermReader"), "\r\n", ScanApp.Resources.GetString("InvalidIndexer"), "\r\n", invalidIndexerException.get_Message() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
			}
			if (this.myReaderData != null)
			{
				try
				{
					this.myReaderData.Dispose();
					this.myReaderData = null;
				}
				catch (OperationFailureException operationFailureException3)
				{
					ProjectData.SetProjectError((Exception)operationFailureException3);
					OperationFailureException operationFailureException2 = operationFailureException3;
					str = new string[] { ScanApp.Resources.GetString("TermReader"), "\r\n", ScanApp.Resources.GetString("OperationFailure"), "\r\n", operationFailureException2.get_Message(), "\r\n", ScanApp.Resources.GetString("Result"), " = ", (Results)((void*)(checked((int)(checked((uint)operationFailureException2.Result))))).ToString() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
				catch (InvalidRequestException invalidRequestException3)
				{
					ProjectData.SetProjectError((Exception)invalidRequestException3);
					InvalidRequestException invalidRequestException2 = invalidRequestException3;
					str = new string[] { ScanApp.Resources.GetString("TermReader"), "\r\n", ScanApp.Resources.GetString("InvalidRequest"), "\r\n", invalidRequestException2.get_Message() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
				catch (InvalidIndexerException invalidIndexerException3)
				{
					ProjectData.SetProjectError((Exception)invalidIndexerException3);
					InvalidIndexerException invalidIndexerException2 = invalidIndexerException3;
					str = new string[] { ScanApp.Resources.GetString("TermReader"), "\r\n", ScanApp.Resources.GetString("InvalidIndexer"), "\r\n", invalidIndexerException2.get_Message() };
					MessageBox.Show(string.Concat(str));
					ProjectData.ClearProjectError();
				}
			}
		}
	}
}