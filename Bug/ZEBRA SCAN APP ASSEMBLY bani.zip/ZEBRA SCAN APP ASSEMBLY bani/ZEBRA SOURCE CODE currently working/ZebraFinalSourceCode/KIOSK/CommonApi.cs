﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Job_Book_Zebra_MK500_Micro_Kiosk
{
    class CommonApi
    {
    }
}
