﻿namespace Job_Book_Zebra_MK500_Micro_Kiosk
{
    partial class Phase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxCoreNumber = new System.Windows.Forms.TextBox();
            this.textBoxJobNumber = new System.Windows.Forms.TextBox();
            this.textBoxOperatorBadgeID = new System.Windows.Forms.TextBox();
            this.buttonBack = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxTableID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonScan = new System.Windows.Forms.Button();
            this.buttonEnd = new System.Windows.Forms.Button();
            this.buttonStart = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnEndMyJob = new System.Windows.Forms.Button();
            this.btnStartMyJob = new System.Windows.Forms.Button();
            this.PanelPopup = new System.Windows.Forms.Panel();
            this.scaninalloprators = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoxAddAllOperators = new System.Windows.Forms.TextBox();
            this.lblTeam = new System.Windows.Forms.Label();
            this.lblTableIdinPopupWindow = new System.Windows.Forms.Label();
            this.btnok = new System.Windows.Forms.Button();
            this.panel4.SuspendLayout();
            this.PanelPopup.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxCoreNumber
            // 
            this.textBoxCoreNumber.BackColor = System.Drawing.Color.Gray;
            this.textBoxCoreNumber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.textBoxCoreNumber.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.textBoxCoreNumber.ForeColor = System.Drawing.Color.White;
            this.textBoxCoreNumber.Location = new System.Drawing.Point(124, 92);
            this.textBoxCoreNumber.Multiline = true;
            this.textBoxCoreNumber.Name = "textBoxCoreNumber";
            this.textBoxCoreNumber.Size = new System.Drawing.Size(181, 34);
            this.textBoxCoreNumber.TabIndex = 2;
            this.textBoxCoreNumber.TextChanged += new System.EventHandler(this.textBoxCoreNumber_TextChanged);
            this.textBoxCoreNumber.GotFocus += new System.EventHandler(this.textBoxCoreNumber_GotFocus);
            this.textBoxCoreNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.buttonContinue_KeyDown);
            this.textBoxCoreNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCoreNumber_KeyPress);
            // 
            // textBoxJobNumber
            // 
            this.textBoxJobNumber.BackColor = System.Drawing.Color.Gray;
            this.textBoxJobNumber.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.textBoxJobNumber.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.textBoxJobNumber.ForeColor = System.Drawing.Color.White;
            this.textBoxJobNumber.Location = new System.Drawing.Point(124, 52);
            this.textBoxJobNumber.Multiline = true;
            this.textBoxJobNumber.Name = "textBoxJobNumber";
            this.textBoxJobNumber.Size = new System.Drawing.Size(181, 34);
            this.textBoxJobNumber.TabIndex = 1;
            this.textBoxJobNumber.TextChanged += new System.EventHandler(this.textBoxJobNumber_TextChanged);
            this.textBoxJobNumber.GotFocus += new System.EventHandler(this.textBoxJobNumber_GotFocus);
            this.textBoxJobNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.buttonContinue_KeyDown);
            this.textBoxJobNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxJobNumber_KeyPress);
            // 
            // textBoxOperatorBadgeID
            // 
            this.textBoxOperatorBadgeID.BackColor = System.Drawing.Color.Gray;
            this.textBoxOperatorBadgeID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.textBoxOperatorBadgeID.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.textBoxOperatorBadgeID.ForeColor = System.Drawing.Color.White;
            this.textBoxOperatorBadgeID.Location = new System.Drawing.Point(124, 131);
            this.textBoxOperatorBadgeID.Multiline = true;
            this.textBoxOperatorBadgeID.Name = "textBoxOperatorBadgeID";
            this.textBoxOperatorBadgeID.Size = new System.Drawing.Size(181, 34);
            this.textBoxOperatorBadgeID.TabIndex = 0;
            this.textBoxOperatorBadgeID.TextChanged += new System.EventHandler(this.textBoxOperatorBadgeID_TextChanged);
            this.textBoxOperatorBadgeID.GotFocus += new System.EventHandler(this.textBoxOperatorBadgeId_GotFocus);
            this.textBoxOperatorBadgeID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.buttonContinue_KeyDown);
            // 
            // buttonBack
            // 
            this.buttonBack.BackColor = System.Drawing.Color.Gray;
            this.buttonBack.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.buttonBack.ForeColor = System.Drawing.Color.White;
            this.buttonBack.Location = new System.Drawing.Point(14, 170);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(104, 62);
            this.buttonBack.TabIndex = 6;
            this.buttonBack.TabStop = false;
            this.buttonBack.Text = "Back";
            this.buttonBack.Click += new System.EventHandler(this.button8_Click);
            this.buttonBack.KeyDown += new System.Windows.Forms.KeyEventHandler(this.buttonContinue_KeyDown);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.SeaShell;
            this.label5.Location = new System.Drawing.Point(14, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 20);
            this.label5.Text = "Badge ID";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.SeaShell;
            this.label8.Location = new System.Drawing.Point(14, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 20);
            this.label8.Text = "Job No";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.SeaShell;
            this.label9.Location = new System.Drawing.Point(14, 92);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 20);
            this.label9.Text = "Core No";
            // 
            // textBoxTableID
            // 
            this.textBoxTableID.BackColor = System.Drawing.Color.Gray;
            this.textBoxTableID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.textBoxTableID.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.textBoxTableID.ForeColor = System.Drawing.Color.White;
            this.textBoxTableID.Location = new System.Drawing.Point(124, 12);
            this.textBoxTableID.Multiline = true;
            this.textBoxTableID.Name = "textBoxTableID";
            this.textBoxTableID.Size = new System.Drawing.Size(181, 34);
            this.textBoxTableID.TabIndex = 3;
            this.textBoxTableID.TextChanged += new System.EventHandler(this.textBoxTableID_TextChanged);
            this.textBoxTableID.GotFocus += new System.EventHandler(this.textBoxTableID_GotFocus);
            this.textBoxTableID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.buttonContinue_KeyDown);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.SeaShell;
            this.label1.Location = new System.Drawing.Point(14, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 20);
            this.label1.Text = "Table ID";
            // 
            // buttonScan
            // 
            this.buttonScan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonScan.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.buttonScan.ForeColor = System.Drawing.Color.SeaShell;
            this.buttonScan.Location = new System.Drawing.Point(124, 170);
            this.buttonScan.Name = "buttonScan";
            this.buttonScan.Size = new System.Drawing.Size(181, 62);
            this.buttonScan.TabIndex = 4;
            this.buttonScan.Text = "Scan";
            this.buttonScan.Click += new System.EventHandler(this.buttonScan_Click);
            this.buttonScan.KeyDown += new System.Windows.Forms.KeyEventHandler(this.buttonScan_KeyDown);
            // 
            // buttonEnd
            // 
            this.buttonEnd.BackColor = System.Drawing.Color.Red;
            this.buttonEnd.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.buttonEnd.ForeColor = System.Drawing.Color.SeaShell;
            this.buttonEnd.Location = new System.Drawing.Point(124, 171);
            this.buttonEnd.Name = "buttonEnd";
            this.buttonEnd.Size = new System.Drawing.Size(180, 62);
            this.buttonEnd.TabIndex = 19;
            this.buttonEnd.Text = "End Project";
            this.buttonEnd.Visible = false;
            this.buttonEnd.Click += new System.EventHandler(this.buttonEnd_Click);
            this.buttonEnd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.buttonEnd_KeyDown);
            // 
            // buttonStart
            // 
            this.buttonStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(177)))), ((int)(((byte)(136)))));
            this.buttonStart.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.buttonStart.ForeColor = System.Drawing.Color.SeaShell;
            this.buttonStart.Location = new System.Drawing.Point(124, 170);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(181, 62);
            this.buttonStart.TabIndex = 14;
            this.buttonStart.Text = "Start New Project";
            this.buttonStart.Visible = false;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            this.buttonStart.KeyDown += new System.Windows.Forms.KeyEventHandler(this.buttonStart_KeyDown);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(310, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1, 232);
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(7, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 233);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(7, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(303, 1);
            // 
            // panel5
            // 
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(303, 1);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(8, 235);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(303, 1);
            // 
            // btnEndMyJob
            // 
            this.btnEndMyJob.BackColor = System.Drawing.Color.DarkOrange;
            this.btnEndMyJob.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btnEndMyJob.ForeColor = System.Drawing.Color.SeaShell;
            this.btnEndMyJob.Location = new System.Drawing.Point(124, 170);
            this.btnEndMyJob.Name = "btnEndMyJob";
            this.btnEndMyJob.Size = new System.Drawing.Size(181, 62);
            this.btnEndMyJob.TabIndex = 38;
            this.btnEndMyJob.Text = "Pause My Job";
            this.btnEndMyJob.Visible = false;
            this.btnEndMyJob.Click += new System.EventHandler(this.btnEndMyJob_Click);
            // 
            // btnStartMyJob
            // 
            this.btnStartMyJob.BackColor = System.Drawing.Color.Teal;
            this.btnStartMyJob.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btnStartMyJob.ForeColor = System.Drawing.Color.SeaShell;
            this.btnStartMyJob.Location = new System.Drawing.Point(124, 170);
            this.btnStartMyJob.Name = "btnStartMyJob";
            this.btnStartMyJob.Size = new System.Drawing.Size(181, 62);
            this.btnStartMyJob.TabIndex = 39;
            this.btnStartMyJob.Text = "Start My Job";
            this.btnStartMyJob.Visible = false;
            this.btnStartMyJob.Click += new System.EventHandler(this.btnStartMyJob_Click);
            // 
            // PanelPopup
            // 
            this.PanelPopup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(49)))), ((int)(((byte)(60)))));
            this.PanelPopup.Controls.Add(this.scaninalloprators);
            this.PanelPopup.Controls.Add(this.label3);
            this.PanelPopup.Controls.Add(this.label2);
            this.PanelPopup.Controls.Add(this.txtBoxAddAllOperators);
            this.PanelPopup.Controls.Add(this.lblTeam);
            this.PanelPopup.Controls.Add(this.lblTableIdinPopupWindow);
            this.PanelPopup.Controls.Add(this.btnok);
            this.PanelPopup.Location = new System.Drawing.Point(10, 9);
            this.PanelPopup.Name = "PanelPopup";
            this.PanelPopup.Size = new System.Drawing.Size(298, 223);
            this.PanelPopup.Visible = false;
            this.PanelPopup.GotFocus += new System.EventHandler(this.PanelPopup_GotFocus);
            // 
            // scaninalloprators
            // 
            this.scaninalloprators.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.scaninalloprators.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.scaninalloprators.ForeColor = System.Drawing.Color.SeaShell;
            this.scaninalloprators.Location = new System.Drawing.Point(201, 96);
            this.scaninalloprators.Name = "scaninalloprators";
            this.scaninalloprators.Size = new System.Drawing.Size(84, 45);
            this.scaninalloprators.TabIndex = 45;
            this.scaninalloprators.Text = "Scan";
            this.scaninalloprators.Click += new System.EventHandler(this.scaninalloprators_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Underline);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(81, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 31);
            this.label3.Text = "Add All Operators";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.SeaShell;
            this.label2.Location = new System.Drawing.Point(3, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 20);
            this.label2.Text = "Badge ID";
            // 
            // txtBoxAddAllOperators
            // 
            this.txtBoxAddAllOperators.BackColor = System.Drawing.Color.Gray;
            this.txtBoxAddAllOperators.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtBoxAddAllOperators.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.txtBoxAddAllOperators.ForeColor = System.Drawing.Color.White;
            this.txtBoxAddAllOperators.Location = new System.Drawing.Point(81, 42);
            this.txtBoxAddAllOperators.Multiline = true;
            this.txtBoxAddAllOperators.Name = "txtBoxAddAllOperators";
            this.txtBoxAddAllOperators.Size = new System.Drawing.Size(204, 48);
            this.txtBoxAddAllOperators.TabIndex = 41;
            this.txtBoxAddAllOperators.TextChanged += new System.EventHandler(this.txtBoxAddAllOperators_TextChanged);
            this.txtBoxAddAllOperators.GotFocus += new System.EventHandler(this.txtBoxAddAllOperators_GotFocus);
            this.txtBoxAddAllOperators.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBoxAddAllOperators_KeyDown);
            this.txtBoxAddAllOperators.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxAddAllOperators_KeyPress);
            // 
            // lblTeam
            // 
            this.lblTeam.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold);
            this.lblTeam.ForeColor = System.Drawing.Color.Gold;
            this.lblTeam.Location = new System.Drawing.Point(3, 164);
            this.lblTeam.Name = "lblTeam";
            this.lblTeam.Size = new System.Drawing.Size(282, 56);
            this.lblTeam.Text = "Operators";
            this.lblTeam.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTableIdinPopupWindow
            // 
            this.lblTableIdinPopupWindow.Font = new System.Drawing.Font("Arial", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.lblTableIdinPopupWindow.ForeColor = System.Drawing.Color.Tomato;
            this.lblTableIdinPopupWindow.Location = new System.Drawing.Point(110, 144);
            this.lblTableIdinPopupWindow.Name = "lblTableIdinPopupWindow";
            this.lblTableIdinPopupWindow.Size = new System.Drawing.Size(75, 20);
            this.lblTableIdinPopupWindow.Text = "Table ID";
            this.lblTableIdinPopupWindow.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnok
            // 
            this.btnok.BackColor = System.Drawing.Color.IndianRed;
            this.btnok.Font = new System.Drawing.Font("Vani", 12F, System.Drawing.FontStyle.Regular);
            this.btnok.ForeColor = System.Drawing.Color.SeaShell;
            this.btnok.Location = new System.Drawing.Point(81, 96);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(114, 45);
            this.btnok.TabIndex = 44;
            this.btnok.Text = "OK";
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // Phase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(49)))), ((int)(((byte)(60)))));
            this.ClientSize = new System.Drawing.Size(321, 240);
            this.ControlBox = false;
            this.Controls.Add(this.PanelPopup);
            this.Controls.Add(this.buttonScan);
            this.Controls.Add(this.btnStartMyJob);
            this.Controls.Add(this.btnEndMyJob);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBoxTableID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxCoreNumber);
            this.Controls.Add(this.textBoxJobNumber);
            this.Controls.Add(this.textBoxOperatorBadgeID);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.buttonEnd);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Phase";
            this.Text = "LEGNANO";
            this.Load += new System.EventHandler(this.Phase_Load);
            this.panel4.ResumeLayout(false);
            this.PanelPopup.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxCoreNumber;
        private System.Windows.Forms.TextBox textBoxJobNumber;
        private System.Windows.Forms.TextBox textBoxOperatorBadgeID;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxTableID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonScan;
        private System.Windows.Forms.Button buttonEnd;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnEndMyJob;
        private System.Windows.Forms.Button btnStartMyJob;
        private System.Windows.Forms.Panel PanelPopup;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.TextBox txtBoxAddAllOperators;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTeam;
        private System.Windows.Forms.Label lblTableIdinPopupWindow;
        private System.Windows.Forms.Button scaninalloprators;
    }
}