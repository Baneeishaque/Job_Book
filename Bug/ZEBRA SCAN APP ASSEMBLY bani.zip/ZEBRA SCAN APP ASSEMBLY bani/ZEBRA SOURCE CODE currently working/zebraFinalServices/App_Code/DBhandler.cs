﻿using System;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public class DBhandler
{
    SqlConnection con;   //********Test_LAVROZIONE
    

    public DBhandler()
    {
// Connection to TEST_LAVORAZIONE

        ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["ConnectionString"];
    
        if (settings != null)
        {
            con = new SqlConnection(settings.ConnectionString);
     
        }



    }


    public string SingleInsertUpdate(String query)
    {
        if (con != null)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result == 1)
                {
                    return "1";
                }
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }
        return "1";
    }


    public string CountData(String query)
    {
        if (con != null)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);

                string result = cmd.ExecuteScalar().ToString();
                con.Close();

                if (int.Parse(result) == 0 || result=="")
                {

                    return "0";
                }
                else
                {
                    return "1";
                }

            }
            catch (Exception exception)
            {
                return exception.Message;
            }
           
        }

        else
        {
            return "-1";
        }


    }

    public string MaxData(String query)
    {
        if (con != null)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);

                string result = cmd.ExecuteScalar().ToString();
                con.Close();

               return result;

            }
            catch (Exception exception)
            {
                return exception.Message;
            }
           
        }

        else
        {
            return "-1";
        }


    }


   public string SelectDataFromDB(String query)
    {
        if (con != null)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);

                string result = cmd.ExecuteScalar().ToString();
                con.Close();

               return result;

            }
            catch (Exception exception)
            {
                return "";
            }
           
        }

        else
        {
            return "";
        }


    }




    // Select Data from Bretli_Group_ME

}





