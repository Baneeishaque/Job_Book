﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Data;
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{
    public Service()
    {
    }





                                      /*
                                          * 
                                          *  
                                          * 
                                          *
                                          *
                                          *
                                          *  SERVICE CODE OF  LTC JOB TIME TRACKER SYSTEM FINAL
                                          *
                                          *
                                          *
                                          *
                                          *
                                          *
                                          *
                                          * */






    [WebMethod] // Equipment is table id
    public string InsertJob(string equipment, string employeeID, string jobNumber, string itemNumber, string coreNumber, string coreTotal, string phase,string maxofWorkinprogress,string maxnumberTimeEmployeee,string todopassed,string doingpassed,string donepassed,string firstdataorNot,string Department_Code,string actualPhase,string customerNumber,string customerdescription,string coredescription,string kg,string thickness)
    {
        DBhandler db = new DBhandler();
     //   string dbresult;
       
        
     //  if (dbresult == "1")
    //  {
         
                 //   string maxofWorkinprogress_Converted='000'+maxofWorkinprogress;
                //    string maxnumberTimeEmployeee_Converted='000'+maxnumberTimeEmployeee;
                    decimal kg_converted=decimal.Parse(kg);
                    decimal thickness_Converted=decimal.Parse(thickness);
           string dbresult = db.SingleInsertUpdate("INSERT INTO Equipment_Scrum([Equipment No_],Job, Item, Core, CoreTotal, Phases, Status) VALUES('" + equipment + "', '" + jobNumber + "', '" + itemNumber + "', " + coreNumber + ", " + coreTotal + ", '" + phase + "', 'START')");
            if (dbresult == "1")
                {
         
       

          dbresult = db.SingleInsertUpdate("INSERT INTO WorkInProgress(No_, Job, Item, [Customer No_], [Customer Description], [Core Description], Core, CoreTotal, Location, Operation, [Badge Start], [Date Start], [Badge End], [Date End], [No Operator], [Weight for Unit kg], [Thickness mm], [Stack mm], [Column 1 Measure mm], [Central Measure mm], [Column 2 Measure mm], [Actual Phases],[Department Code])VALUES('" + maxofWorkinprogress + "','" + jobNumber + "','" + itemNumber + "','" + customerNumber + "','" + customerdescription + "','" + coredescription + "','" + coreNumber + "','" + coreTotal + "','" + equipment + "','" + phase + "','" + employeeID + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','',0,1,'"+kg_converted+"','"+thickness_Converted+"',0,0,0,'0','"+actualPhase+"','" + Department_Code + "')");
            //  if (dbresult == "1")
                        //{

                            // dbresult = db.SingleInsertUpdate("INSERT INTO Time_Employee(PK_Time_Employee, FK_WorkInProgress_No_, ID_employee, Time_Start, Time_End)VALUES('" + maxnumberTimeEmployeee + "','" + maxofWorkinprogress + "','" + employeeID + "','" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','')");
                      
                            if (dbresult == "1" && actualPhase !="REPAIR" )
                            {
                                
                                     if(firstdataorNot=="0" ||firstdataorNot=="" )
                                            
                                            {

                                         /*
                                          * 
                                          *  Tha belowm code is only for ,when data inserting to scrum table at the first time
                                          * 
                                          * */

                                                int todoconverted = (int.Parse(coreTotal.ToString())-1);
                                                int doingconverted = 1;
                                                int doneconverted = 0;

                                                dbresult = db.SingleInsertUpdate("INSERT INTO ScrumTable(Job, Item, CoreTotal, ToDo, Doing, Done)VALUES('" + jobNumber + "','" + itemNumber + "','" + coreTotal + "','" + todoconverted + "','" + doingconverted + "','" + doneconverted + "')");

                                            
                                            }
                                            else
        
                                           {
                                             // start 
                                 
                                            int DoingConvertedTo_int=int.Parse(doingpassed.ToString())+1;
                                            int DoneConvertedTo_int=int.Parse(donepassed.ToString());
                                           
                                            int ToDoConvertedTo_int=int.Parse(todopassed.ToString())-1;
                                            dbresult = db.SingleInsertUpdate("UPDATE ScrumTable SET ToDo = '" + ToDoConvertedTo_int + "', Doing='" + DoingConvertedTo_int + "',Done='" + DoneConvertedTo_int + "' WHERE(Job = '" + jobNumber + "' and Item= '" + itemNumber + "' and CoreTotal= '" + coreTotal + "' )");
        
            
                                           }


                                }


                       // }
                 }
          // }
        return dbresult;
    }

    [WebMethod]
    public string UpdateJob(string equipment, string employeeID, string jobNumber,string itemnumber,string CoreNo,string phasepassed,string todopassed,string doingpaased,string donepassed,string coretotalpassed,string actulphase)
    {
        DBhandler db = new DBhandler();

        //TODO : Handle Department table

      // string dbresult = db.SingleInsertUpdate("UPDATE Equipment_Scrum SET Status = 'END' WHERE([Job] = '" + jobNumber + "' and Item ='" + itemnumber + "' and Core ='" + CoreNo + "' )");
      string dbresult = db.SingleInsertUpdate("Delete from Equipment_Scrum WHERE([Job] = '" + jobNumber + "' and Item ='" + itemnumber + "' and Core ='" + CoreNo + "' and Phases ='" + phasepassed + "' )");
     
        if (dbresult == "1")
        {
            dbresult = db.SingleInsertUpdate("UPDATE WorkInProgress SET [Date End] = '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "',[Badge End]= '" + employeeID + "' WHERE(Job = '" + jobNumber + "' and Item = '" + itemnumber + "' and Core ='" + CoreNo + "' and Operation ='" + phasepassed + "' )");
           // if (dbresult == "1")
           // {
               // dbresult = db.SingleInsertUpdate("UPDATE Time_Employee SET Time_End = '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' WHERE(ID_employee = '" + employeeID + "')");
                 if(dbresult == "1" && actulphase!="REPAIR")    
                 {
                 dbresult = db.SingleInsertUpdate("UPDATE ScrumTable SET ToDo = '" + todopassed + "', Doing='" + doingpaased + "',Done='" + donepassed + "' WHERE(Job = '" + jobNumber + "' and Item= '" + itemnumber + "' and CoreTotal= '" + coretotalpassed + "' )");
                 }

           // }

        }

        return dbresult;
    }
    


    [WebMethod]
    public string SelectJobs(string jobNumber, string itemNumber, string employeeID, string coreNumber, string coreTotal, string phase)
    {
        DBhandler db = new DBhandler();

        //TODO : Handle Department table


        string dbresult = db.CountData("SELECT COUNT(*) from WorkInProgress WHERE (Job = '" + jobNumber + "' and Item ='" + itemNumber + "' and Core ='" + coreNumber + "' and Operation ='" + phase + "' and [Badge End]='' and [Actual Phases]!='REPAIR')");

        return dbresult;
    }

 [WebMethod]
    public string Selectmaxofworkinprogressnumber()
    {
        DBhandler db = new DBhandler();

        //TODO : Handle Department table


        string dbresult = db.MaxData("SELECT max(No_) from WorkInProgress");

        return dbresult;
    }
    [WebMethod]
    public string SelectmaxoftimeEmployee()
    {
        DBhandler db = new DBhandler();

        //TODO : Handle Department table


        string dbresult = db.MaxData("SELECT max(PK_Time_Employee) from Time_Employee");

        return dbresult;
    }

      [WebMethod]//for scrum table
    public string SelectNoofWorkinProgress(string jobNumber, string itemNumber, string employeeID, string coreNumber, string coreTotal, string phase)
    {
        DBhandler db = new DBhandler();

        //TODO : Handle Department table


        string dbresult = db.CountData("SELECT COUNT(*) from WorkInProgress WHERE (Job = '" + jobNumber + "' and Item ='" + itemNumber + "' and CoreTotal ='" + coreTotal + "'  and Operation ='" + phase + "' )");

        return dbresult;
    }
 
   
    [WebMethod]
    public string SelectNofRowsinWorkinProgressToupdateDoinginScrumTable(string jobNumber, string itemNumber, string employeeID, string coreNumber, string coreTotal, string phase)
    {
        DBhandler db = new DBhandler();

        //TODO : Handle Department table


        string dbresult = db.MaxData("SELECT COUNT(*) from WorkInProgress WHERE (Job = '" + jobNumber + "' and Item ='" + itemNumber + "' and CoreTotal ='" + coreTotal + "' and Operation ='" + phase + "' and [Badge End]='' and [Actual Phases]!='REPAIR')");
   //     string dbresult = db.MaxData("SELECT COUNT(*) from WorkInProgress WHERE (Operation ='" + phase + "' and [Badge End]='')");

        return dbresult;
    }
   [WebMethod]
    public string SelectNofRowsinWorkinProgressToupdateDoneinScrumTable(string jobNumber, string itemNumber, string employeeID, string coreNumber, string coreTotal, string phase)
    {
        DBhandler db = new DBhandler();

        //TODO : Handle Department table



        string dbresult = db.MaxData("SELECT COUNT(*) from WorkInProgress WHERE (Job = '" + jobNumber + "' and Item ='" + itemNumber + "' and CoreTotal ='" + coreTotal + "' and Operation ='" + phase + "' and [Badge End] !='' and [Actual Phases]!='REPAIR')");

        //string dbresult = db.MaxData("SELECT COUNT(*) from WorkInProgress WHERE (Operation ='" + phase + "' and [Badge End] !='')");



        return dbresult;
    }

       [WebMethod]
    public string SelectToCheckTableisAlreadyRunningOrNot_For_JobNumberandCoreNos(string jobNumber, string itemNumber, string employeeID, string coreNumber, string coreTotal, string phase, string tableIDsend )
    {
        DBhandler db = new DBhandler();

        //TODO : Handle Department table



        string dbresult = db.MaxData("SELECT COUNT(*) from Equipment_Scrum WHERE (Job = '" + jobNumber + "' and Item ='" + itemNumber + "' and CoreTotal ='" + coreTotal + "' and Core='" + coreNumber + "' and Phases ='" + phase + "' and [Equipment No_]='" + tableIDsend + "' and Status='START')");

        //string dbresult = db.MaxData("SELECT COUNT(*) from WorkInProgress WHERE (Operation ='" + phase + "' and [Badge End] !='')");

        return dbresult;
    }
       [WebMethod]
public string SelectToCheckTableisAlreadyRunningOrNot_Without_JobNumberAndCoreNumber(string jobNumber, string itemNumber, string employeeID, string coreNumber, string coreTotal, string phase, string tableIDsend )
    {
        DBhandler db = new DBhandler();

        //TODO : Handle Department table



        string dbresult = db.MaxData("SELECT COUNT(*) from Equipment_Scrum WHERE ([Equipment No_]='" + tableIDsend + "' and Status='START')");

        //string dbresult = db.MaxData("SELECT COUNT(*) from WorkInProgress WHERE (Operation ='" + phase + "' and [Badge End] !='')");

        return dbresult;
    }




       [WebMethod]
       public string SelectDetails_Department_Code(string TblIDSend)
       {
           DBhandler db = new DBhandler();

           //TODO : Handle Department table

           // string dbresult = db.SingleInsertUpdate("UPDATE Equipment_Scrum SET Status = 'END' WHERE([Job] = '" + jobNumber + "' and Item ='" + itemnumber + "' and Core ='" + CoreNo + "' )");
           string dbresult = db.SelectDataFromDB("select [Department No_] from Equipment WHERE([Equipment No_] = '" + TblIDSend + "')");

           return dbresult;
       }
      
       [WebMethod]
       public string Select_TableID_Scrum_Table_Already_Started_job(string jobsend,string itemSend,string coreSend,string phaseSend)
       {
           DBhandler db = new DBhandler();

           //TODO : Handle Department table

           // string dbresult = db.SingleInsertUpdate("UPDATE Equipment_Scrum SET Status = 'END' WHERE([Job] = '" + jobNumber + "' and Item ='" + itemnumber + "' and Core ='" + CoreNo + "' )");
           string dbresult = db.SelectDataFromDB("select [Equipment No_] from Equipment_Scrum WHERE([Job] = '" + jobsend + "' and Item='"+itemSend+"' and Core='"+coreSend+"' and Status='START' and Phases='"+phaseSend+"')");

           return dbresult;
       }


          [WebMethod]//for scrum table
    public string Select_For_Repair_Button(string jobNumber, string itemNumber, string employeeID, string coreNumber, string coreTotal, string phase)
    {
        DBhandler db = new DBhandler();

        //TODO : Handle Department table


        string dbresult = db.MaxData("SELECT COUNT(*) from WorkInProgress WHERE (Job = '" + jobNumber + "' and Item ='" + itemNumber + "' and Core='" + coreNumber + "' and CoreTotal ='" + coreTotal + "' and Operation ='" + phase + "' )");

        return dbresult;
    }
 


    //  bretli me db




}
