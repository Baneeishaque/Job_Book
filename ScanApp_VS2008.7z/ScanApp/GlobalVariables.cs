﻿using System;
using Microsoft.VisualBasic.CompilerServices;

namespace ScanApp
{
	// Token: 0x02000007 RID: 7
	[StandardModule]
	internal sealed class GlobalVariables
	{
		// Token: 0x0400000C RID: 12
		public static string strNetworkAddress = "";

		// Token: 0x0400000D RID: 13
		public static string strNetworkDB = "";

		// Token: 0x0400000E RID: 14
		public static string strNetworkUsername = "";

		// Token: 0x0400000F RID: 15
		public static string strNetworkPassword = "";

		// Token: 0x04000010 RID: 16
		public static string strConnectionString = "";

		// Token: 0x04000011 RID: 17
		public static string strDepartmentCode = "";

		// Token: 0x04000012 RID: 18
		public static string strTableId = "";

		// Token: 0x04000013 RID: 19
		public static string strSpreadSheetLocation = "";

		// Token: 0x04000014 RID: 20
		public static string VerifyServer = "";

		// Token: 0x04000015 RID: 21
		public static string VerifyDB = "";

		// Token: 0x04000016 RID: 22
		public static string VerifyTable = "";

		// Token: 0x04000017 RID: 23
		public static string CopyTable = "";

		// Token: 0x04000018 RID: 24
		public static string VerifyUser = "";

		// Token: 0x04000019 RID: 25
		public static string VerifyPwd = "";

		// Token: 0x0400001A RID: 26
		public static string WebServiceURL = "";

		// Token: 0x0400001B RID: 27
		public static string strMessagePrefixWarning = "Warning : ";

		// Token: 0x0400001C RID: 28
		public static string strMessagePrefixError = "Error : ";

		// Token: 0x0400001D RID: 29
		public static string strMessagePrefixInfo = "Info : ";

		// Token: 0x0400001E RID: 30
		public static string strBarcodeNumber = "";
	}
}
