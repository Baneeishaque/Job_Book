﻿using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Web.Services;
using System.Web.Services.Description;
using System.Web.Services.Protocols;
using Microsoft.VisualBasic.CompilerServices;

namespace ScanApp.LegnanoService
{
	// Token: 0x0200000B RID: 11
	[DesignerCategory("code")]
	[WebServiceBinding(Name = "Service1Soap", Namespace = "http://tempuri.org/")]
	[DebuggerStepThrough]
	public class Service1 : SoapHttpClientProtocol
	{
		// Token: 0x0600015D RID: 349 RVA: 0x000112D0 File Offset: 0x0000F6D0
		public Service1()
		{
			this.Url = "http://localhost/WSLegnanoConnectionService/Service1.asmx";
		}

		// Token: 0x0600015E RID: 350 RVA: 0x000112E8 File Offset: 0x0000F6E8
		[SoapDocumentMethod("http://tempuri.org/GetServerDateTime", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string GetServerDateTime()
		{
			object[] array = this.Invoke("GetServerDateTime", new object[0]);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x0600015F RID: 351 RVA: 0x00011314 File Offset: 0x0000F714
		public IAsyncResult BeginGetServerDateTime(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("GetServerDateTime", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000160 RID: 352 RVA: 0x00011340 File Offset: 0x0000F740
		public string EndGetServerDateTime(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x06000161 RID: 353 RVA: 0x00011364 File Offset: 0x0000F764
		[SoapDocumentMethod("http://tempuri.org/HelloWorld", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string HelloWorld()
		{
			object[] array = this.Invoke("HelloWorld", new object[0]);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x06000162 RID: 354 RVA: 0x00011390 File Offset: 0x0000F790
		public IAsyncResult BeginHelloWorld(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("HelloWorld", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000163 RID: 355 RVA: 0x000113BC File Offset: 0x0000F7BC
		public string EndHelloWorld(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x06000164 RID: 356 RVA: 0x000113E0 File Offset: 0x0000F7E0
		[SoapDocumentMethod("http://tempuri.org/openMK500Connection", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public void openMK500Connection()
		{
			this.Invoke("openMK500Connection", new object[0]);
		}

		// Token: 0x06000165 RID: 357 RVA: 0x000113F8 File Offset: 0x0000F7F8
		public IAsyncResult BeginopenMK500Connection(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("openMK500Connection", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000166 RID: 358 RVA: 0x00011424 File Offset: 0x0000F824
		public void EndopenMK500Connection(IAsyncResult asyncResult)
		{
			this.EndInvoke(asyncResult);
		}

		// Token: 0x06000167 RID: 359 RVA: 0x00011430 File Offset: 0x0000F830
		[SoapDocumentMethod("http://tempuri.org/closeMK500Connection", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public void closeMK500Connection()
		{
			this.Invoke("closeMK500Connection", new object[0]);
		}

		// Token: 0x06000168 RID: 360 RVA: 0x00011448 File Offset: 0x0000F848
		public IAsyncResult BegincloseMK500Connection(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("closeMK500Connection", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000169 RID: 361 RVA: 0x00011474 File Offset: 0x0000F874
		public void EndcloseMK500Connection(IAsyncResult asyncResult)
		{
			this.EndInvoke(asyncResult);
		}

		// Token: 0x0600016A RID: 362 RVA: 0x00011480 File Offset: 0x0000F880
		[SoapDocumentMethod("http://tempuri.org/TestFirstDBConnection", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public bool TestFirstDBConnection()
		{
			object[] array = this.Invoke("TestFirstDBConnection", new object[0]);
			return Conversions.ToBoolean(array[0]);
		}

		// Token: 0x0600016B RID: 363 RVA: 0x000114AC File Offset: 0x0000F8AC
		public IAsyncResult BeginTestFirstDBConnection(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("TestFirstDBConnection", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x0600016C RID: 364 RVA: 0x000114D8 File Offset: 0x0000F8D8
		public bool EndTestFirstDBConnection(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToBoolean(array[0]);
		}

		// Token: 0x0600016D RID: 365 RVA: 0x000114FC File Offset: 0x0000F8FC
		[SoapDocumentMethod("http://tempuri.org/TestSecondDBConnection", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public bool TestSecondDBConnection()
		{
			object[] array = this.Invoke("TestSecondDBConnection", new object[0]);
			return Conversions.ToBoolean(array[0]);
		}

		// Token: 0x0600016E RID: 366 RVA: 0x00011528 File Offset: 0x0000F928
		public IAsyncResult BeginTestSecondDBConnection(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("TestSecondDBConnection", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x0600016F RID: 367 RVA: 0x00011554 File Offset: 0x0000F954
		public bool EndTestSecondDBConnection(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToBoolean(array[0]);
		}

		// Token: 0x06000170 RID: 368 RVA: 0x00011578 File Offset: 0x0000F978
		[SoapDocumentMethod("http://tempuri.org/InitializeTransaction", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public void InitializeTransaction()
		{
			this.Invoke("InitializeTransaction", new object[0]);
		}

		// Token: 0x06000171 RID: 369 RVA: 0x00011590 File Offset: 0x0000F990
		public IAsyncResult BeginInitializeTransaction(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("InitializeTransaction", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000172 RID: 370 RVA: 0x000115BC File Offset: 0x0000F9BC
		public void EndInitializeTransaction(IAsyncResult asyncResult)
		{
			this.EndInvoke(asyncResult);
		}

		// Token: 0x06000173 RID: 371 RVA: 0x000115C8 File Offset: 0x0000F9C8
		[SoapDocumentMethod("http://tempuri.org/RollbackTransaction", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public void RollbackTransaction()
		{
			this.Invoke("RollbackTransaction", new object[0]);
		}

		// Token: 0x06000174 RID: 372 RVA: 0x000115E0 File Offset: 0x0000F9E0
		public IAsyncResult BeginRollbackTransaction(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("RollbackTransaction", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000175 RID: 373 RVA: 0x0001160C File Offset: 0x0000FA0C
		public void EndRollbackTransaction(IAsyncResult asyncResult)
		{
			this.EndInvoke(asyncResult);
		}

		// Token: 0x06000176 RID: 374 RVA: 0x00011618 File Offset: 0x0000FA18
		[SoapDocumentMethod("http://tempuri.org/CommitTransaction", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public void CommitTransaction()
		{
			this.Invoke("CommitTransaction", new object[0]);
		}

		// Token: 0x06000177 RID: 375 RVA: 0x00011630 File Offset: 0x0000FA30
		public IAsyncResult BeginCommitTransaction(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("CommitTransaction", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000178 RID: 376 RVA: 0x0001165C File Offset: 0x0000FA5C
		public void EndCommitTransaction(IAsyncResult asyncResult)
		{
			this.EndInvoke(asyncResult);
		}

		// Token: 0x06000179 RID: 377 RVA: 0x00011668 File Offset: 0x0000FA68
		[SoapDocumentMethod("http://tempuri.org/CheckRecords", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string CheckRecords(string Job, string Item, int CoreTotal)
		{
			object[] array = this.Invoke("CheckRecords", new object[]
			{
				Job,
				Item,
				CoreTotal
			});
			return Conversions.ToString(array[0]);
		}

		// Token: 0x0600017A RID: 378 RVA: 0x000116AC File Offset: 0x0000FAAC
		public IAsyncResult BeginCheckRecords(string Job, string Item, int CoreTotal, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("CheckRecords", new object[]
			{
				Job,
				Item,
				CoreTotal
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x0600017B RID: 379 RVA: 0x000116F0 File Offset: 0x0000FAF0
		public string EndCheckRecords(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x0600017C RID: 380 RVA: 0x00011714 File Offset: 0x0000FB14
		[SoapDocumentMethod("http://tempuri.org/CopyDataFromDB", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public DataTable CopyDataFromDB(string DocumentNo, string Posizione)
		{
			object[] array = this.Invoke("CopyDataFromDB", new object[]
			{
				DocumentNo,
				Posizione
			});
			return (DataTable)array[0];
		}

		// Token: 0x0600017D RID: 381 RVA: 0x0001174C File Offset: 0x0000FB4C
		public IAsyncResult BeginCopyDataFromDB(string DocumentNo, string Posizione, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("CopyDataFromDB", new object[]
			{
				DocumentNo,
				Posizione
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x0600017E RID: 382 RVA: 0x00011784 File Offset: 0x0000FB84
		public DataTable EndCopyDataFromDB(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return (DataTable)array[0];
		}

		// Token: 0x0600017F RID: 383 RVA: 0x000117A8 File Offset: 0x0000FBA8
		[SoapDocumentMethod("http://tempuri.org/DeleteFinishedEquipmentScrum", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object DeleteFinishedEquipmentScrum(string Job, string Item, string Core, string CoreTotal)
		{
			object[] array = this.Invoke("DeleteFinishedEquipmentScrum", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal
			});
			return array[0];
		}

		// Token: 0x06000180 RID: 384 RVA: 0x000117E8 File Offset: 0x0000FBE8
		public IAsyncResult BeginDeleteFinishedEquipmentScrum(string Job, string Item, string Core, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("DeleteFinishedEquipmentScrum", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000181 RID: 385 RVA: 0x0001182C File Offset: 0x0000FC2C
		public object EndDeleteFinishedEquipmentScrum(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x06000182 RID: 386 RVA: 0x0001184C File Offset: 0x0000FC4C
		[SoapDocumentMethod("http://tempuri.org/DeleteItemInWP", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object DeleteItemInWP(string Job, string Item, string Core, string CoreTotal)
		{
			object[] array = this.Invoke("DeleteItemInWP", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal
			});
			return array[0];
		}

		// Token: 0x06000183 RID: 387 RVA: 0x0001188C File Offset: 0x0000FC8C
		public IAsyncResult BeginDeleteItemInWP(string Job, string Item, string Core, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("DeleteItemInWP", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000184 RID: 388 RVA: 0x000118D0 File Offset: 0x0000FCD0
		public object EndDeleteItemInWP(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x06000185 RID: 389 RVA: 0x000118F0 File Offset: 0x0000FCF0
		[SoapDocumentMethod("http://tempuri.org/Deletequery", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object Deletequery(string Job, string Item, string Core, string CoreTotal)
		{
			object[] array = this.Invoke("Deletequery", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal
			});
			return array[0];
		}

		// Token: 0x06000186 RID: 390 RVA: 0x00011930 File Offset: 0x0000FD30
		public IAsyncResult BeginDeletequery(string Job, string Item, string Core, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("Deletequery", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000187 RID: 391 RVA: 0x00011974 File Offset: 0x0000FD74
		public object EndDeletequery(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x06000188 RID: 392 RVA: 0x00011994 File Offset: 0x0000FD94
		[SoapDocumentMethod("http://tempuri.org/DoingQuery", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string DoingQuery(string Job, string Item, string CoreTotal)
		{
			object[] array = this.Invoke("DoingQuery", new object[]
			{
				Job,
				Item,
				CoreTotal
			});
			return Conversions.ToString(array[0]);
		}

		// Token: 0x06000189 RID: 393 RVA: 0x000119D4 File Offset: 0x0000FDD4
		public IAsyncResult BeginDoingQuery(string Job, string Item, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("DoingQuery", new object[]
			{
				Job,
				Item,
				CoreTotal
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x0600018A RID: 394 RVA: 0x00011A14 File Offset: 0x0000FE14
		public string EndDoingQuery(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x0600018B RID: 395 RVA: 0x00011A38 File Offset: 0x0000FE38
		[SoapDocumentMethod("http://tempuri.org/Donequery", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string Donequery(string Job, string Item, string CoreTotal)
		{
			object[] array = this.Invoke("Donequery", new object[]
			{
				Job,
				Item,
				CoreTotal
			});
			return Conversions.ToString(array[0]);
		}

		// Token: 0x0600018C RID: 396 RVA: 0x00011A78 File Offset: 0x0000FE78
		public IAsyncResult BeginDonequery(string Job, string Item, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("Donequery", new object[]
			{
				Job,
				Item,
				CoreTotal
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x0600018D RID: 397 RVA: 0x00011AB8 File Offset: 0x0000FEB8
		public string EndDonequery(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x0600018E RID: 398 RVA: 0x00011ADC File Offset: 0x0000FEDC
		[SoapDocumentMethod("http://tempuri.org/InsertInNetwork", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object InsertInNetwork(string Job, string Item, string CustomerNo, string CustomerDescription, string CoreDescription, int Core, int CoreTotal, string Location, string Operation, string BadgeStart, DateTime myStartDate, decimal NoOfOperator, string DepartmentCode, decimal Weight, decimal Thickness, decimal Stackmm, decimal Column1MeasureInmm, decimal CentralMeasuremm, decimal Column2MeasureInmm)
		{
			object[] array = this.Invoke("InsertInNetwork", new object[]
			{
				Job,
				Item,
				CustomerNo,
				CustomerDescription,
				CoreDescription,
				Core,
				CoreTotal,
				Location,
				Operation,
				BadgeStart,
				myStartDate,
				NoOfOperator,
				DepartmentCode,
				Weight,
				Thickness,
				Stackmm,
				Column1MeasureInmm,
				CentralMeasuremm,
				Column2MeasureInmm
			});
			return array[0];
		}

		// Token: 0x0600018F RID: 399 RVA: 0x00011BB4 File Offset: 0x0000FFB4
		public IAsyncResult BeginInsertInNetwork(string Job, string Item, string CustomerNo, string CustomerDescription, string CoreDescription, int Core, int CoreTotal, string Location, string Operation, string BadgeStart, DateTime myStartDate, decimal NoOfOperator, string DepartmentCode, decimal Weight, decimal Thickness, decimal Stackmm, decimal Column1MeasureInmm, decimal CentralMeasuremm, decimal Column2MeasureInmm, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("InsertInNetwork", new object[]
			{
				Job,
				Item,
				CustomerNo,
				CustomerDescription,
				CoreDescription,
				Core,
				CoreTotal,
				Location,
				Operation,
				BadgeStart,
				myStartDate,
				NoOfOperator,
				DepartmentCode,
				Weight,
				Thickness,
				Stackmm,
				Column1MeasureInmm,
				CentralMeasuremm,
				Column2MeasureInmm
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000190 RID: 400 RVA: 0x00011C90 File Offset: 0x00010090
		public object EndInsertInNetwork(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x06000191 RID: 401 RVA: 0x00011CB0 File Offset: 0x000100B0
		[SoapDocumentMethod("http://tempuri.org/GetCustomDate", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string GetCustomDate()
		{
			object[] array = this.Invoke("GetCustomDate", new object[0]);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x06000192 RID: 402 RVA: 0x00011CDC File Offset: 0x000100DC
		public IAsyncResult BeginGetCustomDate(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("GetCustomDate", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000193 RID: 403 RVA: 0x00011D08 File Offset: 0x00010108
		public string EndGetCustomDate(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x06000194 RID: 404 RVA: 0x00011D2C File Offset: 0x0001012C
		[SoapDocumentMethod("http://tempuri.org/InsertEquipmentScrum", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object InsertEquipmentScrum(string EquipmentNo, string Job, string Item, int Core, int CoreTotal, string Phases, string Status)
		{
			object[] array = this.Invoke("InsertEquipmentScrum", new object[]
			{
				EquipmentNo,
				Job,
				Item,
				Core,
				CoreTotal,
				Phases,
				Status
			});
			return array[0];
		}

		// Token: 0x06000195 RID: 405 RVA: 0x00011D88 File Offset: 0x00010188
		public IAsyncResult BeginInsertEquipmentScrum(string EquipmentNo, string Job, string Item, int Core, int CoreTotal, string Phases, string Status, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("InsertEquipmentScrum", new object[]
			{
				EquipmentNo,
				Job,
				Item,
				Core,
				CoreTotal,
				Phases,
				Status
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000196 RID: 406 RVA: 0x00011DE8 File Offset: 0x000101E8
		public object EndInsertEquipmentScrum(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x06000197 RID: 407 RVA: 0x00011E08 File Offset: 0x00010208
		[SoapDocumentMethod("http://tempuri.org/InsertScrumTable", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object InsertScrumTable(string Job, string Item, int CoreTotal, int ToDo, int Doing, int Done)
		{
			object[] array = this.Invoke("InsertScrumTable", new object[]
			{
				Job,
				Item,
				CoreTotal,
				ToDo,
				Doing,
				Done
			});
			return array[0];
		}

		// Token: 0x06000198 RID: 408 RVA: 0x00011E68 File Offset: 0x00010268
		public IAsyncResult BeginInsertScrumTable(string Job, string Item, int CoreTotal, int ToDo, int Doing, int Done, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("InsertScrumTable", new object[]
			{
				Job,
				Item,
				CoreTotal,
				ToDo,
				Doing,
				Done
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x06000199 RID: 409 RVA: 0x00011ECC File Offset: 0x000102CC
		public object EndInsertScrumTable(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x0600019A RID: 410 RVA: 0x00011EEC File Offset: 0x000102EC
		[SoapDocumentMethod("http://tempuri.org/CheckTableIsBusy", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string CheckTableIsBusy(string EquipmentNo)
		{
			object[] array = this.Invoke("CheckTableIsBusy", new object[]
			{
				EquipmentNo
			});
			return Conversions.ToString(array[0]);
		}

		// Token: 0x0600019B RID: 411 RVA: 0x00011F20 File Offset: 0x00010320
		public IAsyncResult BeginCheckTableIsBusy(string EquipmentNo, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("CheckTableIsBusy", new object[]
			{
				EquipmentNo
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x0600019C RID: 412 RVA: 0x00011F54 File Offset: 0x00010354
		public string EndCheckTableIsBusy(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x0600019D RID: 413 RVA: 0x00011F78 File Offset: 0x00010378
		[SoapDocumentMethod("http://tempuri.org/OnGoingCount", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object OnGoingCount(string Job, string Item, int Core, int CoreTotal)
		{
			object[] array = this.Invoke("OnGoingCount", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal
			});
			return array[0];
		}

		// Token: 0x0600019E RID: 414 RVA: 0x00011FC0 File Offset: 0x000103C0
		public IAsyncResult BeginOnGoingCount(string Job, string Item, int Core, int CoreTotal, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("OnGoingCount", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x0600019F RID: 415 RVA: 0x00012010 File Offset: 0x00010410
		public object EndOnGoingCount(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x060001A0 RID: 416 RVA: 0x00012030 File Offset: 0x00010430
		[SoapDocumentMethod("http://tempuri.org/CreateNoForWorkInProgress", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string CreateNoForWorkInProgress()
		{
			object[] array = this.Invoke("CreateNoForWorkInProgress", new object[0]);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001A1 RID: 417 RVA: 0x0001205C File Offset: 0x0001045C
		public IAsyncResult BeginCreateNoForWorkInProgress(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("CreateNoForWorkInProgress", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001A2 RID: 418 RVA: 0x00012088 File Offset: 0x00010488
		public string EndCreateNoForWorkInProgress(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001A3 RID: 419 RVA: 0x000120AC File Offset: 0x000104AC
		[SoapDocumentMethod("http://tempuri.org/CreateNoForWorkInProgressNC", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string CreateNoForWorkInProgressNC()
		{
			object[] array = this.Invoke("CreateNoForWorkInProgressNC", new object[0]);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001A4 RID: 420 RVA: 0x000120D8 File Offset: 0x000104D8
		public IAsyncResult BeginCreateNoForWorkInProgressNC(AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("CreateNoForWorkInProgressNC", new object[0], callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001A5 RID: 421 RVA: 0x00012104 File Offset: 0x00010504
		public string EndCreateNoForWorkInProgressNC(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001A6 RID: 422 RVA: 0x00012128 File Offset: 0x00010528
		[SoapDocumentMethod("http://tempuri.org/InsertWorkInProgressNC", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object InsertWorkInProgressNC(string Job, string Item, int Core, string SubOperation, string BadgeStart, DateTime myStartDate, string DepartmentCode, string DescriptionStart, string DescriptionEnd, string Block)
		{
			object[] array = this.Invoke("InsertWorkInProgressNC", new object[]
			{
				Job,
				Item,
				Core,
				SubOperation,
				BadgeStart,
				myStartDate,
				DepartmentCode,
				DescriptionStart,
				DescriptionEnd,
				Block
			});
			return array[0];
		}

		// Token: 0x060001A7 RID: 423 RVA: 0x00012198 File Offset: 0x00010598
		public IAsyncResult BeginInsertWorkInProgressNC(string Job, string Item, int Core, string SubOperation, string BadgeStart, DateTime myStartDate, string DepartmentCode, string DescriptionStart, string DescriptionEnd, string Block, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("InsertWorkInProgressNC", new object[]
			{
				Job,
				Item,
				Core,
				SubOperation,
				BadgeStart,
				myStartDate,
				DepartmentCode,
				DescriptionStart,
				DescriptionEnd,
				Block
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001A8 RID: 424 RVA: 0x0001220C File Offset: 0x0001060C
		public object EndInsertWorkInProgressNC(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x060001A9 RID: 425 RVA: 0x0001222C File Offset: 0x0001062C
		[SoapDocumentMethod("http://tempuri.org/InsertWorkInProgress", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object InsertWorkInProgress(string Job, string Item, int Core, int CoreTotal, string Location, string Operation, string BadgeStart, DateTime myStartDate, decimal NoOfOperator, string DepartmentCode, decimal Stackmm, decimal Column1MeasureInmm, decimal CentralMeasuremm, decimal Column2MeasureInmm)
		{
			object[] array = this.Invoke("InsertWorkInProgress", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal,
				Location,
				Operation,
				BadgeStart,
				myStartDate,
				NoOfOperator,
				DepartmentCode,
				Stackmm,
				Column1MeasureInmm,
				CentralMeasuremm,
				Column2MeasureInmm
			});
			return array[0];
		}

		// Token: 0x060001AA RID: 426 RVA: 0x000122D4 File Offset: 0x000106D4
		public IAsyncResult BeginInsertWorkInProgress(string Job, string Item, int Core, int CoreTotal, string Location, string Operation, string BadgeStart, DateTime myStartDate, decimal NoOfOperator, string DepartmentCode, decimal Stackmm, decimal Column1MeasureInmm, decimal CentralMeasuremm, decimal Column2MeasureInmm, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("InsertWorkInProgress", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal,
				Location,
				Operation,
				BadgeStart,
				myStartDate,
				NoOfOperator,
				DepartmentCode,
				Stackmm,
				Column1MeasureInmm,
				CentralMeasuremm,
				Column2MeasureInmm
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001AB RID: 427 RVA: 0x00012384 File Offset: 0x00010784
		public object EndInsertWorkInProgress(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x060001AC RID: 428 RVA: 0x000123A4 File Offset: 0x000107A4
		[SoapDocumentMethod("http://tempuri.org/QryCustomerName", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string QryCustomerName(string Job)
		{
			object[] array = this.Invoke("QryCustomerName", new object[]
			{
				Job
			});
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001AD RID: 429 RVA: 0x000123D8 File Offset: 0x000107D8
		public IAsyncResult BeginQryCustomerName(string Job, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("QryCustomerName", new object[]
			{
				Job
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001AE RID: 430 RVA: 0x0001240C File Offset: 0x0001080C
		public string EndQryCustomerName(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001AF RID: 431 RVA: 0x00012430 File Offset: 0x00010830
		[SoapDocumentMethod("http://tempuri.org/ToDoquery", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string ToDoquery(string Job, string Item, string CoreTotal)
		{
			object[] array = this.Invoke("ToDoquery", new object[]
			{
				Job,
				Item,
				CoreTotal
			});
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001B0 RID: 432 RVA: 0x00012470 File Offset: 0x00010870
		public IAsyncResult BeginToDoquery(string Job, string Item, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("ToDoquery", new object[]
			{
				Job,
				Item,
				CoreTotal
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x000124B0 File Offset: 0x000108B0
		public string EndToDoquery(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x000124D4 File Offset: 0x000108D4
		[SoapDocumentMethod("http://tempuri.org/UpdateEquipmentScrum", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object UpdateEquipmentScrum(string EquipmentNo, string Job, string Item, string Core, string CoreTotal, string Phases, string Status)
		{
			object[] array = this.Invoke("UpdateEquipmentScrum", new object[]
			{
				EquipmentNo,
				Job,
				Item,
				Core,
				CoreTotal,
				Phases,
				Status
			});
			return array[0];
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x00012524 File Offset: 0x00010924
		public IAsyncResult BeginUpdateEquipmentScrum(string EquipmentNo, string Job, string Item, string Core, string CoreTotal, string Phases, string Status, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("UpdateEquipmentScrum", new object[]
			{
				EquipmentNo,
				Job,
				Item,
				Core,
				CoreTotal,
				Phases,
				Status
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x0001257C File Offset: 0x0001097C
		public object EndUpdateEquipmentScrum(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x060001B5 RID: 437 RVA: 0x0001259C File Offset: 0x0001099C
		[SoapDocumentMethod("http://tempuri.org/UpdateScrumTable", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object UpdateScrumTable(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done)
		{
			object[] array = this.Invoke("UpdateScrumTable", new object[]
			{
				Job,
				Item,
				CoreTotal,
				ToDo,
				Doing,
				Done
			});
			return array[0];
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x000125F8 File Offset: 0x000109F8
		public IAsyncResult BeginUpdateScrumTable(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("UpdateScrumTable", new object[]
			{
				Job,
				Item,
				CoreTotal,
				ToDo,
				Doing,
				Done
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001B7 RID: 439 RVA: 0x00012658 File Offset: 0x00010A58
		public object EndUpdateScrumTable(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x00012678 File Offset: 0x00010A78
		[SoapDocumentMethod("http://tempuri.org/ValidateData", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string ValidateData(string DocumentNo, string Posizione)
		{
			object[] array = this.Invoke("ValidateData", new object[]
			{
				DocumentNo,
				Posizione
			});
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x000126B0 File Offset: 0x00010AB0
		public IAsyncResult BeginValidateData(string DocumentNo, string Posizione, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("ValidateData", new object[]
			{
				DocumentNo,
				Posizione
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001BA RID: 442 RVA: 0x000126E8 File Offset: 0x00010AE8
		public string EndValidateData(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001BB RID: 443 RVA: 0x0001270C File Offset: 0x00010B0C
		[SoapDocumentMethod("http://tempuri.org/ValidateDuplicateEntry", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string ValidateDuplicateEntry(string Job, string Item, string Core, string CoreTotal, string Operation)
		{
			object[] array = this.Invoke("ValidateDuplicateEntry", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal,
				Operation
			});
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001BC RID: 444 RVA: 0x00012758 File Offset: 0x00010B58
		public IAsyncResult BeginValidateDuplicateEntry(string Job, string Item, string Core, string CoreTotal, string Operation, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("ValidateDuplicateEntry", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal,
				Operation
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001BD RID: 445 RVA: 0x000127A4 File Offset: 0x00010BA4
		public string EndValidateDuplicateEntry(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001BE RID: 446 RVA: 0x000127C8 File Offset: 0x00010BC8
		[SoapDocumentMethod("http://tempuri.org/DoingEquipmentScrum", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string DoingEquipmentScrum(string Job, string Item, string Core, string CoreTotal)
		{
			object[] array = this.Invoke("DoingEquipmentScrum", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal
			});
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001BF RID: 447 RVA: 0x0001280C File Offset: 0x00010C0C
		public IAsyncResult BeginDoingEquipmentScrum(string Job, string Item, string Core, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("DoingEquipmentScrum", new object[]
			{
				Job,
				Item,
				Core,
				CoreTotal
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x00012850 File Offset: 0x00010C50
		public string EndDoingEquipmentScrum(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return Conversions.ToString(array[0]);
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x00012874 File Offset: 0x00010C74
		[SoapDocumentMethod("http://tempuri.org/UpdateScrumTableOnEndClosing", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object UpdateScrumTableOnEndClosing(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done)
		{
			object[] array = this.Invoke("UpdateScrumTableOnEndClosing", new object[]
			{
				Job,
				Item,
				CoreTotal,
				ToDo,
				Doing,
				Done
			});
			return array[0];
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x000128D0 File Offset: 0x00010CD0
		public IAsyncResult BeginUpdateScrumTableOnEndClosing(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("UpdateScrumTableOnEndClosing", new object[]
			{
				Job,
				Item,
				CoreTotal,
				ToDo,
				Doing,
				Done
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x00012930 File Offset: 0x00010D30
		public object EndUpdateScrumTableOnEndClosing(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x00012950 File Offset: 0x00010D50
		[SoapDocumentMethod("http://tempuri.org/UpdateScrumTableOnStartConformity", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object UpdateScrumTableOnStartConformity(string Job, string Item, int ToDo, int Doing, string CoreTotal)
		{
			object[] array = this.Invoke("UpdateScrumTableOnStartConformity", new object[]
			{
				Job,
				Item,
				ToDo,
				Doing,
				CoreTotal
			});
			return array[0];
		}

		// Token: 0x060001C5 RID: 453 RVA: 0x000129A0 File Offset: 0x00010DA0
		public IAsyncResult BeginUpdateScrumTableOnStartConformity(string Job, string Item, int ToDo, int Doing, string CoreTotal, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("UpdateScrumTableOnStartConformity", new object[]
			{
				Job,
				Item,
				ToDo,
				Doing,
				CoreTotal
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001C6 RID: 454 RVA: 0x000129F4 File Offset: 0x00010DF4
		public object EndUpdateScrumTableOnStartConformity(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x00012A14 File Offset: 0x00010E14
		[SoapDocumentMethod("http://tempuri.org/UpdateScrumTableOnStartNonConformity", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object UpdateScrumTableOnStartNonConformity(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done)
		{
			object[] array = this.Invoke("UpdateScrumTableOnStartNonConformity", new object[]
			{
				Job,
				Item,
				CoreTotal,
				ToDo,
				Doing,
				Done
			});
			return array[0];
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x00012A70 File Offset: 0x00010E70
		public IAsyncResult BeginUpdateScrumTableOnStartNonConformity(string Job, string Item, string CoreTotal, int ToDo, int Doing, int Done, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("UpdateScrumTableOnStartNonConformity", new object[]
			{
				Job,
				Item,
				CoreTotal,
				ToDo,
				Doing,
				Done
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x00012AD0 File Offset: 0x00010ED0
		public object EndUpdateScrumTableOnStartNonConformity(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x060001CA RID: 458 RVA: 0x00012AF0 File Offset: 0x00010EF0
		[SoapDocumentMethod("http://tempuri.org/UpdateWorkInProgress", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object UpdateWorkInProgress(string CustomerNo, string CoreDescription, string CustomerDescription, string Thickness, string Weight, string Job, string Item, string Core, string CoreTotal, string Location, string Operation)
		{
			object[] array = this.Invoke("UpdateWorkInProgress", new object[]
			{
				CustomerNo,
				CoreDescription,
				CustomerDescription,
				Thickness,
				Weight,
				Job,
				Item,
				Core,
				CoreTotal,
				Location,
				Operation
			});
			return array[0];
		}

		// Token: 0x060001CB RID: 459 RVA: 0x00012B5C File Offset: 0x00010F5C
		public IAsyncResult BeginUpdateWorkInProgress(string CustomerNo, string CoreDescription, string CustomerDescription, string Thickness, string Weight, string Job, string Item, string Core, string CoreTotal, string Location, string Operation, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("UpdateWorkInProgress", new object[]
			{
				CustomerNo,
				CoreDescription,
				CustomerDescription,
				Thickness,
				Weight,
				Job,
				Item,
				Core,
				CoreTotal,
				Location,
				Operation
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001CC RID: 460 RVA: 0x00012BCC File Offset: 0x00010FCC
		public object EndUpdateWorkInProgress(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x060001CD RID: 461 RVA: 0x00012BEC File Offset: 0x00010FEC
		[SoapDocumentMethod("http://tempuri.org/UpdateWorkInNetwork", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object UpdateWorkInNetwork(string BadgeEnd, DateTime DateEnd, string Job, string Item, int Core, int CoreTotal, string Location, decimal NoOfOperator, string Operation)
		{
			object[] array = this.Invoke("UpdateWorkInNetwork", new object[]
			{
				BadgeEnd,
				DateEnd,
				Job,
				Item,
				Core,
				CoreTotal,
				Location,
				NoOfOperator,
				Operation
			});
			return array[0];
		}

		// Token: 0x060001CE RID: 462 RVA: 0x00012C60 File Offset: 0x00011060
		public IAsyncResult BeginUpdateWorkInNetwork(string BadgeEnd, DateTime DateEnd, string Job, string Item, int Core, int CoreTotal, string Location, decimal NoOfOperator, string Operation, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("UpdateWorkInNetwork", new object[]
			{
				BadgeEnd,
				DateEnd,
				Job,
				Item,
				Core,
				CoreTotal,
				Location,
				NoOfOperator,
				Operation
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001CF RID: 463 RVA: 0x00012CD8 File Offset: 0x000110D8
		public object EndUpdateWorkInNetwork(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x00012CF8 File Offset: 0x000110F8
		[SoapDocumentMethod("http://tempuri.org/UpdateWorkInProgressNC", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public object UpdateWorkInProgressNC(string BadgeEnd, DateTime DateEnd, string Job, string Item, int Core, string BadgeStart, DateTime DateStart)
		{
			object[] array = this.Invoke("UpdateWorkInProgressNC", new object[]
			{
				BadgeEnd,
				DateEnd,
				Job,
				Item,
				Core,
				BadgeStart,
				DateStart
			});
			return array[0];
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x00012D58 File Offset: 0x00011158
		public IAsyncResult BeginUpdateWorkInProgressNC(string BadgeEnd, DateTime DateEnd, string Job, string Item, int Core, string BadgeStart, DateTime DateStart, AsyncCallback callback, object asyncState)
		{
			return this.BeginInvoke("UpdateWorkInProgressNC", new object[]
			{
				BadgeEnd,
				DateEnd,
				Job,
				Item,
				Core,
				BadgeStart,
				DateStart
			}, callback, RuntimeHelpers.GetObjectValue(asyncState));
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x00012DBC File Offset: 0x000111BC
		public object EndUpdateWorkInProgressNC(IAsyncResult asyncResult)
		{
			object[] array = this.EndInvoke(asyncResult);
			return array[0];
		}
	}
}
