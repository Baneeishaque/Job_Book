﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using ScanApp.LegnanoService;

namespace ScanApp.My
{
	// Token: 0x02000002 RID: 2
	[HideModuleName]
	[GeneratedCode("MyTemplate", "8.0.0.0")]
	[StandardModule]
	internal sealed class MyProject
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000002 RID: 2 RVA: 0x0000FACC File Offset: 0x0000DECC
		internal static MyProject.MyForms Forms
		{
			[DebuggerHidden]
			get
			{
				return MyProject.m_MyFormsObjectProvider.GetInstance;
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000003 RID: 3 RVA: 0x0000FAE8 File Offset: 0x0000DEE8
		internal static MyProject.MyWebServices WebServices
		{
			[DebuggerHidden]
			get
			{
				return MyProject.m_MyWebServicesObjectProvider.GetInstance;
			}
		}

		// Token: 0x04000001 RID: 1
		private static MyProject.ThreadSafeObjectProvider<MyProject.MyForms> m_MyFormsObjectProvider = new MyProject.ThreadSafeObjectProvider<MyProject.MyForms>();

		// Token: 0x04000002 RID: 2
		private static readonly MyProject.ThreadSafeObjectProvider<MyProject.MyWebServices> m_MyWebServicesObjectProvider = new MyProject.ThreadSafeObjectProvider<MyProject.MyWebServices>();

		// Token: 0x02000003 RID: 3
		[EditorBrowsable(1)]
		[MyGroupCollection("System.Windows.Forms.Form", "Create__Instance__", "Dispose__Instance__", "My.MyProject.Forms")]
		internal sealed class MyForms
		{
			// Token: 0x17000003 RID: 3
			// (get) Token: 0x06000004 RID: 4 RVA: 0x0000FB04 File Offset: 0x0000DF04
			// (set) Token: 0x06000005 RID: 5 RVA: 0x0000FB2C File Offset: 0x0000DF2C
			public SmartApp SmartApp
			{
				[DebuggerNonUserCode]
				get
				{
					this.m_SmartApp = MyProject.MyForms.Create__Instance__<SmartApp>(this.m_SmartApp);
					return this.m_SmartApp;
				}
				[DebuggerNonUserCode]
				set
				{
					if (value != this.m_SmartApp)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.Dispose__Instance__<SmartApp>(ref this.m_SmartApp);
					}
				}
			}

			// Token: 0x06000006 RID: 6 RVA: 0x0000FB58 File Offset: 0x0000DF58
			[DebuggerHidden]
			private static T Create__Instance__<T>(T Instance) where T : Form, new()
			{
				if (Instance == null)
				{
					if (MyProject.MyForms.m_FormBeingCreated != null)
					{
						if (MyProject.MyForms.m_FormBeingCreated.ContainsKey(typeof(T)))
						{
							throw new InvalidOperationException(Utils.GetResourceString("WinForms_RecursiveFormCreate", new string[0]));
						}
					}
					else
					{
						MyProject.MyForms.m_FormBeingCreated = new Hashtable();
					}
					MyProject.MyForms.m_FormBeingCreated.Add(typeof(T), null);
					try
					{
						return (T)((object)Activator.CreateInstance(typeof(T)));
					}
					catch (TargetInvocationException ex) when (ex.InnerException != null)
					{
						string resourceString = Utils.GetResourceString("WinForms_SeeInnerException", new string[]
						{
							ex.InnerException.Message
						});
						throw new InvalidOperationException(resourceString, ex.InnerException);
					}
					finally
					{
						MyProject.MyForms.m_FormBeingCreated.Remove(typeof(T));
					}
				}
				return Instance;
			}

			// Token: 0x06000007 RID: 7 RVA: 0x0000FC7C File Offset: 0x0000E07C
			[DebuggerHidden]
			private void Dispose__Instance__<T>(ref T instance) where T : Form
			{
				instance.Dispose();
				instance = default(T);
			}

			// Token: 0x06000008 RID: 8 RVA: 0x0000FCA8 File Offset: 0x0000E0A8
			[EditorBrowsable(1)]
			[DebuggerHidden]
			public MyForms()
			{
			}

			// Token: 0x06000009 RID: 9 RVA: 0x0000FCB4 File Offset: 0x0000E0B4
			[EditorBrowsable(1)]
			public override bool Equals(object o)
			{
				return base.Equals(RuntimeHelpers.GetObjectValue(o));
			}

			// Token: 0x0600000A RID: 10 RVA: 0x0000FCD4 File Offset: 0x0000E0D4
			[EditorBrowsable(1)]
			public override int GetHashCode()
			{
				return base.GetHashCode();
			}

			// Token: 0x0600000B RID: 11 RVA: 0x0000FCEC File Offset: 0x0000E0EC
			[EditorBrowsable(1)]
			internal Type GetType()
			{
				return typeof(MyProject.MyForms);
			}

			// Token: 0x0600000C RID: 12 RVA: 0x0000FD08 File Offset: 0x0000E108
			[EditorBrowsable(1)]
			public override string ToString()
			{
				return base.ToString();
			}

			// Token: 0x04000003 RID: 3
			public SmartApp m_SmartApp;

			// Token: 0x04000004 RID: 4
			private static Hashtable m_FormBeingCreated;
		}

		// Token: 0x02000004 RID: 4
		[MyGroupCollection("System.Web.Services.Protocols.SoapHttpClientProtocol", "Create__Instance__", "Dispose__Instance__", "")]
		[EditorBrowsable(1)]
		internal sealed class MyWebServices
		{
			// Token: 0x17000004 RID: 4
			// (get) Token: 0x0600000D RID: 13 RVA: 0x0000FD20 File Offset: 0x0000E120
			// (set) Token: 0x0600000E RID: 14 RVA: 0x0000FD48 File Offset: 0x0000E148
			public Service1 Service1
			{
				[DebuggerNonUserCode]
				get
				{
					this.m_Service1 = MyProject.MyWebServices.Create__Instance__<Service1>(this.m_Service1);
					return this.m_Service1;
				}
				[DebuggerNonUserCode]
				set
				{
					if (value != this.m_Service1)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.Dispose__Instance__<Service1>(ref this.m_Service1);
					}
				}
			}

			// Token: 0x0600000F RID: 15 RVA: 0x0000FD74 File Offset: 0x0000E174
			[DebuggerHidden]
			[EditorBrowsable(1)]
			public override bool Equals(object o)
			{
				return base.Equals(RuntimeHelpers.GetObjectValue(o));
			}

			// Token: 0x06000010 RID: 16 RVA: 0x0000FD94 File Offset: 0x0000E194
			[DebuggerHidden]
			[EditorBrowsable(1)]
			public override int GetHashCode()
			{
				return base.GetHashCode();
			}

			// Token: 0x06000011 RID: 17 RVA: 0x0000FDAC File Offset: 0x0000E1AC
			[DebuggerHidden]
			[EditorBrowsable(1)]
			internal Type GetType()
			{
				return typeof(MyProject.MyWebServices);
			}

			// Token: 0x06000012 RID: 18 RVA: 0x0000FDC8 File Offset: 0x0000E1C8
			[DebuggerHidden]
			[EditorBrowsable(1)]
			public override string ToString()
			{
				return base.ToString();
			}

			// Token: 0x06000013 RID: 19 RVA: 0x0000FDE0 File Offset: 0x0000E1E0
			[DebuggerHidden]
			private static T Create__Instance__<T>(T instance) where T : new()
			{
				T result;
				if (instance == null)
				{
					result = (T)((object)Activator.CreateInstance(typeof(T)));
				}
				else
				{
					result = instance;
				}
				return result;
			}

			// Token: 0x06000014 RID: 20 RVA: 0x0000FE18 File Offset: 0x0000E218
			[DebuggerHidden]
			private void Dispose__Instance__<T>(ref T instance)
			{
				instance = default(T);
			}

			// Token: 0x06000015 RID: 21 RVA: 0x0000FE38 File Offset: 0x0000E238
			[DebuggerHidden]
			[EditorBrowsable(1)]
			public MyWebServices()
			{
			}

			// Token: 0x04000005 RID: 5
			public Service1 m_Service1;
		}

		// Token: 0x02000005 RID: 5
		[ComVisible(false)]
		[EditorBrowsable(1)]
		internal sealed class ThreadSafeObjectProvider<T> where T : new()
		{
			// Token: 0x17000005 RID: 5
			// (get) Token: 0x06000016 RID: 22 RVA: 0x0000FE44 File Offset: 0x0000E244
			internal T GetInstance
			{
				get
				{
					if (this.$STATIC$get_GetInstance$200130$DataSlotName == null || this.$STATIC$get_GetInstance$200130$DataSlotName.Length == 0)
					{
						Random random = new Random();
						this.$STATIC$get_GetInstance$200130$DataSlotName = string.Format(CultureInfo.CurrentCulture, "{0}.Microsoft.VisualBasic.CompilerServices.ProjectData", new object[]
						{
							random.Next()
						});
					}
					LocalDataStoreSlot namedDataSlot = Thread.GetNamedDataSlot(this.$STATIC$get_GetInstance$200130$DataSlotName);
					object objectValue = RuntimeHelpers.GetObjectValue(Thread.GetData(namedDataSlot));
					T t = Conversions.ToGenericParameter<T>(RuntimeHelpers.GetObjectValue(objectValue));
					if (t == null)
					{
						t = (T)((object)Activator.CreateInstance(typeof(T)));
						Thread.SetData(namedDataSlot, t);
					}
					return t;
				}
			}

			// Token: 0x06000017 RID: 23 RVA: 0x0000FEF4 File Offset: 0x0000E2F4
			[DebuggerHidden]
			[EditorBrowsable(1)]
			public ThreadSafeObjectProvider()
			{
			}

			// Token: 0x04000006 RID: 6
			private string $STATIC$get_GetInstance$200130$DataSlotName;
		}
	}
}
