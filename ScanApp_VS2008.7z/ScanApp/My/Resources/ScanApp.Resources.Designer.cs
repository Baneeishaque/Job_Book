﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using Microsoft.VisualBasic.CompilerServices;

namespace ScanApp.My.Resources
{
	// Token: 0x02000009 RID: 9
	[DebuggerNonUserCode]
	[StandardModule]
	internal sealed class Resources
	{
		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000026 RID: 38 RVA: 0x00010B34 File Offset: 0x0000EF34
		[EditorBrowsable(2)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (object.ReferenceEquals(Resources.resourceMan, null))
				{
					ResourceManager resourceManager = new ResourceManager("ScanApp.Resources", typeof(Resources).Assembly);
					Resources.resourceMan = resourceManager;
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000027 RID: 39 RVA: 0x00010B7C File Offset: 0x0000EF7C
		// (set) Token: 0x06000028 RID: 40 RVA: 0x00010B94 File Offset: 0x0000EF94
		[EditorBrowsable(2)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000029 RID: 41 RVA: 0x00010BA0 File Offset: 0x0000EFA0
		internal static string About
		{
			get
			{
				return Resources.ResourceManager.GetString("About", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x0600002A RID: 42 RVA: 0x00010BC8 File Offset: 0x0000EFC8
		internal static string AboutMsg
		{
			get
			{
				return Resources.ResourceManager.GetString("AboutMsg", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x0600002B RID: 43 RVA: 0x00010BF0 File Offset: 0x0000EFF0
		internal static string AimMode
		{
			get
			{
				return Resources.ResourceManager.GetString("AimMode", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x0600002C RID: 44 RVA: 0x00010C18 File Offset: 0x0000F018
		internal static string AimType
		{
			get
			{
				return Resources.ResourceManager.GetString("AimType", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x0600002D RID: 45 RVA: 0x00010C40 File Offset: 0x0000F040
		internal static string AppExitMsg
		{
			get
			{
				return Resources.ResourceManager.GetString("AppExitMsg", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x0600002E RID: 46 RVA: 0x00010C68 File Offset: 0x0000F068
		internal static string Back
		{
			get
			{
				return Resources.ResourceManager.GetString("Back", Resources.resourceCulture);
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x0600002F RID: 47 RVA: 0x00010C90 File Offset: 0x0000F090
		internal static string Background
		{
			get
			{
				return Resources.ResourceManager.GetString("Background", Resources.resourceCulture);
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000030 RID: 48 RVA: 0x00010CB8 File Offset: 0x0000F0B8
		internal static string Code128
		{
			get
			{
				return Resources.ResourceManager.GetString("Code128", Resources.resourceCulture);
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x06000031 RID: 49 RVA: 0x00010CE0 File Offset: 0x0000F0E0
		internal static string Code39
		{
			get
			{
				return Resources.ResourceManager.GetString("Code39", Resources.resourceCulture);
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000032 RID: 50 RVA: 0x00010D08 File Offset: 0x0000F108
		internal static string Data
		{
			get
			{
				return Resources.ResourceManager.GetString("Data", Resources.resourceCulture);
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000033 RID: 51 RVA: 0x00010D30 File Offset: 0x0000F130
		internal static string Decoders
		{
			get
			{
				return Resources.ResourceManager.GetString("Decoders", Resources.resourceCulture);
			}
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000034 RID: 52 RVA: 0x00010D58 File Offset: 0x0000F158
		internal static string Disabled
		{
			get
			{
				return Resources.ResourceManager.GetString("Disabled", Resources.resourceCulture);
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x06000035 RID: 53 RVA: 0x00010D80 File Offset: 0x0000F180
		internal static string Dot
		{
			get
			{
				return Resources.ResourceManager.GetString("Dot", Resources.resourceCulture);
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x06000036 RID: 54 RVA: 0x00010DA8 File Offset: 0x0000F1A8
		internal static string Enabled
		{
			get
			{
				return Resources.ResourceManager.GetString("Enabled", Resources.resourceCulture);
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x06000037 RID: 55 RVA: 0x00010DD0 File Offset: 0x0000F1D0
		internal static string ExitApp
		{
			get
			{
				return Resources.ResourceManager.GetString("ExitApp", Resources.resourceCulture);
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x06000038 RID: 56 RVA: 0x00010DF8 File Offset: 0x0000F1F8
		internal static string Failure
		{
			get
			{
				return Resources.ResourceManager.GetString("Failure", Resources.resourceCulture);
			}
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000039 RID: 57 RVA: 0x00010E20 File Offset: 0x0000F220
		internal static string Foreground
		{
			get
			{
				return Resources.ResourceManager.GetString("Foreground", Resources.resourceCulture);
			}
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x0600003A RID: 58 RVA: 0x00010E48 File Offset: 0x0000F248
		internal static string Hold
		{
			get
			{
				return Resources.ResourceManager.GetString("Hold", Resources.resourceCulture);
			}
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x0600003B RID: 59 RVA: 0x00010E70 File Offset: 0x0000F270
		internal static string InitReader
		{
			get
			{
				return Resources.ResourceManager.GetString("InitReader", Resources.resourceCulture);
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x0600003C RID: 60 RVA: 0x00010E98 File Offset: 0x0000F298
		internal static string InvalidIndexer
		{
			get
			{
				return Resources.ResourceManager.GetString("InvalidIndexer", Resources.resourceCulture);
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x0600003D RID: 61 RVA: 0x00010EC0 File Offset: 0x0000F2C0
		internal static string InvalidRequest
		{
			get
			{
				return Resources.ResourceManager.GetString("InvalidRequest", Resources.resourceCulture);
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x0600003E RID: 62 RVA: 0x00010EE8 File Offset: 0x0000F2E8
		internal static string Item
		{
			get
			{
				return Resources.ResourceManager.GetString("Item", Resources.resourceCulture);
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x0600003F RID: 63 RVA: 0x00010F10 File Offset: 0x0000F310
		internal static string ItemNotSelected
		{
			get
			{
				return Resources.ResourceManager.GetString("ItemNotSelected", Resources.resourceCulture);
			}
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000040 RID: 64 RVA: 0x00010F38 File Offset: 0x0000F338
		internal static string Length
		{
			get
			{
				return Resources.ResourceManager.GetString("Length", Resources.resourceCulture);
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000041 RID: 65 RVA: 0x00010F60 File Offset: 0x0000F360
		internal static string Monitor
		{
			get
			{
				return Resources.ResourceManager.GetString("Monitor", Resources.resourceCulture);
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x06000042 RID: 66 RVA: 0x00010F88 File Offset: 0x0000F388
		internal static string NoDeviceSelected
		{
			get
			{
				return Resources.ResourceManager.GetString("NoDeviceSelected", Resources.resourceCulture);
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x06000043 RID: 67 RVA: 0x00010FB0 File Offset: 0x0000F3B0
		internal static string None
		{
			get
			{
				return Resources.ResourceManager.GetString("None", Resources.resourceCulture);
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x06000044 RID: 68 RVA: 0x00010FD8 File Offset: 0x0000F3D8
		internal static string OperationFailure
		{
			get
			{
				return Resources.ResourceManager.GetString("OperationFailure", Resources.resourceCulture);
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x06000045 RID: 69 RVA: 0x00011000 File Offset: 0x0000F400
		internal static string Options
		{
			get
			{
				return Resources.ResourceManager.GetString("Options", Resources.resourceCulture);
			}
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x06000046 RID: 70 RVA: 0x00011028 File Offset: 0x0000F428
		internal static string Release
		{
			get
			{
				return Resources.ResourceManager.GetString("Release", Resources.resourceCulture);
			}
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x06000047 RID: 71 RVA: 0x00011050 File Offset: 0x0000F450
		internal static string Result
		{
			get
			{
				return Resources.ResourceManager.GetString("Result", Resources.resourceCulture);
			}
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x06000048 RID: 72 RVA: 0x00011078 File Offset: 0x0000F478
		internal static string Reticle
		{
			get
			{
				return Resources.ResourceManager.GetString("Reticle", Resources.resourceCulture);
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x06000049 RID: 73 RVA: 0x000110A0 File Offset: 0x0000F4A0
		internal static string Scan
		{
			get
			{
				return Resources.ResourceManager.GetString("Scan", Resources.resourceCulture);
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x0600004A RID: 74 RVA: 0x000110C8 File Offset: 0x0000F4C8
		internal static string ScanContinuous
		{
			get
			{
				return Resources.ResourceManager.GetString("ScanContinuous", Resources.resourceCulture);
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x0600004B RID: 75 RVA: 0x000110F0 File Offset: 0x0000F4F0
		internal static string ScanType
		{
			get
			{
				return Resources.ResourceManager.GetString("ScanType", Resources.resourceCulture);
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x0600004C RID: 76 RVA: 0x00011118 File Offset: 0x0000F518
		internal static string SelectDevice
		{
			get
			{
				return Resources.ResourceManager.GetString("SelectDevice", Resources.resourceCulture);
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x0600004D RID: 77 RVA: 0x00011140 File Offset: 0x0000F540
		internal static string Slab
		{
			get
			{
				return Resources.ResourceManager.GetString("Slab", Resources.resourceCulture);
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x0600004E RID: 78 RVA: 0x00011168 File Offset: 0x0000F568
		internal static string Source
		{
			get
			{
				return Resources.ResourceManager.GetString("Source", Resources.resourceCulture);
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x0600004F RID: 79 RVA: 0x00011190 File Offset: 0x0000F590
		internal static string StartRead
		{
			get
			{
				return Resources.ResourceManager.GetString("StartRead", Resources.resourceCulture);
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000050 RID: 80 RVA: 0x000111B8 File Offset: 0x0000F5B8
		internal static string StopRead
		{
			get
			{
				return Resources.ResourceManager.GetString("StopRead", Resources.resourceCulture);
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000051 RID: 81 RVA: 0x000111E0 File Offset: 0x0000F5E0
		internal static string TermReader
		{
			get
			{
				return Resources.ResourceManager.GetString("TermReader", Resources.resourceCulture);
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000052 RID: 82 RVA: 0x00011208 File Offset: 0x0000F608
		internal static string Time
		{
			get
			{
				return Resources.ResourceManager.GetString("Time", Resources.resourceCulture);
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06000053 RID: 83 RVA: 0x00011230 File Offset: 0x0000F630
		internal static string Trigger
		{
			get
			{
				return Resources.ResourceManager.GetString("Trigger", Resources.resourceCulture);
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x06000054 RID: 84 RVA: 0x00011258 File Offset: 0x0000F658
		internal static string Type
		{
			get
			{
				return Resources.ResourceManager.GetString("Type", Resources.resourceCulture);
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x06000055 RID: 85 RVA: 0x00011280 File Offset: 0x0000F680
		internal static string Value
		{
			get
			{
				return Resources.ResourceManager.GetString("Value", Resources.resourceCulture);
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06000056 RID: 86 RVA: 0x000112A8 File Offset: 0x0000F6A8
		internal static string VB_BarcodeSample1
		{
			get
			{
				return Resources.ResourceManager.GetString("VB_BarcodeSample1", Resources.resourceCulture);
			}
		}

		// Token: 0x04000020 RID: 32
		private static ResourceManager resourceMan;

		// Token: 0x04000021 RID: 33
		private static CultureInfo resourceCulture;
	}
}
