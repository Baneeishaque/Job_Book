﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: ComVisible(false)]
[assembly: AssemblyCompany("")]
[assembly: Guid("9ddc21c8-9be1-423d-9ff3-965e6d8b4e92")]
[assembly: CLSCompliant(true)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyProduct("ScanApp")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyTitle("ScanApp")]
[assembly: Debuggable(259)]
