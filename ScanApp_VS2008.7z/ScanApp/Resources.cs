﻿using System;
using System.Diagnostics;
using System.Resources;

namespace ScanApp
{
	// Token: 0x02000008 RID: 8
	internal class Resources
	{
		// Token: 0x06000023 RID: 35 RVA: 0x00010AE4 File Offset: 0x0000EEE4
		[DebuggerNonUserCode]
		public Resources()
		{
		}

		// Token: 0x06000025 RID: 37 RVA: 0x00010B14 File Offset: 0x0000EF14
		public static string GetString(string name)
		{
			return Resources.m_rmNameValues.GetString(name);
		}

		// Token: 0x0400001F RID: 31
		private static ResourceManager m_rmNameValues = new ResourceManager("VB_BarcodeSample1.Resources", typeof(Resources).Assembly);
	}
}
