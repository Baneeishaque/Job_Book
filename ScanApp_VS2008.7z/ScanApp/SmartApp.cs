﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using Microsoft.VisualBasic.CompilerServices;
using ScanApp.LegnanoService;
using ScanApp.My;
using ScanApp.VB_BarcodeSample1;
using Symbol;
using Symbol.Barcode;

namespace ScanApp
{
	// Token: 0x0200000A RID: 10
	[DesignerGenerated]
	public partial class SmartApp : Form
	{
		// Token: 0x06000057 RID: 87 RVA: 0x00012DDC File Offset: 0x000111DC
		public SmartApp()
		{
			base.Load += new EventHandler(this.SmartApp_Load);
			base.Closing += new CancelEventHandler(this.SmartApp_Closing);
			this.strBarcode = string.Empty;
			this.stopwatch = new Stopwatch();
			this.myconnection = false;
			this.NoOfOperator = string.Empty;
			this.activity = string.Empty;
			this.badgeid = string.Empty;
			this.CustomerNo = string.Empty;
			this.CustomerName = string.Empty;
			this.Description = string.Empty;
			this.NetWeight = string.Empty;
			this.NonConformityDoing = string.Empty;
			this.jobno = string.Empty;
			this.coreno = string.Empty;
			this.tableid = string.Empty;
			this.status = string.Empty;
			this.BadgeStart = string.Empty;
			this.StartDate = string.Empty;
			this.BadgeEnd = string.Empty;
			this.EndDate = string.Empty;
			this.ConfigDepartmentCode = string.Empty;
			this.CoreDescription = string.Empty;
			this.WeightForUnitKg = default(decimal);
			this.CustomerDescription = string.Empty;
			this.ThicknessInmm = default(decimal);
			this.StackInmm = default(decimal);
			this.Column1MeasureInmm = default(decimal);
			this.CentralMeasureInmm = default(decimal);
			this.Column2MeasureInmm = default(decimal);
			this.ConfigTableId = string.Empty;
			this.IsClicked = false;
			this.ToDo = 0;
			this.Doing = 0;
			this.Done = 0;
			this.MyEventHandler = null;
			this.NoOfOperatorValueIsFocused = false;
			this.myScanSampleAPI = null;
			this.myReadNotifyHandler = null;
			this.myStatusNotifyHandler = null;
			this.myFormActivatedEventHandler = null;
			this.myFormDeactivatedEventHandler = null;
			this.isReaderInitiated = false;
			this.prevState = States.ERROR;
			this.InitializeComponent();
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00012FBC File Offset: 0x000113BC
		public static void Main()
		{
			Application.Run(MyProject.Forms.SmartApp);
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x0600005B RID: 91 RVA: 0x00015F6C File Offset: 0x0001436C
		// (set) Token: 0x0600005C RID: 92 RVA: 0x00015F84 File Offset: 0x00014384
		internal virtual Panel pnlMenu
		{
			[DebuggerNonUserCode]
			get
			{
				return this._pnlMenu;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._pnlMenu = value;
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x0600005D RID: 93 RVA: 0x00015F90 File Offset: 0x00014390
		// (set) Token: 0x0600005E RID: 94 RVA: 0x00015FA8 File Offset: 0x000143A8
		internal virtual PictureBox pcLegnano
		{
			[DebuggerNonUserCode]
			get
			{
				return this._pcLegnano;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.pcLegnano_Click);
				if (this._pcLegnano != null)
				{
					this._pcLegnano.Click -= eventHandler;
				}
				this._pcLegnano = value;
				if (this._pcLegnano != null)
				{
					this._pcLegnano.Click += eventHandler;
				}
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x0600005F RID: 95 RVA: 0x00015FF8 File Offset: 0x000143F8
		// (set) Token: 0x06000060 RID: 96 RVA: 0x00016010 File Offset: 0x00014410
		internal virtual Label Label8
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label8;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label8 = value;
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000061 RID: 97 RVA: 0x0001601C File Offset: 0x0001441C
		// (set) Token: 0x06000062 RID: 98 RVA: 0x00016034 File Offset: 0x00014434
		internal virtual Label lblSelectActivity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblSelectActivity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblSelectActivity = value;
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000063 RID: 99 RVA: 0x00016040 File Offset: 0x00014440
		// (set) Token: 0x06000064 RID: 100 RVA: 0x00016058 File Offset: 0x00014458
		internal virtual Button btnActivity6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity6 = value;
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000065 RID: 101 RVA: 0x00016064 File Offset: 0x00014464
		// (set) Token: 0x06000066 RID: 102 RVA: 0x0001607C File Offset: 0x0001447C
		internal virtual Button btnActivity5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity5 = value;
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000067 RID: 103 RVA: 0x00016088 File Offset: 0x00014488
		// (set) Token: 0x06000068 RID: 104 RVA: 0x000160A0 File Offset: 0x000144A0
		internal virtual Button btnActivity4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity4 = value;
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000069 RID: 105 RVA: 0x000160AC File Offset: 0x000144AC
		// (set) Token: 0x0600006A RID: 106 RVA: 0x000160C4 File Offset: 0x000144C4
		internal virtual Button btnActivity3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity3 = value;
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x0600006B RID: 107 RVA: 0x000160D0 File Offset: 0x000144D0
		// (set) Token: 0x0600006C RID: 108 RVA: 0x000160E8 File Offset: 0x000144E8
		internal virtual Button btnActivity2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity2 = value;
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x0600006D RID: 109 RVA: 0x000160F4 File Offset: 0x000144F4
		// (set) Token: 0x0600006E RID: 110 RVA: 0x0001610C File Offset: 0x0001450C
		internal virtual Button btnActivity1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnActivity1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._btnActivity1 = value;
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x0600006F RID: 111 RVA: 0x00016118 File Offset: 0x00014518
		// (set) Token: 0x06000070 RID: 112 RVA: 0x00016130 File Offset: 0x00014530
		internal virtual TabControl tbActivities
		{
			[DebuggerNonUserCode]
			get
			{
				return this._tbActivities;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._tbActivities = value;
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000071 RID: 113 RVA: 0x0001613C File Offset: 0x0001453C
		// (set) Token: 0x06000072 RID: 114 RVA: 0x00016154 File Offset: 0x00014554
		internal virtual TabPage tbSelectActivity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._tbSelectActivity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._tbSelectActivity = value;
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000073 RID: 115 RVA: 0x00016160 File Offset: 0x00014560
		// (set) Token: 0x06000074 RID: 116 RVA: 0x00016178 File Offset: 0x00014578
		internal virtual TabPage tbScanBarcodes
		{
			[DebuggerNonUserCode]
			get
			{
				return this._tbScanBarcodes;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._tbScanBarcodes = value;
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000075 RID: 117 RVA: 0x00016184 File Offset: 0x00014584
		// (set) Token: 0x06000076 RID: 118 RVA: 0x0001619C File Offset: 0x0001459C
		internal virtual TabPage tbSelectTasks
		{
			[DebuggerNonUserCode]
			get
			{
				return this._tbSelectTasks;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._tbSelectTasks = value;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000077 RID: 119 RVA: 0x000161A8 File Offset: 0x000145A8
		// (set) Token: 0x06000078 RID: 120 RVA: 0x000161C0 File Offset: 0x000145C0
		internal virtual PictureBox pcClose
		{
			[DebuggerNonUserCode]
			get
			{
				return this._pcClose;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.pcClose_Click);
				if (this._pcClose != null)
				{
					this._pcClose.Click -= eventHandler;
				}
				this._pcClose = value;
				if (this._pcClose != null)
				{
					this._pcClose.Click += eventHandler;
				}
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000079 RID: 121 RVA: 0x00016210 File Offset: 0x00014610
		// (set) Token: 0x0600007A RID: 122 RVA: 0x00016228 File Offset: 0x00014628
		internal virtual Label Label7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label7 = value;
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x0600007B RID: 123 RVA: 0x00016234 File Offset: 0x00014634
		// (set) Token: 0x0600007C RID: 124 RVA: 0x0001624C File Offset: 0x0001464C
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x0600007D RID: 125 RVA: 0x00016258 File Offset: 0x00014658
		// (set) Token: 0x0600007E RID: 126 RVA: 0x00016270 File Offset: 0x00014670
		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label2 = value;
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x0600007F RID: 127 RVA: 0x0001627C File Offset: 0x0001467C
		// (set) Token: 0x06000080 RID: 128 RVA: 0x00016294 File Offset: 0x00014694
		internal virtual Label lblTime
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblTime;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblTime = value;
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06000081 RID: 129 RVA: 0x000162A0 File Offset: 0x000146A0
		// (set) Token: 0x06000082 RID: 130 RVA: 0x000162B8 File Offset: 0x000146B8
		internal virtual Label Label3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label3 = value;
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x06000083 RID: 131 RVA: 0x000162C4 File Offset: 0x000146C4
		// (set) Token: 0x06000084 RID: 132 RVA: 0x000162DC File Offset: 0x000146DC
		internal virtual Label Label4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label4 = value;
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06000085 RID: 133 RVA: 0x000162E8 File Offset: 0x000146E8
		// (set) Token: 0x06000086 RID: 134 RVA: 0x00016300 File Offset: 0x00014700
		internal virtual Button btn3Activity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btn3Activity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btn3Activity_Click);
				if (this._btn3Activity != null)
				{
					this._btn3Activity.Click -= eventHandler;
				}
				this._btn3Activity = value;
				if (this._btn3Activity != null)
				{
					this._btn3Activity.Click += eventHandler;
				}
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000087 RID: 135 RVA: 0x00016350 File Offset: 0x00014750
		// (set) Token: 0x06000088 RID: 136 RVA: 0x00016368 File Offset: 0x00014768
		internal virtual Button btn2Activity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btn2Activity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btn2Activity_Click);
				if (this._btn2Activity != null)
				{
					this._btn2Activity.Click -= eventHandler;
				}
				this._btn2Activity = value;
				if (this._btn2Activity != null)
				{
					this._btn2Activity.Click += eventHandler;
				}
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000089 RID: 137 RVA: 0x000163B8 File Offset: 0x000147B8
		// (set) Token: 0x0600008A RID: 138 RVA: 0x000163D0 File Offset: 0x000147D0
		internal virtual Button btn1Activity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btn1Activity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btn1Activity_Click);
				if (this._btn1Activity != null)
				{
					this._btn1Activity.Click -= eventHandler;
				}
				this._btn1Activity = value;
				if (this._btn1Activity != null)
				{
					this._btn1Activity.Click += eventHandler;
				}
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x0600008B RID: 139 RVA: 0x00016420 File Offset: 0x00014820
		// (set) Token: 0x0600008C RID: 140 RVA: 0x00016438 File Offset: 0x00014838
		internal virtual Label lblMessage
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblMessage;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblMessage = value;
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x0600008D RID: 141 RVA: 0x00016444 File Offset: 0x00014844
		// (set) Token: 0x0600008E RID: 142 RVA: 0x0001645C File Offset: 0x0001485C
		internal virtual TextBox txtCoreNo
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtCoreNo;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				KeyEventHandler keyEventHandler = new KeyEventHandler(this.txtCoreNo_KeyDown);
				EventHandler eventHandler = new EventHandler(this.txtCoreNo_LostFocus);
				EventHandler eventHandler2 = new EventHandler(this.txtCoreNo_GotFocus);
				if (this._txtCoreNo != null)
				{
					this._txtCoreNo.KeyDown -= keyEventHandler;
					this._txtCoreNo.LostFocus -= eventHandler;
					this._txtCoreNo.GotFocus -= eventHandler2;
				}
				this._txtCoreNo = value;
				if (this._txtCoreNo != null)
				{
					this._txtCoreNo.KeyDown += keyEventHandler;
					this._txtCoreNo.LostFocus += eventHandler;
					this._txtCoreNo.GotFocus += eventHandler2;
				}
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x0600008F RID: 143 RVA: 0x000164FC File Offset: 0x000148FC
		// (set) Token: 0x06000090 RID: 144 RVA: 0x00016514 File Offset: 0x00014914
		internal virtual TextBox txtJobNo
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtJobNo;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				KeyEventHandler keyEventHandler = new KeyEventHandler(this.txtJobNo_KeyDown);
				EventHandler eventHandler = new EventHandler(this.txtJobNo_LostFocus);
				EventHandler eventHandler2 = new EventHandler(this.txtJobNo_GotFocus);
				if (this._txtJobNo != null)
				{
					this._txtJobNo.KeyDown -= keyEventHandler;
					this._txtJobNo.LostFocus -= eventHandler;
					this._txtJobNo.GotFocus -= eventHandler2;
				}
				this._txtJobNo = value;
				if (this._txtJobNo != null)
				{
					this._txtJobNo.KeyDown += keyEventHandler;
					this._txtJobNo.LostFocus += eventHandler;
					this._txtJobNo.GotFocus += eventHandler2;
				}
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000091 RID: 145 RVA: 0x000165B4 File Offset: 0x000149B4
		// (set) Token: 0x06000092 RID: 146 RVA: 0x000165CC File Offset: 0x000149CC
		internal virtual Button btnEndJob
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnEndJob;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btnEndJob_Click);
				if (this._btnEndJob != null)
				{
					this._btnEndJob.Click -= eventHandler;
				}
				this._btnEndJob = value;
				if (this._btnEndJob != null)
				{
					this._btnEndJob.Click += eventHandler;
				}
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000093 RID: 147 RVA: 0x0001661C File Offset: 0x00014A1C
		// (set) Token: 0x06000094 RID: 148 RVA: 0x00016634 File Offset: 0x00014A34
		internal virtual Button btnPauseJob
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnPauseJob;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btnPauseJob_Click);
				if (this._btnPauseJob != null)
				{
					this._btnPauseJob.Click -= eventHandler;
				}
				this._btnPauseJob = value;
				if (this._btnPauseJob != null)
				{
					this._btnPauseJob.Click += eventHandler;
				}
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x06000095 RID: 149 RVA: 0x00016684 File Offset: 0x00014A84
		// (set) Token: 0x06000096 RID: 150 RVA: 0x0001669C File Offset: 0x00014A9C
		internal virtual Timer Timer1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Timer1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.Timer1_Tick);
				if (this._Timer1 != null)
				{
					this._Timer1.Tick -= eventHandler;
				}
				this._Timer1 = value;
				if (this._Timer1 != null)
				{
					this._Timer1.Tick += eventHandler;
				}
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000097 RID: 151 RVA: 0x000166EC File Offset: 0x00014AEC
		// (set) Token: 0x06000098 RID: 152 RVA: 0x00016704 File Offset: 0x00014B04
		internal virtual Label lblActivity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblActivity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblActivity = value;
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x06000099 RID: 153 RVA: 0x00016710 File Offset: 0x00014B10
		// (set) Token: 0x0600009A RID: 154 RVA: 0x00016728 File Offset: 0x00014B28
		internal virtual Label lblNoOfOperator
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblNoOfOperator;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblNoOfOperator = value;
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x0600009B RID: 155 RVA: 0x00016734 File Offset: 0x00014B34
		// (set) Token: 0x0600009C RID: 156 RVA: 0x0001674C File Offset: 0x00014B4C
		internal virtual Label Label9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label9 = value;
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x0600009D RID: 157 RVA: 0x00016758 File Offset: 0x00014B58
		// (set) Token: 0x0600009E RID: 158 RVA: 0x00016770 File Offset: 0x00014B70
		internal virtual Label Label10
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label10;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label10 = value;
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x0600009F RID: 159 RVA: 0x0001677C File Offset: 0x00014B7C
		// (set) Token: 0x060000A0 RID: 160 RVA: 0x00016794 File Offset: 0x00014B94
		internal virtual Label Label11
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label11;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label11 = value;
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x060000A1 RID: 161 RVA: 0x000167A0 File Offset: 0x00014BA0
		// (set) Token: 0x060000A2 RID: 162 RVA: 0x000167B8 File Offset: 0x00014BB8
		internal virtual TextBox txtActivityName
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtActivityName;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._txtActivityName = value;
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x060000A3 RID: 163 RVA: 0x000167C4 File Offset: 0x00014BC4
		// (set) Token: 0x060000A4 RID: 164 RVA: 0x000167DC File Offset: 0x00014BDC
		internal virtual Button btnResume
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnResume;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btnResume_Click);
				if (this._btnResume != null)
				{
					this._btnResume.Click -= eventHandler;
				}
				this._btnResume = value;
				if (this._btnResume != null)
				{
					this._btnResume.Click += eventHandler;
				}
			}
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x060000A5 RID: 165 RVA: 0x0001682C File Offset: 0x00014C2C
		// (set) Token: 0x060000A6 RID: 166 RVA: 0x00016844 File Offset: 0x00014C44
		internal virtual TextBox StatusName
		{
			[DebuggerNonUserCode]
			get
			{
				return this._StatusName;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._StatusName = value;
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x060000A7 RID: 167 RVA: 0x00016850 File Offset: 0x00014C50
		// (set) Token: 0x060000A8 RID: 168 RVA: 0x00016868 File Offset: 0x00014C68
		internal virtual TextBox statusCoreNo
		{
			[DebuggerNonUserCode]
			get
			{
				return this._statusCoreNo;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._statusCoreNo = value;
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x060000A9 RID: 169 RVA: 0x00016874 File Offset: 0x00014C74
		// (set) Token: 0x060000AA RID: 170 RVA: 0x0001688C File Offset: 0x00014C8C
		internal virtual TextBox statusJobNo
		{
			[DebuggerNonUserCode]
			get
			{
				return this._statusJobNo;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._statusJobNo = value;
			}
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x060000AB RID: 171 RVA: 0x00016898 File Offset: 0x00014C98
		// (set) Token: 0x060000AC RID: 172 RVA: 0x000168B0 File Offset: 0x00014CB0
		internal virtual TextBox statusBadgeId
		{
			[DebuggerNonUserCode]
			get
			{
				return this._statusBadgeId;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.statusBadgeId_LostFocus);
				EventHandler eventHandler2 = new EventHandler(this.statusBadgeId_GotFocus);
				if (this._statusBadgeId != null)
				{
					this._statusBadgeId.LostFocus -= eventHandler;
					this._statusBadgeId.GotFocus -= eventHandler2;
				}
				this._statusBadgeId = value;
				if (this._statusBadgeId != null)
				{
					this._statusBadgeId.LostFocus += eventHandler;
					this._statusBadgeId.GotFocus += eventHandler2;
				}
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x060000AD RID: 173 RVA: 0x00016928 File Offset: 0x00014D28
		// (set) Token: 0x060000AE RID: 174 RVA: 0x00016940 File Offset: 0x00014D40
		internal virtual TextBox statusActivity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._statusActivity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._statusActivity = value;
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x060000AF RID: 175 RVA: 0x0001694C File Offset: 0x00014D4C
		// (set) Token: 0x060000B0 RID: 176 RVA: 0x00016964 File Offset: 0x00014D64
		internal virtual Label Label15
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label15;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label15 = value;
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x060000B1 RID: 177 RVA: 0x00016970 File Offset: 0x00014D70
		// (set) Token: 0x060000B2 RID: 178 RVA: 0x00016988 File Offset: 0x00014D88
		internal virtual Label Label17
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label17;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label17 = value;
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x060000B3 RID: 179 RVA: 0x00016994 File Offset: 0x00014D94
		// (set) Token: 0x060000B4 RID: 180 RVA: 0x000169AC File Offset: 0x00014DAC
		internal virtual Label Label16
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label16;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label16 = value;
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x060000B5 RID: 181 RVA: 0x000169B8 File Offset: 0x00014DB8
		// (set) Token: 0x060000B6 RID: 182 RVA: 0x000169D0 File Offset: 0x00014DD0
		internal virtual Label Label19
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label19;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label19 = value;
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x060000B7 RID: 183 RVA: 0x000169DC File Offset: 0x00014DDC
		// (set) Token: 0x060000B8 RID: 184 RVA: 0x000169F4 File Offset: 0x00014DF4
		internal virtual Label Label18
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label18;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label18 = value;
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x060000B9 RID: 185 RVA: 0x00016A00 File Offset: 0x00014E00
		// (set) Token: 0x060000BA RID: 186 RVA: 0x00016A18 File Offset: 0x00014E18
		internal virtual Label Label20
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label20;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label20 = value;
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x060000BB RID: 187 RVA: 0x00016A24 File Offset: 0x00014E24
		// (set) Token: 0x060000BC RID: 188 RVA: 0x00016A3C File Offset: 0x00014E3C
		internal virtual TextBox txtBadgeId
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtBadgeId;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.txtBadgeId_TextChanged);
				KeyEventHandler keyEventHandler = new KeyEventHandler(this.txtBadgeId_KeyDown);
				EventHandler eventHandler2 = new EventHandler(this.txtBadgeId_LostFocus);
				EventHandler eventHandler3 = new EventHandler(this.txtBadgeId_GotFocus);
				if (this._txtBadgeId != null)
				{
					this._txtBadgeId.TextChanged -= eventHandler;
					this._txtBadgeId.KeyDown -= keyEventHandler;
					this._txtBadgeId.LostFocus -= eventHandler2;
					this._txtBadgeId.GotFocus -= eventHandler3;
				}
				this._txtBadgeId = value;
				if (this._txtBadgeId != null)
				{
					this._txtBadgeId.TextChanged += eventHandler;
					this._txtBadgeId.KeyDown += keyEventHandler;
					this._txtBadgeId.LostFocus += eventHandler2;
					this._txtBadgeId.GotFocus += eventHandler3;
				}
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x060000BD RID: 189 RVA: 0x00016B04 File Offset: 0x00014F04
		// (set) Token: 0x060000BE RID: 190 RVA: 0x00016B1C File Offset: 0x00014F1C
		internal virtual TabPage tbTableConfig
		{
			[DebuggerNonUserCode]
			get
			{
				return this._tbTableConfig;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._tbTableConfig = value;
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x060000BF RID: 191 RVA: 0x00016B28 File Offset: 0x00014F28
		// (set) Token: 0x060000C0 RID: 192 RVA: 0x00016B40 File Offset: 0x00014F40
		internal virtual TextBox txtConfigDepartmentCode
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtConfigDepartmentCode;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.txtConfigDepartmentCode_LostFocus);
				EventHandler eventHandler2 = new EventHandler(this.txtConfigDepartmentCode_GotFocus);
				if (this._txtConfigDepartmentCode != null)
				{
					this._txtConfigDepartmentCode.LostFocus -= eventHandler;
					this._txtConfigDepartmentCode.GotFocus -= eventHandler2;
				}
				this._txtConfigDepartmentCode = value;
				if (this._txtConfigDepartmentCode != null)
				{
					this._txtConfigDepartmentCode.LostFocus += eventHandler;
					this._txtConfigDepartmentCode.GotFocus += eventHandler2;
				}
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x060000C1 RID: 193 RVA: 0x00016BB8 File Offset: 0x00014FB8
		// (set) Token: 0x060000C2 RID: 194 RVA: 0x00016BD0 File Offset: 0x00014FD0
		internal virtual Label Label21
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label21;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label21 = value;
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x060000C3 RID: 195 RVA: 0x00016BDC File Offset: 0x00014FDC
		// (set) Token: 0x060000C4 RID: 196 RVA: 0x00016BF4 File Offset: 0x00014FF4
		internal virtual TextBox txtConfigTableId
		{
			[DebuggerNonUserCode]
			get
			{
				return this._txtConfigTableId;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.txtConfigTableId_LostFocus);
				EventHandler eventHandler2 = new EventHandler(this.txtConfigTableId_GotFocus);
				if (this._txtConfigTableId != null)
				{
					this._txtConfigTableId.LostFocus -= eventHandler;
					this._txtConfigTableId.GotFocus -= eventHandler2;
				}
				this._txtConfigTableId = value;
				if (this._txtConfigTableId != null)
				{
					this._txtConfigTableId.LostFocus += eventHandler;
					this._txtConfigTableId.GotFocus += eventHandler2;
				}
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x060000C5 RID: 197 RVA: 0x00016C6C File Offset: 0x0001506C
		// (set) Token: 0x060000C6 RID: 198 RVA: 0x00016C84 File Offset: 0x00015084
		internal virtual Label lblTable
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblTable;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblTable = value;
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x060000C7 RID: 199 RVA: 0x00016C90 File Offset: 0x00015090
		// (set) Token: 0x060000C8 RID: 200 RVA: 0x00016CA8 File Offset: 0x000150A8
		internal virtual Button btn4Activity
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btn4Activity;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btn4Activity_Click);
				if (this._btn4Activity != null)
				{
					this._btn4Activity.Click -= eventHandler;
				}
				this._btn4Activity = value;
				if (this._btn4Activity != null)
				{
					this._btn4Activity.Click += eventHandler;
				}
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x060000C9 RID: 201 RVA: 0x00016CF8 File Offset: 0x000150F8
		// (set) Token: 0x060000CA RID: 202 RVA: 0x00016D10 File Offset: 0x00015110
		internal virtual Button btnCancelConfig
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnCancelConfig;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btnCancelConfig_Click);
				if (this._btnCancelConfig != null)
				{
					this._btnCancelConfig.Click -= eventHandler;
				}
				this._btnCancelConfig = value;
				if (this._btnCancelConfig != null)
				{
					this._btnCancelConfig.Click += eventHandler;
				}
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x060000CB RID: 203 RVA: 0x00016D60 File Offset: 0x00015160
		// (set) Token: 0x060000CC RID: 204 RVA: 0x00016D78 File Offset: 0x00015178
		internal virtual Button btnSaveConfig
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnSaveConfig;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btnSaveConfig_Click);
				if (this._btnSaveConfig != null)
				{
					this._btnSaveConfig.Click -= eventHandler;
				}
				this._btnSaveConfig = value;
				if (this._btnSaveConfig != null)
				{
					this._btnSaveConfig.Click += eventHandler;
				}
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x060000CD RID: 205 RVA: 0x00016DC8 File Offset: 0x000151C8
		// (set) Token: 0x060000CE RID: 206 RVA: 0x00016DE0 File Offset: 0x000151E0
		internal virtual PictureBox pcSettings
		{
			[DebuggerNonUserCode]
			get
			{
				return this._pcSettings;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.pcSettings_Click);
				if (this._pcSettings != null)
				{
					this._pcSettings.Click -= eventHandler;
				}
				this._pcSettings = value;
				if (this._pcSettings != null)
				{
					this._pcSettings.Click += eventHandler;
				}
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x060000CF RID: 207 RVA: 0x00016E30 File Offset: 0x00015230
		// (set) Token: 0x060000D0 RID: 208 RVA: 0x00016E48 File Offset: 0x00015248
		internal virtual Label lblDepartmentCode
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblDepartmentCode;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblDepartmentCode = value;
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x060000D1 RID: 209 RVA: 0x00016E54 File Offset: 0x00015254
		// (set) Token: 0x060000D2 RID: 210 RVA: 0x00016E6C File Offset: 0x0001526C
		internal virtual Label lblTableId
		{
			[DebuggerNonUserCode]
			get
			{
				return this._lblTableId;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._lblTableId = value;
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x060000D3 RID: 211 RVA: 0x00016E78 File Offset: 0x00015278
		// (set) Token: 0x060000D4 RID: 212 RVA: 0x00016E90 File Offset: 0x00015290
		internal virtual Button btnAdd
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnAdd;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btnAdd_Click);
				if (this._btnAdd != null)
				{
					this._btnAdd.Click -= eventHandler;
				}
				this._btnAdd = value;
				if (this._btnAdd != null)
				{
					this._btnAdd.Click += eventHandler;
				}
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x060000D5 RID: 213 RVA: 0x00016EE0 File Offset: 0x000152E0
		// (set) Token: 0x060000D6 RID: 214 RVA: 0x00016EF8 File Offset: 0x000152F8
		internal virtual Button btnSubtract
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnSubtract;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btnSubtract_Click);
				if (this._btnSubtract != null)
				{
					this._btnSubtract.Click -= eventHandler;
				}
				this._btnSubtract = value;
				if (this._btnSubtract != null)
				{
					this._btnSubtract.Click += eventHandler;
				}
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x060000D7 RID: 215 RVA: 0x00016F48 File Offset: 0x00015348
		// (set) Token: 0x060000D8 RID: 216 RVA: 0x00016F60 File Offset: 0x00015360
		internal virtual NumericUpDown NoOfOperatorValue
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NoOfOperatorValue;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.NoOfOperatorValue_ValueChanged);
				if (this._NoOfOperatorValue != null)
				{
					this._NoOfOperatorValue.ValueChanged -= eventHandler;
				}
				this._NoOfOperatorValue = value;
				if (this._NoOfOperatorValue != null)
				{
					this._NoOfOperatorValue.ValueChanged += eventHandler;
				}
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x060000D9 RID: 217 RVA: 0x00016FB0 File Offset: 0x000153B0
		// (set) Token: 0x060000DA RID: 218 RVA: 0x00016FC8 File Offset: 0x000153C8
		internal virtual PictureBox MsgIconConfig
		{
			[DebuggerNonUserCode]
			get
			{
				return this._MsgIconConfig;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._MsgIconConfig = value;
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x060000DB RID: 219 RVA: 0x00016FD4 File Offset: 0x000153D4
		// (set) Token: 0x060000DC RID: 220 RVA: 0x00016FEC File Offset: 0x000153EC
		internal virtual Label msgConfig
		{
			[DebuggerNonUserCode]
			get
			{
				return this._msgConfig;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._msgConfig = value;
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x060000DD RID: 221 RVA: 0x00016FF8 File Offset: 0x000153F8
		// (set) Token: 0x060000DE RID: 222 RVA: 0x00017010 File Offset: 0x00015410
		internal virtual Label Label12
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label12;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._Label12 = value;
			}
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x060000DF RID: 223 RVA: 0x0001701C File Offset: 0x0001541C
		// (set) Token: 0x060000E0 RID: 224 RVA: 0x00017034 File Offset: 0x00015434
		internal virtual TextBox statusTime
		{
			[DebuggerNonUserCode]
			get
			{
				return this._statusTime;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._statusTime = value;
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x060000E1 RID: 225 RVA: 0x00017040 File Offset: 0x00015440
		// (set) Token: 0x060000E2 RID: 226 RVA: 0x00017058 File Offset: 0x00015458
		internal virtual Button buttonContinue
		{
			[DebuggerNonUserCode]
			get
			{
				return this._buttonContinue;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.buttonContinue_Click);
				if (this._buttonContinue != null)
				{
					this._buttonContinue.Click -= eventHandler;
				}
				this._buttonContinue = value;
				if (this._buttonContinue != null)
				{
					this._buttonContinue.Click += eventHandler;
				}
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x060000E3 RID: 227 RVA: 0x000170A8 File Offset: 0x000154A8
		// (set) Token: 0x060000E4 RID: 228 RVA: 0x000170C0 File Offset: 0x000154C0
		internal virtual Button buttonBack
		{
			[DebuggerNonUserCode]
			get
			{
				return this._buttonBack;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.buttonBack_Click);
				if (this._buttonBack != null)
				{
					this._buttonBack.Click -= eventHandler;
				}
				this._buttonBack = value;
				if (this._buttonBack != null)
				{
					this._buttonBack.Click += eventHandler;
				}
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x060000E5 RID: 229 RVA: 0x00017110 File Offset: 0x00015510
		// (set) Token: 0x060000E6 RID: 230 RVA: 0x00017128 File Offset: 0x00015528
		internal virtual Button btnClr2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnClr2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btnClr2_Click);
				if (this._btnClr2 != null)
				{
					this._btnClr2.Click -= eventHandler;
				}
				this._btnClr2 = value;
				if (this._btnClr2 != null)
				{
					this._btnClr2.Click += eventHandler;
				}
			}
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x060000E7 RID: 231 RVA: 0x00017178 File Offset: 0x00015578
		// (set) Token: 0x060000E8 RID: 232 RVA: 0x00017190 File Offset: 0x00015590
		internal virtual Button btnClr1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnClr1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btnClr1_Click);
				if (this._btnClr1 != null)
				{
					this._btnClr1.Click -= eventHandler;
				}
				this._btnClr1 = value;
				if (this._btnClr1 != null)
				{
					this._btnClr1.Click += eventHandler;
				}
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x060000E9 RID: 233 RVA: 0x000171E0 File Offset: 0x000155E0
		// (set) Token: 0x060000EA RID: 234 RVA: 0x000171F8 File Offset: 0x000155F8
		internal virtual Timer Timer2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Timer2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.Timer2_Tick);
				if (this._Timer2 != null)
				{
					this._Timer2.Tick -= eventHandler;
				}
				this._Timer2 = value;
				if (this._Timer2 != null)
				{
					this._Timer2.Tick += eventHandler;
				}
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x060000EB RID: 235 RVA: 0x00017248 File Offset: 0x00015648
		// (set) Token: 0x060000EC RID: 236 RVA: 0x00017260 File Offset: 0x00015660
		private virtual PictureBox msgIcon
		{
			[DebuggerNonUserCode]
			get
			{
				return this._msgIcon;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._msgIcon = value;
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x060000ED RID: 237 RVA: 0x0001726C File Offset: 0x0001566C
		// (set) Token: 0x060000EE RID: 238 RVA: 0x00017284 File Offset: 0x00015684
		internal virtual Button StartJob
		{
			[DebuggerNonUserCode]
			get
			{
				return this._StartJob;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.StartJob_Click);
				if (this._StartJob != null)
				{
					this._StartJob.Click -= eventHandler;
				}
				this._StartJob = value;
				if (this._StartJob != null)
				{
					this._StartJob.Click += eventHandler;
				}
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x060000EF RID: 239 RVA: 0x000172D4 File Offset: 0x000156D4
		// (set) Token: 0x060000F0 RID: 240 RVA: 0x000172EC File Offset: 0x000156EC
		internal virtual Button btnMinus
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnMinus;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btnMinus_Click);
				if (this._btnMinus != null)
				{
					this._btnMinus.Click -= eventHandler;
				}
				this._btnMinus = value;
				if (this._btnMinus != null)
				{
					this._btnMinus.Click += eventHandler;
				}
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x060000F1 RID: 241 RVA: 0x0001733C File Offset: 0x0001573C
		// (set) Token: 0x060000F2 RID: 242 RVA: 0x00017354 File Offset: 0x00015754
		internal virtual Button btnPlus
		{
			[DebuggerNonUserCode]
			get
			{
				return this._btnPlus;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				EventHandler eventHandler = new EventHandler(this.btnPlus_Click);
				if (this._btnPlus != null)
				{
					this._btnPlus.Click -= eventHandler;
				}
				this._btnPlus = value;
				if (this._btnPlus != null)
				{
					this._btnPlus.Click += eventHandler;
				}
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x060000F3 RID: 243 RVA: 0x000173A4 File Offset: 0x000157A4
		// (set) Token: 0x060000F4 RID: 244 RVA: 0x000173BC File Offset: 0x000157BC
		internal virtual NumericUpDown NumericNoOfOperator
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NumericNoOfOperator;
			}
			[DebuggerNonUserCode]
			[MethodImpl(32)]
			set
			{
				this._NumericNoOfOperator = value;
			}
		}

		// Token: 0x060000F5 RID: 245 RVA: 0x000173C8 File Offset: 0x000157C8
		public void ClearScanData()
		{
			this.txtBadgeId.Text = "";
			this.txtBadgeId.Enabled = true;
			this.NoOfOperatorValue.Value = Conversions.ToDecimal("1");
			this.msgIcon.Visible = false;
			this.lblMessage.Visible = false;
			this.lblMessage.Text = "";
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x00017438 File Offset: 0x00015838
		public void GetDetailsForStatus()
		{
			this.statusActivity.Text = this.Myactivity;
			this.statusBadgeId.Text = this.MyBadgeId;
			this.statusBadgeId.Enabled = false;
			this.statusJobNo.Text = this.MyJobNo;
			this.statusCoreNo.Text = this.MyCoreNo;
			this.StatusName.Text = "";
			this.statusTime.Text = "";
			this.StartJob.Enabled = true;
			this.btnPauseJob.Enabled = false;
			this.btnEndJob.Enabled = false;
			this.btnResume.Enabled = false;
		}

		// Token: 0x060000F7 RID: 247 RVA: 0x000174F4 File Offset: 0x000158F4
		public void readConfigValues()
		{
			try
			{
				DataSet dataSet = new DataSet();
				dataSet.ReadXml("\\Platform\\Barcode Gulf\\Config.xml");
				if (dataSet.Tables[0].Rows.Count > 0)
				{
					GlobalVariables.strNetworkAddress = dataSet.Tables[0].Rows[0]["NetAddress"].ToString().Trim();
					GlobalVariables.strNetworkDB = dataSet.Tables[0].Rows[0]["DB"].ToString().Trim();
					GlobalVariables.strNetworkUsername = dataSet.Tables[0].Rows[0]["UName"].ToString().Trim();
					GlobalVariables.strNetworkPassword = dataSet.Tables[0].Rows[0]["Pwd"].ToString().Trim();
					GlobalVariables.strDepartmentCode = dataSet.Tables[0].Rows[0]["DepartmentCode"].ToString().Trim();
					GlobalVariables.strTableId = dataSet.Tables[0].Rows[0]["TableId"].ToString().Trim();
					GlobalVariables.VerifyServer = dataSet.Tables[0].Rows[0]["VerifyServer"].ToString().Trim();
					GlobalVariables.VerifyUser = dataSet.Tables[0].Rows[0]["VerifyUser"].ToString().Trim();
					GlobalVariables.VerifyPwd = dataSet.Tables[0].Rows[0]["VerifyPwd"].ToString().Trim();
					GlobalVariables.VerifyDB = dataSet.Tables[0].Rows[0]["VerifyDB"].ToString().Trim();
					GlobalVariables.VerifyTable = dataSet.Tables[0].Rows[0]["VerifyTable"].ToString().Trim();
					GlobalVariables.CopyTable = dataSet.Tables[0].Rows[0]["CopyTable"].ToString().Trim();
					GlobalVariables.WebServiceURL = dataSet.Tables[0].Rows[0]["WebServiceURL"].ToString().Trim();
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x000177D4 File Offset: 0x00015BD4
		private static Service1 createWebService()
		{
			Service1 service = new Service1();
			string webServiceURL = GlobalVariables.WebServiceURL;
			if (!string.IsNullOrEmpty(webServiceURL))
			{
				service.Url = webServiceURL;
			}
			return service;
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x00017804 File Offset: 0x00015C04
		public void writeConfigValuesinXml()
		{
			try
			{
				XmlDocument xmlDocument = new XmlDocument();
				xmlDocument.Load("\\Platform\\Barcode Gulf\\Config.xml");
				XmlNode xmlNode = xmlDocument.SelectSingleNode("Configurations/DepartmentCode");
				XmlNode xmlNode2 = xmlDocument.SelectSingleNode("Configurations/TableId");
				if (xmlNode != null)
				{
					string text = this.txtConfigDepartmentCode.Text.Trim();
					xmlNode.InnerText = "" + this.txtConfigDepartmentCode.Text.Trim() + "";
					xmlDocument.Save("\\Platform\\Barcode Gulf\\Config.xml");
				}
				if (xmlNode2 != null)
				{
					string text2 = this.txtConfigTableId.Text.Trim();
					xmlNode2.InnerText = "" + this.txtConfigTableId.Text.Trim() + "";
					xmlDocument.Save("\\Platform\\Barcode Gulf\\Config.xml");
					this.msgConfig.Visible = true;
					this.MsgIconConfig.Visible = true;
					this.msgConfig.Text = "Saved Settings Successfully";
				}
			}
			catch (Exception ex)
			{
				throw new Exception("Check Configuration Settings");
			}
		}

		// Token: 0x060000FA RID: 250 RVA: 0x00017928 File Offset: 0x00015D28
		private void myReader_ReadNotify(object Sender, EventArgs e)
		{
			if (this.InvokeRequired)
			{
				this.Invoke(this.myReadNotifyHandler, new object[]
				{
					RuntimeHelpers.GetObjectValue(Sender),
					e
				});
			}
			else
			{
				ReaderData nextReaderData = this.myScanSampleAPI.Reader.GetNextReaderData();
				Results result = nextReaderData.Result;
				if (result == Results.SUCCESS)
				{
					this.HandleContinuousData(nextReaderData);
				}
				else if (result == Results.E_SCN_READTIMEOUT)
				{
					this.myScanSampleAPI.StartRead(true);
				}
				else if (result != Results.CANCELED)
				{
					if (result == Results.E_SCN_DEVICEFAILURE)
					{
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.StartRead(true);
					}
					else
					{
						string text = "Read Failed\nResult = " + nextReaderData.Result.ToString();
						this.lblMessage.Text = text;
						if (nextReaderData.Result == Results.E_SCN_READINCOMPATIBLE)
						{
							MessageBox.Show(Resources.GetString("AppExitMsg"), Resources.GetString("Failure"));
							this.Close();
						}
					}
				}
			}
		}

		// Token: 0x060000FB RID: 251 RVA: 0x00017A3C File Offset: 0x00015E3C
		private void myReader_StatusNotify(object Sender, EventArgs e)
		{
			if (this.InvokeRequired)
			{
				this.Invoke(this.myStatusNotifyHandler, new object[]
				{
					RuntimeHelpers.GetObjectValue(Sender),
					e
				});
			}
			else
			{
				BarcodeStatus nextStatus = this.myScanSampleAPI.Reader.GetNextStatus();
				switch (nextStatus.State)
				{
				case States.IDLE:
					break;
				case States.WAITING:
					if (this.prevState == States.READY)
					{
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.StartRead(true);
					}
					break;
				case States.READY:
					break;
				default:
					this.lblMessage.Text = nextStatus.Text;
					break;
				}
				this.prevState = nextStatus.State;
			}
		}

		// Token: 0x060000FC RID: 252 RVA: 0x00017AF4 File Offset: 0x00015EF4
		private void HandleData(ReaderData TheReaderData)
		{
			this.txtBadgeId.Text = TheReaderData.Text;
		}

		// Token: 0x060000FD RID: 253 RVA: 0x00017B0C File Offset: 0x00015F0C
		private void HandleContinuousData(ReaderData TheReaderData)
		{
			if (this.txtBadgeId.Focused)
			{
				this.txtBadgeId.Text = TheReaderData.Text.Replace("/O", "/");
				string text = this.txtBadgeId.Text.Length.ToString();
				if (Operators.CompareString(this.txtBadgeId.Text, "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
				}
				else if (this.txtBadgeId.Text.Contains("/"))
				{
					MessageBox.Show("Check Scanned Badge Id", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
					this.txtBadgeId.Text = "";
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtJobNo.Text, this.txtBadgeId.Text, false) == 0)
				{
					this.txtBadgeId.Text = "";
					this.lblMessage.Text = "Job No. already scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, this.txtBadgeId.Text, false) == 0)
				{
					this.txtBadgeId.Text = "";
					this.lblMessage.Text = "Core No. already scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Conversions.ToDouble(text) > 9.0 | Conversions.ToDouble(text) < 8.0)
				{
					this.txtBadgeId.Text = "";
					MessageBox.Show("Check Scanned Badge Id", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else
				{
					this.badgeid = this.txtBadgeId.Text;
					this.txtBadgeId.Enabled = false;
					if (Operators.CompareString(this.txtJobNo.Text, "", false) == 0)
					{
						this.txtJobNo.Focus();
					}
					else if (Operators.CompareString(this.txtCoreNo.Text, "", false) == 0)
					{
						this.txtCoreNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, "", false) != 0)
					{
						this.tbActivities.SelectedIndex = 2;
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.Visible)
					{
						this.msgIcon.Visible = false;
						this.lblMessage.Visible = false;
					}
				}
			}
			else if (this.txtJobNo.Focused)
			{
				this.txtJobNo.Text = TheReaderData.Text.Replace("/O", "/");
				string text2 = this.txtJobNo.Text.Length.ToString();
				if (Operators.CompareString(this.txtJobNo.Text, "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
				}
				else if (this.txtJobNo.Text.Contains("-"))
				{
					MessageBox.Show("Check Scanned Job Number", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
					this.txtJobNo.Text = "";
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtBadgeId.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, this.txtJobNo.Text, false) == 0)
				{
					this.txtJobNo.Text = "";
					this.lblMessage.Text = "Operator Id has been scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, this.txtJobNo.Text, false) == 0)
				{
					this.txtJobNo.Text = "";
					this.lblMessage.Text = "Core No. has been scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Conversions.ToDouble(text2) > 11.0 | Conversions.ToDouble(text2) < 9.0)
				{
					this.txtJobNo.Text = "";
					MessageBox.Show("Check Scanned Job No", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else
				{
					this.jobno = this.txtJobNo.Text;
					this.txtJobNo.Enabled = false;
					if (Operators.CompareString(this.txtBadgeId.Text, "", false) == 0)
					{
						this.txtBadgeId.Focus();
					}
					else if (Operators.CompareString(this.txtCoreNo.Text, "", false) == 0)
					{
						this.txtCoreNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, "", false) != 0)
					{
						this.tbActivities.SelectedIndex = 2;
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.Visible)
					{
						this.msgIcon.Visible = false;
						this.lblMessage.Visible = false;
					}
				}
			}
			else if (this.txtCoreNo.Focused)
			{
				string text3 = TheReaderData.Text.Replace("/O", "/");
				this.txtCoreNo.Text = text3.Replace(" ", "");
				string text4 = this.txtCoreNo.Text.Length.ToString();
				if (Operators.CompareString(this.txtCoreNo.Text, "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (this.txtCoreNo.Text.Contains("-"))
				{
					MessageBox.Show("Check Scanned Core Number", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
					this.txtCoreNo.Text = "";
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtJobNo.Text, this.txtCoreNo.Text, false) == 0)
				{
					this.txtCoreNo.Text = "";
					this.lblMessage.Text = "Job No. already scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Operators.CompareString(this.txtBadgeId.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, this.txtCoreNo.Text, false) == 0)
				{
					this.txtCoreNo.Text = "";
					this.lblMessage.Text = "Operator Badge Id already scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else if (Conversions.ToDouble(text4) > 7.0 | Conversions.ToDouble(text4) < 3.0)
				{
					this.txtCoreNo.Text = "";
					MessageBox.Show("Check Scanned Core No", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else
				{
					this.coreno = this.txtCoreNo.Text;
					this.txtCoreNo.Enabled = false;
					if (Operators.CompareString(this.txtBadgeId.Text, "", false) == 0)
					{
						this.txtBadgeId.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.Text, "", false) == 0)
					{
						this.txtJobNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, "", false) != 0)
					{
						this.tbActivities.SelectedIndex = 2;
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.Visible)
					{
						this.msgIcon.Visible = false;
						this.lblMessage.Visible = false;
					}
				}
			}
			else if (this.statusBadgeId.Focused == Conversions.ToBoolean("True"))
			{
				this.statusBadgeId.Text = TheReaderData.Text.Replace("/O", "/");
				string text5 = this.statusBadgeId.Text.Length.ToString();
				if (Operators.CompareString(this.statusBadgeId.Text, "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
				}
				else if (Conversions.ToDouble(text5) > 9.0 | Conversions.ToDouble(text5) < 8.0)
				{
					this.statusBadgeId.Text = "";
					MessageBox.Show("Check Scanned Badge Id", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else
				{
					this.badgeid = this.statusBadgeId.Text;
					this.statusBadgeId.Enabled = Conversions.ToBoolean("False");
					if (this.lblMessage.Visible)
					{
						this.msgIcon.Visible = false;
						this.lblMessage.Visible = false;
					}
				}
			}
			else if (this.txtConfigTableId.Focused == Conversions.ToBoolean("True"))
			{
				this.txtConfigTableId.Text = TheReaderData.Text.Replace("/O", "/");
				string text6 = this.txtConfigTableId.Text.Length.ToString();
				if (Operators.CompareString(this.txtConfigTableId.Text, "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
					this.txtConfigTableId.Text = "";
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else
				{
					this.ConfigTableId = this.txtConfigTableId.Text;
					this.txtConfigTableId.Enabled = Conversions.ToBoolean("False");
				}
			}
			else if (this.txtConfigDepartmentCode.Focused == Conversions.ToBoolean("True"))
			{
				this.txtConfigDepartmentCode.Text = TheReaderData.Text.Replace("/O", "/");
				string text7 = this.txtConfigDepartmentCode.Text.Length.ToString();
				if (Operators.CompareString(this.txtConfigDepartmentCode.Text, "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
					this.txtConfigTableId.Text = "";
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
				}
				else
				{
					this.ConfigDepartmentCode = this.txtConfigDepartmentCode.Text;
					this.txtConfigDepartmentCode.Enabled = Conversions.ToBoolean("False");
				}
			}
		}

		// Token: 0x060000FE RID: 254 RVA: 0x00018974 File Offset: 0x00016D74
		private void SmartApp_Closing(object sender, CancelEventArgs e)
		{
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.DetachReadNotify();
				this.myScanSampleAPI.DetachStatusNotify();
				this.myScanSampleAPI.TermReader();
				this.Activated -= this.myFormActivatedEventHandler;
				this.Deactivate -= this.myFormDeactivatedEventHandler;
			}
		}

		// Token: 0x060000FF RID: 255 RVA: 0x000189CC File Offset: 0x00016DCC
		private void btnBack_Click(object sender, EventArgs e)
		{
			this.ClearScanData();
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
			this.tbActivities.SelectedIndex = 1;
		}

		// Token: 0x06000100 RID: 256 RVA: 0x000189FC File Offset: 0x00016DFC
		private void pcLegnano_Click(object sender, EventArgs e)
		{
			if (!this.pcClose.Visible)
			{
				this.pcClose.Enabled = true;
				this.pcClose.Visible = true;
			}
			else if (this.pcClose.Visible)
			{
				this.pcClose.Enabled = false;
				this.pcClose.Visible = false;
			}
		}

		// Token: 0x06000101 RID: 257 RVA: 0x00018A5C File Offset: 0x00016E5C
		public void InsertInEquipmentScrum()
		{
			string[] array = this.statusJobNo.Text.Split(new char[]
			{
				'/'
			});
			string[] array2 = this.statusCoreNo.Text.Split(new char[]
			{
				'/'
			});
			string text = this.lblTableId.Text;
			string job = array[0];
			string item = array[1];
			string text2 = array2[0];
			string text3 = array2[1];
			string text4 = this.statusActivity.Text;
			string text5 = this.StatusName.Text.Trim();
			try
			{
				try
				{
					short num = Convert.ToInt16(SmartApp.createWebService().DoingEquipmentScrum(job, item, text2, text3));
					if (num <= 0)
					{
						SmartApp.createWebService().InsertEquipmentScrum(text, job, item, Conversions.ToInteger(text2), Conversions.ToInteger(text3), this.Myactivity, this.StatusName.Text);
					}
					else
					{
						SmartApp.createWebService().UpdateEquipmentScrum(text, job, item, text2, text3, this.Myactivity, this.StatusName.Text);
					}
				}
				catch (SqlException ex)
				{
					throw new Exception("Check connection with machine");
				}
			}
			catch (Exception ex2)
			{
				throw new Exception("Check connection with machine");
			}
		}

		// Token: 0x06000102 RID: 258 RVA: 0x00018BC4 File Offset: 0x00016FC4
		public void InsertInScrumTable()
		{
			string[] array = this.statusJobNo.Text.Split(new char[]
			{
				'/'
			});
			string[] array2 = this.statusCoreNo.Text.Split(new char[]
			{
				'/'
			});
			string text = this.lblTableId.Text;
			string job = array[0];
			string item = array[1];
			string text2 = array2[0];
			string text3 = array2[1];
			string myactivity = this.Myactivity;
			string text4 = this.StatusName.Text.Trim();
			string strNetworkAddress = GlobalVariables.strNetworkAddress;
			string strNetworkUsername = GlobalVariables.strNetworkUsername;
			string strNetworkPassword = GlobalVariables.strNetworkPassword;
			string strNetworkDB = GlobalVariables.strNetworkDB;
			string text5 = SmartApp.createWebService().CheckRecords(job, item, Conversions.ToInteger(text3));
			try
			{
				short num = Conversions.ToShort(text5);
				if (num <= 0)
				{
					int toDo = checked((int)Math.Round(unchecked(Conversions.ToDouble(text3) - 1.0)));
					int doing = 1;
					int done = 0;
					SmartApp.createWebService().InsertScrumTable(job, item, Conversions.ToInteger(text3), toDo, doing, done);
				}
				else
				{
					this.CheckToDo();
				}
			}
			catch (SqlException ex)
			{
				throw new Exception("Check connection with machine");
			}
		}

		// Token: 0x06000103 RID: 259 RVA: 0x00018D0C File Offset: 0x0001710C
		public void CheckToDo()
		{
			string[] array = this.statusJobNo.Text.Split(new char[]
			{
				'/'
			});
			string[] array2 = this.statusCoreNo.Text.Split(new char[]
			{
				'/'
			});
			string text = this.lblTableId.Text;
			string job = array[0];
			string item = array[1];
			string text2 = array2[0];
			string text3 = array2[1];
			string myactivity = this.Myactivity;
			string text4 = this.StatusName.Text.Trim();
			try
			{
				short toDo = Convert.ToInt16(SmartApp.createWebService().ToDoquery(job, item, text3));
				this.ToDo = (int)toDo;
			}
			catch (Exception ex)
			{
				throw new Exception("Check connection with machine");
			}
			checked
			{
				try
				{
					short done = Convert.ToInt16(SmartApp.createWebService().Donequery(job, item, text3));
					this.Done = (int)done;
					if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.Text, "END", false) == 0)
					{
						this.Done++;
					}
				}
				catch (Exception ex2)
				{
					throw new Exception("Check connection with machine");
				}
				try
				{
					short doing = Convert.ToInt16(SmartApp.createWebService().DoingQuery(job, item, text3));
					this.Doing = (int)doing;
					if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.Text, "END", false) == 0)
					{
						this.Doing--;
					}
				}
				catch (SqlException ex3)
				{
					throw new Exception("Check connection with machine");
				}
				if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.Text, "END", false) == 0)
				{
					this.ToDo = (int)Math.Round(unchecked(Conversions.ToDouble(text3) - (double)(checked(this.Doing + this.Done))));
					SmartApp.createWebService().UpdateScrumTableOnEndClosing(job, item, text3, this.ToDo, this.Doing, this.Done);
				}
				else if (Operators.CompareString(this.Myactivity, "NON CONFORMITY", false) == 0 & Operators.CompareString(this.StatusName.Text, "START", false) == 0)
				{
					if (this.Doing >= 1)
					{
						this.Doing--;
						this.ToDo++;
						SmartApp.createWebService().UpdateScrumTableOnStartConformity(job, item, this.ToDo, this.Doing, text3);
					}
				}
				else
				{
					this.ToDo = (int)Math.Round(unchecked(Conversions.ToDouble(text3) - (double)(checked(this.Doing + this.Done))));
					SmartApp.createWebService().UpdateScrumTable(job, item, text3, this.ToDo, this.Doing, this.Done);
				}
			}
		}

		// Token: 0x06000104 RID: 260 RVA: 0x00019034 File Offset: 0x00017434
		public void MonitoringAndCounterCalculation()
		{
			string[] array = this.statusJobNo.Text.Split(new char[]
			{
				'/'
			});
			string[] array2 = this.statusCoreNo.Text.Split(new char[]
			{
				'/'
			});
			string text = this.lblTableId.Text;
			string job = array[0];
			string item = array[1];
			string core = array2[0];
			string coreTotal = array2[1];
			string myactivity = this.Myactivity;
			string text2 = this.StatusName.Text.Trim();
			string strNetworkAddress = GlobalVariables.strNetworkAddress;
			string strNetworkUsername = GlobalVariables.strNetworkUsername;
			string strNetworkPassword = GlobalVariables.strNetworkPassword;
			string strNetworkDB = GlobalVariables.strNetworkDB;
			if (Operators.CompareString(this.Myactivity, "SETUP", false) == 0 & Operators.CompareString(this.StatusName.Text, "START", false) == 0)
			{
				this.InsertInEquipmentScrum();
				this.InsertInScrumTable();
			}
			else if (Operators.CompareString(this.Myactivity, "SETUP", false) == 0 & Operators.CompareString(this.StatusName.Text, "END", false) == 0)
			{
				this.InsertInEquipmentScrum();
			}
			else if (Operators.CompareString(this.Myactivity, "ASSEMBLY", false) == 0 & Operators.CompareString(this.StatusName.Text, "START", false) == 0)
			{
				this.InsertInEquipmentScrum();
			}
			else if (Operators.CompareString(this.Myactivity, "ASSEMBLY", false) == 0 & Operators.CompareString(this.StatusName.Text, "END", false) == 0)
			{
				this.InsertInEquipmentScrum();
			}
			else if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.Text, "START", false) == 0)
			{
				this.InsertInEquipmentScrum();
			}
			else if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.Text, "END", false) == 0)
			{
				this.CheckToDo();
				if (Operators.CompareString(this.statusActivity.Text, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.Text, "END", false) == 0)
				{
					try
					{
						SmartApp.createWebService().DeleteFinishedEquipmentScrum(job, item, core, coreTotal);
					}
					catch (Exception ex)
					{
						MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
						Application.Exit();
					}
				}
			}
			else if (Operators.CompareString(this.Myactivity, "NON CONFORMITY", false) == 0 & Operators.CompareString(this.StatusName.Text, "START", false) == 0)
			{
				try
				{
					SmartApp.createWebService().DeleteFinishedEquipmentScrum(job, item, core, coreTotal);
				}
				catch (Exception ex2)
				{
					MessageBox.Show("Error!" + ex2.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
					Application.Exit();
				}
				try
				{
					SmartApp.createWebService().DeleteItemInWP(job, item, core, coreTotal);
				}
				catch (Exception ex3)
				{
					MessageBox.Show("Error!" + ex3.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
					Application.Exit();
				}
			}
		}

		// Token: 0x06000105 RID: 261 RVA: 0x000193E0 File Offset: 0x000177E0
		private void pcClose_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000106 RID: 262 RVA: 0x000193EC File Offset: 0x000177EC
		private void btn1Activity_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.ValidateBusyTable())
				{
					this.activity = "SETUP";
					this.txtActivityName.Text = this.activity;
					this.ClearScanData();
					this.txtBadgeId.Focus();
					this.tbActivities.SelectedIndex = 2;
					this.pcSettings.Enabled = false;
					this.pcSettings.Visible = false;
					this.CheckConnectionSettings();
				}
				else
				{
					MessageBox.Show("The table is busy", GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				Application.Exit();
			}
		}

		// Token: 0x06000107 RID: 263 RVA: 0x000194D8 File Offset: 0x000178D8
		private void btn2Activity_Click(object sender, EventArgs e)
		{
			try
			{
				this.activity = "ASSEMBLY";
				this.txtActivityName.Text = this.activity;
				this.ClearScanData();
				this.txtBadgeId.Focus();
				this.tbActivities.SelectedIndex = 2;
				this.pcSettings.Enabled = false;
				this.pcSettings.Visible = false;
				this.CheckConnectionSettings();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				Application.Exit();
			}
		}

		// Token: 0x06000108 RID: 264 RVA: 0x00019598 File Offset: 0x00017998
		private void btn3Activity_Click(object sender, EventArgs e)
		{
			try
			{
				this.activity = "CLOSING";
				this.txtActivityName.Text = this.activity;
				this.ClearScanData();
				this.txtBadgeId.Focus();
				this.tbActivities.SelectedIndex = 2;
				this.pcSettings.Enabled = false;
				this.pcSettings.Visible = false;
				this.CheckConnectionSettings();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				Application.Exit();
			}
		}

		// Token: 0x06000109 RID: 265 RVA: 0x00019658 File Offset: 0x00017A58
		private void btn4Activity_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.ValidateBusyTable())
				{
					this.activity = "NON CONFORMITY";
					this.txtActivityName.Text = this.activity;
					this.ClearScanData();
					this.txtBadgeId.Focus();
					this.tbActivities.SelectedIndex = 2;
					this.pcSettings.Enabled = false;
					this.pcSettings.Visible = false;
					this.CheckConnectionSettings();
				}
				else
				{
					MessageBox.Show("The table is busy", GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				Application.Exit();
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x0600010A RID: 266 RVA: 0x00019744 File Offset: 0x00017B44
		public string Myactivity
		{
			get
			{
				return this.activity;
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x0600010B RID: 267 RVA: 0x0001975C File Offset: 0x00017B5C
		public string MyBadgeId
		{
			get
			{
				return this.badgeid;
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x0600010C RID: 268 RVA: 0x00019774 File Offset: 0x00017B74
		public string MyCustomerNo
		{
			get
			{
				return this.CustomerNo;
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x0600010D RID: 269 RVA: 0x0001978C File Offset: 0x00017B8C
		public string MyDescription
		{
			get
			{
				return this.Description;
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x0600010E RID: 270 RVA: 0x000197A4 File Offset: 0x00017BA4
		public string MyWeight
		{
			get
			{
				return this.NetWeight;
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x0600010F RID: 271 RVA: 0x000197BC File Offset: 0x00017BBC
		public string MyNonConformityDoing
		{
			get
			{
				return this.NonConformityDoing;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06000110 RID: 272 RVA: 0x000197D4 File Offset: 0x00017BD4
		public string MyJobNo
		{
			get
			{
				return this.jobno;
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000111 RID: 273 RVA: 0x000197EC File Offset: 0x00017BEC
		public string MyCoreNo
		{
			get
			{
				return this.coreno;
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000112 RID: 274 RVA: 0x00019804 File Offset: 0x00017C04
		public string MyTableId
		{
			get
			{
				return this.tableid;
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000113 RID: 275 RVA: 0x0001981C File Offset: 0x00017C1C
		public string MyDepartmentCode
		{
			get
			{
				return this.tableid;
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x06000114 RID: 276 RVA: 0x00019834 File Offset: 0x00017C34
		public string MyNoOfOperator
		{
			get
			{
				return this.NoOfOperator;
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000115 RID: 277 RVA: 0x0001984C File Offset: 0x00017C4C
		public string MyTimeValue
		{
			get
			{
				return Conversions.ToString(this.myTime);
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06000116 RID: 278 RVA: 0x0001986C File Offset: 0x00017C6C
		public string MyJobStatus
		{
			get
			{
				return this.jobstatus;
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000117 RID: 279 RVA: 0x00019884 File Offset: 0x00017C84
		public string MyBadgeStart
		{
			get
			{
				return this.BadgeStart;
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000118 RID: 280 RVA: 0x0001989C File Offset: 0x00017C9C
		public string MyStartDate
		{
			get
			{
				return this.StartDate;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000119 RID: 281 RVA: 0x000198B4 File Offset: 0x00017CB4
		public string MyBadgeEnd
		{
			get
			{
				return this.BadgeEnd;
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x0600011A RID: 282 RVA: 0x000198CC File Offset: 0x00017CCC
		public string MyEndDate
		{
			get
			{
				return this.EndDate;
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x0600011B RID: 283 RVA: 0x000198E4 File Offset: 0x00017CE4
		public string MyConfigTableId
		{
			get
			{
				return this.ConfigTableId;
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x0600011C RID: 284 RVA: 0x000198FC File Offset: 0x00017CFC
		public string MyConfigDepartmentCode
		{
			get
			{
				return this.ConfigDepartmentCode;
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x0600011D RID: 285 RVA: 0x00019914 File Offset: 0x00017D14
		public string MyCoreDescription
		{
			get
			{
				return this.CoreDescription;
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x0600011E RID: 286 RVA: 0x0001992C File Offset: 0x00017D2C
		public string MyWeightForUnitKg
		{
			get
			{
				return Conversions.ToString(this.WeightForUnitKg);
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x0600011F RID: 287 RVA: 0x0001994C File Offset: 0x00017D4C
		public string MyCustomerDescription
		{
			get
			{
				return this.CustomerDescription;
			}
		}

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x06000120 RID: 288 RVA: 0x00019964 File Offset: 0x00017D64
		public string MyToDo
		{
			get
			{
				return Conversions.ToString(this.ToDo);
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x06000121 RID: 289 RVA: 0x00019984 File Offset: 0x00017D84
		public string MyDoing
		{
			get
			{
				return Conversions.ToString(this.Doing);
			}
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x06000122 RID: 290 RVA: 0x000199A4 File Offset: 0x00017DA4
		public string MyDone
		{
			get
			{
				return Conversions.ToString(this.Done);
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x06000123 RID: 291 RVA: 0x000199C4 File Offset: 0x00017DC4
		public string MyThicknessmm
		{
			get
			{
				return Conversions.ToString(this.ThicknessInmm);
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x06000124 RID: 292 RVA: 0x000199E4 File Offset: 0x00017DE4
		public string MyCustomerName
		{
			get
			{
				return this.CustomerName;
			}
		}

		// Token: 0x06000125 RID: 293 RVA: 0x000199FC File Offset: 0x00017DFC
		private void btnPauseJob_Click(object sender, EventArgs e)
		{
			this.CheckConnectionSettings();
			this.jobstatus = "PAUSE";
			this.Timer2.Enabled = Conversions.ToBoolean("False");
			this.stopwatch.Stop();
			this.StatusName.Text = this.jobstatus;
			this.StartJob.Enabled = false;
			this.btnPauseJob.Enabled = false;
			this.btnResume.Enabled = true;
			this.btnResume.Focus();
			this.btnEndJob.Enabled = false;
			this.tbActivities.SelectedIndex = 0;
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00019AA0 File Offset: 0x00017EA0
		private void btnResume_Click(object sender, EventArgs e)
		{
			this.CheckConnectionSettings();
			this.Timer2.Enabled = Conversions.ToBoolean("True");
			this.stopwatch.Start();
			this.jobstatus = "RESUME";
			this.StatusName.Text = this.jobstatus;
			this.btnPauseJob.Enabled = true;
			this.btnPauseJob.Focus();
			this.btnEndJob.Enabled = true;
			this.StartJob.Enabled = false;
			this.btnResume.Enabled = false;
			this.tbActivities.SelectedIndex = 0;
		}

		// Token: 0x06000127 RID: 295 RVA: 0x00019B44 File Offset: 0x00017F44
		private void btnEndJob_Click(object sender, EventArgs e)
		{
			if (Operators.CompareString(this.statusBadgeId.Text, "", false) == 0)
			{
				MessageBox.Show("Scan the Badge Id", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
				this.statusBadgeId.Focus();
			}
			else
			{
				this.BadgeEnd = this.statusBadgeId.Text;
				this.EndDate = this.lblTime.Text;
				this.Timer2.Enabled = false;
				this.stopwatch.Reset();
				this.CheckConnectionSettings();
				this.jobstatus = "END";
				this.StatusName.Text = this.jobstatus;
				if (Operators.CompareString(this.Myactivity, "NON CONFORMITY", false) == 0)
				{
					this.UpdateInNetworkForNonConformity();
				}
				else
				{
					this.UpdateInNetwork();
				}
				this.MonitoringAndCounterCalculation();
				this.StartJob.Enabled = false;
				this.pcSettings.Enabled = true;
				this.pcSettings.Visible = true;
				this.tbActivities.SelectedIndex = 1;
				this.statusTime.Text = "00:00:00";
				if (Operators.CompareString(this.Myactivity, "CLOSING", false) == 0 & Operators.CompareString(this.StatusName.Text, "END", false) == 0)
				{
					this.txtJobNo.Text = "";
					this.txtJobNo.Enabled = true;
					this.txtCoreNo.Text = "";
					this.txtCoreNo.Enabled = true;
				}
				if (Operators.CompareString(this.Myactivity, "NON CONFORMITY", false) == 0 & Operators.CompareString(this.StatusName.Text, "END", false) == 0)
				{
					this.txtJobNo.Text = "";
					this.txtJobNo.Enabled = true;
					this.txtCoreNo.Text = "";
					this.txtCoreNo.Enabled = true;
				}
			}
		}

		// Token: 0x06000128 RID: 296 RVA: 0x00019D48 File Offset: 0x00018148
		private void CheckConnectionSettings()
		{
			this.readConfigValues();
			try
			{
				string strNetworkAddress = GlobalVariables.strNetworkAddress;
				string strNetworkUsername = GlobalVariables.strNetworkUsername;
				string strNetworkPassword = GlobalVariables.strNetworkPassword;
				string strNetworkDB = GlobalVariables.strNetworkDB;
				if (SmartApp.createWebService().TestFirstDBConnection() & SmartApp.createWebService().TestSecondDBConnection())
				{
					this.SyncServerTime();
					this.myconnection = true;
				}
				else
				{
					this.myTime = Conversions.ToDate(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
					this.myconnection = false;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				Application.Exit();
			}
		}

		// Token: 0x06000129 RID: 297 RVA: 0x00019E18 File Offset: 0x00018218
		private void SyncServerTime()
		{
			try
			{
				this.myTime = Convert.ToDateTime(SmartApp.createWebService().GetCustomDate(), new CultureInfo("fr-FR"));
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				Application.Exit();
			}
		}

		// Token: 0x0600012A RID: 298 RVA: 0x00019E98 File Offset: 0x00018298
		public string RemoveWhitespace(string fullString)
		{
			return new string(Enumerable.ToArray<char>(Enumerable.Where<char>(fullString, (char x) => !char.IsWhiteSpace(x))));
		}

		// Token: 0x0600012B RID: 299 RVA: 0x00019EC8 File Offset: 0x000182C8
		private void UpdateInNetwork()
		{
			try
			{
				try
				{
					string strNetworkAddress = GlobalVariables.strNetworkAddress;
					string strNetworkUsername = GlobalVariables.strNetworkUsername;
					string strNetworkPassword = GlobalVariables.strNetworkPassword;
					string strNetworkDB = GlobalVariables.strNetworkDB;
					string[] array = this.statusJobNo.Text.Split(new char[]
					{
						'/'
					});
					string job = array[0];
					string item = array[1];
					string[] array2 = this.statusCoreNo.Text.Split(new char[]
					{
						'/'
					});
					string text = array2[0];
					string text2 = array2[1];
					string text3 = this.EndDate.ToString();
					DateTime dateEnd = DateTime.ParseExact(text3, "dd/MM/yyyy HH:mm:ss", DateTimeFormatInfo.InvariantInfo);
					SmartApp.createWebService().UpdateWorkInNetwork(this.BadgeEnd, dateEnd, job, item, Conversions.ToInteger(text), Conversions.ToInteger(text2), this.lblTableId.Text, this.NumericNoOfOperator.Value, this.statusActivity.Text);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
					Application.Exit();
				}
				finally
				{
				}
				if (Operators.CompareString(this.jobstatus, "START", false) == 0)
				{
					this.StartJob.Enabled = false;
					this.tbActivities.SelectedIndex = 0;
				}
				else if (Operators.CompareString(this.jobstatus, "END", false) == 0)
				{
					this.StartJob.Enabled = false;
					this.pcSettings.Enabled = true;
					this.pcSettings.Visible = true;
					this.tbActivities.SelectedIndex = 1;
				}
			}
			catch (Exception ex2)
			{
				throw ex2;
			}
		}

		// Token: 0x0600012C RID: 300 RVA: 0x0001A0D0 File Offset: 0x000184D0
		private void UpdateInNetworkForNonConformity()
		{
			try
			{
				try
				{
					string strNetworkAddress = GlobalVariables.strNetworkAddress;
					string strNetworkUsername = GlobalVariables.strNetworkUsername;
					string strNetworkPassword = GlobalVariables.strNetworkPassword;
					string strNetworkDB = GlobalVariables.strNetworkDB;
					string[] array = this.statusJobNo.Text.Split(new char[]
					{
						'/'
					});
					string job = array[0];
					string item = array[1];
					string[] array2 = this.statusCoreNo.Text.Split(new char[]
					{
						'/'
					});
					string text = array2[0];
					string text2 = array2[1];
					string text3 = this.StartDate.ToString();
					string text4 = this.EndDate.ToString();
					DateTime dateStart = DateTime.ParseExact(text3, "dd/MM/yyyy HH:mm:ss", DateTimeFormatInfo.InvariantInfo);
					DateTime dateEnd = DateTime.ParseExact(text4, "dd/MM/yyyy HH:mm:ss", DateTimeFormatInfo.InvariantInfo);
					SmartApp.createWebService().UpdateWorkInProgressNC(this.BadgeEnd, dateEnd, job, item, Conversions.ToInteger(text), this.BadgeStart, dateStart);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
					Application.Exit();
				}
				finally
				{
				}
				if (Operators.CompareString(this.jobstatus, "START", false) == 0)
				{
					this.StartJob.Enabled = false;
					this.tbActivities.SelectedIndex = 0;
				}
				else if (Operators.CompareString(this.jobstatus, "END", false) == 0)
				{
					this.StartJob.Enabled = false;
					this.pcSettings.Enabled = true;
					this.pcSettings.Visible = true;
					this.tbActivities.SelectedIndex = 1;
				}
			}
			catch (Exception ex2)
			{
				MessageBox.Show("Error!" + ex2.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				Application.Exit();
			}
		}

		// Token: 0x0600012D RID: 301 RVA: 0x0001A304 File Offset: 0x00018704
		private void SmartApp_Load(object sender, EventArgs e)
		{
			try
			{
				this.CheckConnectionSettings();
				this.readSettingsFromXML();
				if (this.myconnection)
				{
					this.tbActivities.SelectedIndex = 1;
					this.Timer1.Enabled = true;
					this.readConfigValues();
					this.myScanSampleAPI = new ScanApp.VB_BarcodeSample1.API();
					this.isReaderInitiated = this.myScanSampleAPI.InitReader();
					if (!this.isReaderInitiated)
					{
						MessageBox.Show(Resources.GetString("AppExitMsg"));
						Application.Exit();
					}
					else
					{
						this.lblMessage.Text = "";
						this.myStatusNotifyHandler = new EventHandler(this.myReader_StatusNotify);
						this.myScanSampleAPI.AttachStatusNotify(this.myStatusNotifyHandler);
					}
				}
				else
				{
					MessageBox.Show("Check Connection Settings");
					Application.Exit();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, GlobalVariables.strMessagePrefixError.Trim() + "Settings", 0, 48, 0);
				Application.Exit();
			}
		}

		// Token: 0x0600012E RID: 302 RVA: 0x0001A424 File Offset: 0x00018824
		private void txtScanOperator_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				this.myReadNotifyHandler = new EventHandler(this.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		// Token: 0x0600012F RID: 303 RVA: 0x0001A47C File Offset: 0x0001887C
		private void txtSerialNo_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				this.myReadNotifyHandler = new EventHandler(this.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		// Token: 0x06000130 RID: 304 RVA: 0x0001A4D4 File Offset: 0x000188D4
		private void txtStationId_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				this.myReadNotifyHandler = new EventHandler(this.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		// Token: 0x06000131 RID: 305 RVA: 0x0001A52C File Offset: 0x0001892C
		private void txtScanOperator_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		// Token: 0x06000132 RID: 306 RVA: 0x0001A548 File Offset: 0x00018948
		private void txtSerialNo_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		// Token: 0x06000133 RID: 307 RVA: 0x0001A564 File Offset: 0x00018964
		private void txtStationId_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		// Token: 0x06000134 RID: 308 RVA: 0x0001A580 File Offset: 0x00018980
		private void Timer1_Tick(object sender, EventArgs e)
		{
			DateTime dateTime = Conversions.ToDate(this.MyTimeValue).AddSeconds(1.0);
			this.lblTime.Text = dateTime.ToString("dd/MM/yyyy HH:mm:ss");
			this.lblTime.Visible = true;
			this.myTime = dateTime;
		}

		// Token: 0x06000135 RID: 309 RVA: 0x0001A5D8 File Offset: 0x000189D8
		private void WriteInNetwork()
		{
			try
			{
				try
				{
					string strNetworkAddress = GlobalVariables.strNetworkAddress;
					string strNetworkUsername = GlobalVariables.strNetworkUsername;
					string strNetworkPassword = GlobalVariables.strNetworkPassword;
					string strNetworkDB = GlobalVariables.strNetworkDB;
					string[] array = this.statusJobNo.Text.Split(new char[]
					{
						'/'
					});
					string text = array[0];
					string text2 = array[1];
					string[] array2 = this.statusCoreNo.Text.Split(new char[]
					{
						'/'
					});
					string text3 = array2[0];
					string text4 = array2[1];
					string text5 = this.StartDate.ToString();
					string text6 = this.EndDate.ToString();
					DateTime myStartDate = DateTime.ParseExact(text5, "dd/MM/yyyy HH:mm:ss", DateTimeFormatInfo.InvariantInfo);
					DataTable dataTable = SmartApp.createWebService().CopyDataFromDB(text, text2);
					if (dataTable.Rows.Count > 0)
					{
						this.CustomerNo = Convert.ToString(RuntimeHelpers.GetObjectValue(dataTable.Rows[0]["Sell-to Customer No_"]));
						this.Description = Convert.ToString(RuntimeHelpers.GetObjectValue(dataTable.Rows[0]["Description"]));
						this.NetWeight = Convert.ToString(RuntimeHelpers.GetObjectValue(dataTable.Rows[0]["Net Weight"]));
					}
					this.CustomerName = SmartApp.createWebService().QryCustomerName(text);
					SmartApp.createWebService().InsertInNetwork(text, text2, this.CustomerNo, this.CustomerName, this.Description, Conversions.ToInteger(text3), Conversions.ToInteger(text4), this.lblTableId.Text, this.statusActivity.Text, this.BadgeStart, myStartDate, Conversions.ToDecimal(this.NoOfOperator), this.lblDepartmentCode.Text, Conversions.ToDecimal(this.NetWeight), this.ThicknessInmm, this.StackInmm, this.Column1MeasureInmm, this.CentralMeasureInmm, this.Column2MeasureInmm);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
					Application.Exit();
				}
				finally
				{
				}
				if (Operators.CompareString(this.jobstatus, "START", false) == 0)
				{
					this.StartJob.Enabled = false;
					this.tbActivities.SelectedIndex = 0;
				}
				else if (Operators.CompareString(this.jobstatus, "END", false) == 0)
				{
					this.StartJob.Enabled = false;
					this.pcSettings.Enabled = true;
					this.pcSettings.Visible = true;
					this.tbActivities.SelectedIndex = 1;
				}
			}
			catch (Exception ex2)
			{
				MessageBox.Show("Error!" + ex2.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				Application.Exit();
			}
		}

		// Token: 0x06000136 RID: 310 RVA: 0x0001A908 File Offset: 0x00018D08
		private void WriteInNetworkForNonConformity()
		{
			this.CheckToDo();
			if (Conversions.ToDouble(this.NonConformityDoing) >= 1.0)
			{
				try
				{
					string strNetworkAddress = GlobalVariables.strNetworkAddress;
					string strNetworkUsername = GlobalVariables.strNetworkUsername;
					string strNetworkPassword = GlobalVariables.strNetworkPassword;
					string strNetworkDB = GlobalVariables.strNetworkDB;
					string[] array = this.statusJobNo.Text.Split(new char[]
					{
						'/'
					});
					string job = array[0];
					string item = array[1];
					string[] array2 = this.statusCoreNo.Text.Split(new char[]
					{
						'/'
					});
					string text = array2[0];
					string text2 = array2[1];
					string text3 = this.StartDate.ToString();
					string text4 = this.EndDate.ToString();
					DateTime myStartDate = DateTime.ParseExact(text3, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
					string subOperation = "0";
					string descriptionStart = "0";
					string descriptionEnd = "0";
					string block = "0";
					SmartApp.createWebService().InsertWorkInProgressNC(job, item, Conversions.ToInteger(text), subOperation, this.BadgeStart, myStartDate, this.lblDepartmentCode.Text, descriptionStart, descriptionEnd, block);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
					Application.Exit();
				}
				finally
				{
				}
				if (Operators.CompareString(this.jobstatus, "START", false) == 0)
				{
					this.StartJob.Enabled = false;
					this.tbActivities.SelectedIndex = 0;
				}
				else if (Operators.CompareString(this.jobstatus, "END", false) == 0)
				{
					this.StartJob.Enabled = false;
					this.pcSettings.Enabled = true;
					this.pcSettings.Visible = true;
					this.tbActivities.SelectedIndex = 1;
				}
			}
		}

		// Token: 0x06000137 RID: 311 RVA: 0x0001AB18 File Offset: 0x00018F18
		private bool ValidateBusyTable()
		{
			string text = this.lblTableId.Text;
			string text2 = SmartApp.createWebService().CheckTableIsBusy(text);
			int num = Convert.ToInt32(text2);
			return num < 1;
		}

		// Token: 0x06000138 RID: 312 RVA: 0x0001AB58 File Offset: 0x00018F58
		private bool Validate()
		{
			string[] array = this.txtJobNo.Text.Split(new char[]
			{
				'/'
			});
			string[] array2 = this.txtCoreNo.Text.Split(new char[]
			{
				'/'
			});
			string text = this.lblTableId.Text;
			string documentNo = array[0];
			string posizione = array[1];
			string text2 = array2[0];
			string text3 = array2[1];
			string myactivity = this.Myactivity;
			string text4 = this.StatusName.Text.Trim();
			this.readConfigValues();
			string verifyServer = GlobalVariables.VerifyServer;
			string verifyUser = GlobalVariables.VerifyUser;
			string verifyPwd = GlobalVariables.VerifyPwd;
			string verifyDB = GlobalVariables.VerifyDB;
			string verifyTable = GlobalVariables.VerifyTable;
			bool result;
			try
			{
				short num = Convert.ToInt16(SmartApp.createWebService().ValidateData(documentNo, posizione));
				if (num == 0)
				{
					MessageBox.Show("Job is not registered", GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
					this.txtJobNo.Text = "";
					this.txtJobNo.Enabled = Conversions.ToBoolean("True");
					this.txtJobNo.Focus();
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
					result = false;
				}
				else if (this.ValidateDuplicateEntry())
				{
					result = true;
				}
				else
				{
					result = false;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				Application.Exit();
			}
			return result;
		}

		// Token: 0x06000139 RID: 313 RVA: 0x0001AD08 File Offset: 0x00019108
		private bool ValidateDuplicateEntry()
		{
			string[] array = this.txtJobNo.Text.Split(new char[]
			{
				'/'
			});
			string[] array2 = this.txtCoreNo.Text.Split(new char[]
			{
				'/'
			});
			string text = this.lblTableId.Text;
			string job = array[0];
			string item = array[1];
			string core = array2[0];
			string coreTotal = array2[1];
			string myactivity = this.Myactivity;
			string text2 = this.StatusName.Text.Trim();
			this.readConfigValues();
			string strNetworkAddress = GlobalVariables.strNetworkAddress;
			string strNetworkUsername = GlobalVariables.strNetworkUsername;
			string strNetworkPassword = GlobalVariables.strNetworkPassword;
			string strNetworkDB = GlobalVariables.strNetworkDB;
			bool result;
			try
			{
				short num = Convert.ToInt16(SmartApp.createWebService().ValidateDuplicateEntry(job, item, core, coreTotal, myactivity));
				short num2 = Convert.ToInt16(SmartApp.createWebService().DoingEquipmentScrum(job, item, core, coreTotal));
				this.NonConformityDoing = Conversions.ToString((int)num2);
				if (num > 0)
				{
					MessageBox.Show("Duplicate Entry not allowed", GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
					this.txtJobNo.Text = "";
					this.txtJobNo.Enabled = Conversions.ToBoolean("True");
					this.txtJobNo.Focus();
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
					result = false;
				}
				else if (Operators.CompareString(myactivity, "NON CONFORMITY", false) == 0 & Conversions.ToDouble(this.NonConformityDoing) == 0.0)
				{
					result = false;
				}
				else if (Operators.CompareString(myactivity, "ASSEMBLY", false) == 0 & Conversions.ToDouble(this.NonConformityDoing) == 0.0)
				{
					MessageBox.Show("Job is not yet started", GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
					this.txtJobNo.Text = "";
					this.txtJobNo.Enabled = Conversions.ToBoolean("True");
					this.txtCoreNo.Text = "";
					this.txtCoreNo.Enabled = Conversions.ToBoolean("True");
					this.txtJobNo.Focus();
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
					result = false;
				}
				else if (Operators.CompareString(myactivity, "CLOSING", false) == 0 & Conversions.ToDouble(this.NonConformityDoing) == 0.0)
				{
					MessageBox.Show("Job is not yet started", GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
					this.txtJobNo.Text = "";
					this.txtJobNo.Enabled = Conversions.ToBoolean("True");
					this.txtCoreNo.Text = "";
					this.txtCoreNo.Enabled = Conversions.ToBoolean("True");
					this.txtJobNo.Focus();
					Thread.Sleep(1000);
					this.myScanSampleAPI.StartRead(true);
					result = false;
				}
				else
				{
					result = true;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				Application.Exit();
			}
			return result;
		}

		// Token: 0x0600013A RID: 314 RVA: 0x0001B09C File Offset: 0x0001949C
		private void txtJobNo_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				this.myReadNotifyHandler = new EventHandler(this.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		// Token: 0x0600013B RID: 315 RVA: 0x0001B0F4 File Offset: 0x000194F4
		private void txtJobNo_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		// Token: 0x0600013C RID: 316 RVA: 0x0001B110 File Offset: 0x00019510
		private void txtJobNo_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == 13)
			{
				string text = this.txtJobNo.Text.Length.ToString();
				if (Operators.CompareString(this.txtJobNo.Text, "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
				}
				else if (this.txtJobNo.Text.Contains("-"))
				{
					MessageBox.Show("Check scanned barcode", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
				}
				else if (Operators.CompareString(this.txtBadgeId.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, this.txtJobNo.Text, false) == 0)
				{
					this.txtJobNo.Text = "";
					this.lblMessage.Text = "Operator Id has been scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
				}
				else if (Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, this.txtJobNo.Text, false) == 0)
				{
					this.txtJobNo.Text = "";
					this.lblMessage.Text = "Core No. has been scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
				}
				else if (Conversions.ToDouble(text) > 11.0 | Conversions.ToDouble(text) < 7.0)
				{
					this.txtJobNo.Text = "";
					MessageBox.Show("Check Scanned Job No. Details", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
				}
				else
				{
					this.jobno = this.txtJobNo.Text;
					this.txtJobNo.Enabled = false;
					if (Operators.CompareString(this.txtBadgeId.Text, "", false) == 0)
					{
						this.txtBadgeId.Focus();
					}
					else if (Operators.CompareString(this.txtCoreNo.Text, "", false) == 0)
					{
						this.txtCoreNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, "", false) != 0)
					{
						this.tbActivities.SelectedIndex = 2;
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.Visible)
					{
						this.msgIcon.Visible = false;
						this.lblMessage.Visible = false;
					}
				}
			}
		}

		// Token: 0x0600013D RID: 317 RVA: 0x0001B42C File Offset: 0x0001982C
		private void txtCoreNo_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				this.myReadNotifyHandler = new EventHandler(this.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		// Token: 0x0600013E RID: 318 RVA: 0x0001B484 File Offset: 0x00019884
		private void txtCoreNo_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		// Token: 0x0600013F RID: 319 RVA: 0x0001B4A0 File Offset: 0x000198A0
		private void txtCoreNo_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == 13)
			{
				string text = this.txtCoreNo.Text.Length.ToString();
				if (Operators.CompareString(this.txtCoreNo.Text, "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
				}
				else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtJobNo.Text, this.txtCoreNo.Text, false) == 0)
				{
					this.txtCoreNo.Text = "";
					this.lblMessage.Text = "Job No. already scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
				}
				else if (Operators.CompareString(this.txtBadgeId.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, this.txtCoreNo.Text, false) == 0)
				{
					this.txtCoreNo.Text = "";
					this.lblMessage.Text = "Operator Badge Id already scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
				}
				else if (Conversions.ToDouble(text) > 7.0 | Conversions.ToDouble(text) < 3.0)
				{
					this.txtCoreNo.Text = "";
					MessageBox.Show("Check Scanned Core No", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
				}
				else
				{
					this.coreno = this.txtCoreNo.Text;
					this.txtCoreNo.Enabled = false;
					if (Operators.CompareString(this.txtBadgeId.Text, "", false) == 0)
					{
						this.txtBadgeId.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.Text, "", false) == 0)
					{
						this.txtJobNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, "", false) != 0)
					{
						this.tbActivities.SelectedIndex = 2;
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.Visible)
					{
						this.msgIcon.Visible = false;
						this.lblMessage.Visible = false;
					}
				}
			}
		}

		// Token: 0x06000140 RID: 320 RVA: 0x0001B780 File Offset: 0x00019B80
		private void txtBadgeId_GotFocus(object sender, EventArgs e)
		{
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				this.myReadNotifyHandler = new EventHandler(this.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		// Token: 0x06000141 RID: 321 RVA: 0x0001B7C0 File Offset: 0x00019BC0
		private void txtBadgeId_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		// Token: 0x06000142 RID: 322 RVA: 0x0001B7DC File Offset: 0x00019BDC
		private void txtBadgeId_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == 13)
			{
				string text = this.txtBadgeId.Text.Length.ToString();
				if (Operators.CompareString(this.txtBadgeId.Text, "", false) == 0)
				{
					MessageBox.Show("Scan Barcode to Continue", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
				}
				else if (this.txtBadgeId.Text.Contains("/"))
				{
					MessageBox.Show("Scan Badge Id to Continue", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
					this.txtBadgeId.Text = "";
				}
				else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtJobNo.Text, this.txtBadgeId.Text, false) == 0)
				{
					this.txtBadgeId.Text = "";
					this.lblMessage.Text = "Job No. already scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
				}
				else if (Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, this.txtBadgeId.Text, false) == 0)
				{
					this.txtBadgeId.Text = "";
					this.lblMessage.Text = "Core No. already scanned";
					this.msgIcon.Visible = true;
					this.lblMessage.Visible = true;
				}
				else if (Conversions.ToDouble(text) > 9.0 | Conversions.ToDouble(text) < 8.0)
				{
					this.txtBadgeId.Text = "";
					MessageBox.Show("Check Scanned Badge Id", GlobalVariables.strMessagePrefixError + " Scan", 0, 16, 0);
				}
				else
				{
					this.badgeid = this.txtBadgeId.Text;
					this.txtBadgeId.Enabled = false;
					if (Operators.CompareString(this.txtJobNo.Text, "", false) == 0)
					{
						this.txtJobNo.Focus();
					}
					else if (Operators.CompareString(this.txtCoreNo.Text, "", false) == 0)
					{
						this.txtCoreNo.Focus();
					}
					else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, "", false) != 0)
					{
						this.tbActivities.SelectedIndex = 2;
						this.myScanSampleAPI.StopRead();
						this.myScanSampleAPI.DetachReadNotify();
					}
					if (this.lblMessage.Visible)
					{
						this.msgIcon.Visible = false;
						this.lblMessage.Visible = false;
					}
				}
			}
		}

		// Token: 0x06000143 RID: 323 RVA: 0x0001BB08 File Offset: 0x00019F08
		private void pcContinue_Click(object sender, EventArgs e)
		{
			if (Operators.CompareString(this.txtBadgeId.Text, "", false) == 0)
			{
				this.txtBadgeId.Focus();
				this.msgIcon.Visible = true;
				this.lblMessage.Text = "Provide Badge Id";
				this.lblMessage.Visible = true;
			}
			else if (Operators.CompareString(this.txtJobNo.Text, "", false) == 0)
			{
				this.txtJobNo.Focus();
				this.msgIcon.Visible = true;
				this.lblMessage.Text = "Provide Job No.";
				this.lblMessage.Visible = true;
			}
			else if (Operators.CompareString(this.txtCoreNo.Text, "", false) == 0)
			{
				this.txtCoreNo.Focus();
				this.msgIcon.Visible = true;
				this.lblMessage.Text = "Provide Core No.";
				this.lblMessage.Visible = true;
				this.NoOfOperator = this.MyNoOfOperator;
			}
			else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, "", false) != 0)
			{
				this.NumericNoOfOperator.Value = this.NoOfOperatorValue.Value;
				this.NoOfOperator = Conversions.ToString(this.NumericNoOfOperator.Value);
				if (this.Validate())
				{
					this.tbActivities.SelectedIndex = 0;
					this.GetDetailsForStatus();
					if (this.lblMessage.Visible)
					{
						this.msgIcon.Visible = false;
						this.lblMessage.Visible = false;
					}
				}
			}
		}

		// Token: 0x06000144 RID: 324 RVA: 0x0001BCF0 File Offset: 0x0001A0F0
		private void btnSaveConfig_Click(object sender, EventArgs e)
		{
			try
			{
				if (Operators.CompareString(this.txtConfigTableId.Text, "", false) == 0)
				{
					this.msgConfig.Visible = true;
					this.MsgIconConfig.Visible = true;
					this.msgConfig.Text = "Error ! Please provide Table Id";
					this.txtConfigTableId.Focus();
				}
				else if (Operators.CompareString(this.txtConfigDepartmentCode.Text, "", false) == 0)
				{
					this.msgConfig.Visible = true;
					this.MsgIconConfig.Visible = true;
					this.msgConfig.Text = "Error ! Please provide Department Code";
					this.txtConfigDepartmentCode.Focus();
				}
				else if (Operators.CompareString(this.txtConfigTableId.Text, "", false) != 0 & Operators.CompareString(this.txtConfigDepartmentCode.Text, "", false) != 0)
				{
					this.writeConfigValuesinXml();
					this.CheckConnectionSettings();
					this.readSettingsFromXML();
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		// Token: 0x06000145 RID: 325 RVA: 0x0001BE1C File Offset: 0x0001A21C
		private void btnCancelConfig_Click(object sender, EventArgs e)
		{
			this.txtConfigTableId.Text = "";
			this.txtConfigDepartmentCode.Text = "";
			this.MsgIconConfig.Visible = false;
			this.msgConfig.Visible = false;
			this.msgConfig.Text = "";
			this.CheckConnectionSettings();
			this.tbActivities.SelectedIndex = 1;
		}

		// Token: 0x06000146 RID: 326 RVA: 0x0001BE8C File Offset: 0x0001A28C
		private void pcSettings_Click(object sender, EventArgs e)
		{
			this.tbActivities.SelectedIndex = 3;
			this.txtConfigTableId.Enabled = Conversions.ToBoolean("True");
			this.txtConfigDepartmentCode.Enabled = Conversions.ToBoolean("True");
			this.readSettingsFromXML();
		}

		// Token: 0x06000147 RID: 327 RVA: 0x0001BEDC File Offset: 0x0001A2DC
		public void readSettingsFromXML()
		{
			try
			{
				DataSet dataSet = new DataSet();
				dataSet.ReadXml("\\Platform\\Barcode Gulf\\Config.xml");
				if (dataSet.Tables[0].Rows.Count > 0)
				{
					GlobalVariables.strDepartmentCode = dataSet.Tables[0].Rows[0]["DepartmentCode"].ToString().Trim();
					GlobalVariables.strTableId = dataSet.Tables[0].Rows[0]["TableId"].ToString().Trim();
					this.lblDepartmentCode.Text = GlobalVariables.strDepartmentCode;
					this.lblTableId.Text = GlobalVariables.strTableId;
					this.txtConfigDepartmentCode.Text = GlobalVariables.strDepartmentCode;
					this.txtConfigTableId.Text = GlobalVariables.strTableId;
				}
			}
			catch (Exception ex)
			{
				throw new Exception("Check Configuration Settings");
			}
		}

		// Token: 0x06000148 RID: 328 RVA: 0x0001BFEC File Offset: 0x0001A3EC
		private void btnSubtract_Click(object sender, EventArgs e)
		{
			decimal value = this.NoOfOperatorValue.Value;
			if (Convert.ToDouble(value) == Conversions.ToDouble("1"))
			{
				this.msgIcon.Visible = Conversions.ToBoolean("True");
				this.lblMessage.Text = "You have reached minimum operator limit";
				this.lblMessage.Visible = Conversions.ToBoolean("True");
			}
			else if (Convert.ToDouble(value) == Conversions.ToDouble("99"))
			{
				this.msgIcon.Visible = Conversions.ToBoolean("False");
				this.lblMessage.Visible = Conversions.ToBoolean("False");
				this.NoOfOperatorValue.Value = decimal.Subtract(this.NoOfOperatorValue.Value, 1m);
			}
			else
			{
				this.NoOfOperatorValue.Value = decimal.Subtract(this.NoOfOperatorValue.Value, 1m);
			}
		}

		// Token: 0x06000149 RID: 329 RVA: 0x0001C0E0 File Offset: 0x0001A4E0
		private void btnAdd_Click(object sender, EventArgs e)
		{
			decimal value = this.NoOfOperatorValue.Value;
			if (Convert.ToDouble(value) == Conversions.ToDouble("100"))
			{
				this.msgIcon.Visible = Conversions.ToBoolean("True");
				this.lblMessage.Text = "You have reached maximum operator limit";
				this.lblMessage.Visible = Conversions.ToBoolean("True");
			}
			else if (Convert.ToDouble(value) == Conversions.ToDouble("2"))
			{
				this.msgIcon.Visible = Conversions.ToBoolean("False");
				this.lblMessage.Visible = Conversions.ToBoolean("False");
				this.NoOfOperatorValue.Value = decimal.Add(this.NoOfOperatorValue.Value, 1m);
			}
			else
			{
				this.NoOfOperatorValue.Value = decimal.Add(this.NoOfOperatorValue.Value, 1m);
			}
		}

		// Token: 0x0600014A RID: 330 RVA: 0x0001C1D4 File Offset: 0x0001A5D4
		private void buttonBack_Click(object sender, EventArgs e)
		{
			this.tbActivities.SelectedIndex = 1;
			this.ClearScanData();
			if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0)
			{
				this.txtJobNo.Text = "";
				this.txtJobNo.Enabled = true;
			}
			if (Operators.CompareString(this.txtCoreNo.Text, "", false) != 0)
			{
				this.txtCoreNo.Text = "";
				this.txtCoreNo.Enabled = true;
			}
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
			this.pcSettings.Enabled = true;
			this.pcSettings.Visible = true;
		}

		// Token: 0x0600014B RID: 331 RVA: 0x0001C29C File Offset: 0x0001A69C
		private void buttonContinue_Click(object sender, EventArgs e)
		{
			if (Operators.CompareString(this.txtBadgeId.Text, "", false) == 0)
			{
				this.txtBadgeId.Focus();
				this.msgIcon.Visible = true;
				this.lblMessage.Text = "Provide Badge Id";
				this.lblMessage.Visible = true;
			}
			else if (Operators.CompareString(this.txtJobNo.Text, "", false) == 0)
			{
				this.txtJobNo.Focus();
				this.msgIcon.Visible = true;
				this.lblMessage.Text = "Provide Job No.";
				this.lblMessage.Visible = true;
			}
			else if (Operators.CompareString(this.txtCoreNo.Text, "", false) == 0)
			{
				this.txtCoreNo.Focus();
				this.msgIcon.Visible = true;
				this.lblMessage.Text = "Provide Core No.";
				this.lblMessage.Visible = true;
				this.NoOfOperator = this.MyNoOfOperator;
			}
			else if (Operators.CompareString(this.txtJobNo.Text, "", false) != 0 & Operators.CompareString(this.txtCoreNo.Text, "", false) != 0 & Operators.CompareString(this.txtBadgeId.Text, "", false) != 0)
			{
				this.NumericNoOfOperator.Value = this.NoOfOperatorValue.Value;
				this.NoOfOperator = Conversions.ToString(this.NumericNoOfOperator.Value);
				if (this.Validate())
				{
					this.ValidateSteps();
					this.pcSettings.Enabled = false;
					this.pcSettings.Visible = false;
					this.tbActivities.SelectedIndex = 0;
					this.CheckConnectionSettings();
					this.GetDetailsForStatus();
					this.StartJob.Focus();
					if (this.lblMessage.Visible)
					{
						this.msgIcon.Visible = false;
						this.lblMessage.Visible = false;
					}
				}
			}
		}

		// Token: 0x0600014C RID: 332 RVA: 0x0001C4B8 File Offset: 0x0001A8B8
		public void ValidateSteps()
		{
			if (Operators.CompareString(this.activity, "SETUP", false) == 0)
			{
				this.btn2Activity.Enabled = Conversions.ToBoolean("True");
				this.btn1Activity.Enabled = false;
			}
			else if (Operators.CompareString(this.activity, "ASSEMBLY", false) == 0)
			{
				this.btn3Activity.Enabled = Conversions.ToBoolean("True");
				this.btn2Activity.Enabled = Conversions.ToBoolean("False");
			}
			else if (Operators.CompareString(this.activity, "CLOSING", false) == 0)
			{
				this.btn3Activity.Enabled = Conversions.ToBoolean("False");
				this.btn1Activity.Enabled = Conversions.ToBoolean("True");
			}
			else if (Operators.CompareString(this.activity, "NON CONFORMITY", false) == 0)
			{
				this.btn2Activity.Enabled = Conversions.ToBoolean("False");
				this.btn3Activity.Enabled = Conversions.ToBoolean("False");
				this.btn1Activity.Enabled = Conversions.ToBoolean("True");
			}
		}

		// Token: 0x0600014D RID: 333 RVA: 0x0001C5E4 File Offset: 0x0001A9E4
		private void btnClr1_Click(object sender, EventArgs e)
		{
			this.txtConfigTableId.Text = "";
			this.txtConfigTableId.Focus();
		}

		// Token: 0x0600014E RID: 334 RVA: 0x0001C608 File Offset: 0x0001AA08
		private void btnClr2_Click(object sender, EventArgs e)
		{
			this.txtConfigDepartmentCode.Text = "";
			this.txtConfigDepartmentCode.Focus();
		}

		// Token: 0x0600014F RID: 335 RVA: 0x0001C62C File Offset: 0x0001AA2C
		private void Timer2_Tick(object sender, EventArgs e)
		{
			TimeSpan elapsed = this.stopwatch.Elapsed;
			this.statusTime.Text = string.Format("{0:00}:{1:00}:{2:00}", Math.Floor(elapsed.TotalHours), elapsed.Minutes, elapsed.Seconds);
		}

		// Token: 0x06000150 RID: 336 RVA: 0x0001C688 File Offset: 0x0001AA88
		private void txtConfigTableId_GotFocus(object sender, EventArgs e)
		{
			this.txtConfigTableId.SelectAll();
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				this.myReadNotifyHandler = new EventHandler(this.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		// Token: 0x06000151 RID: 337 RVA: 0x0001C6EC File Offset: 0x0001AAEC
		private void txtConfigTableId_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		// Token: 0x06000152 RID: 338 RVA: 0x0001C708 File Offset: 0x0001AB08
		private void txtConfigDepartmentCode_GotFocus(object sender, EventArgs e)
		{
			this.txtConfigDepartmentCode.SelectAll();
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				this.myReadNotifyHandler = new EventHandler(this.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		// Token: 0x06000153 RID: 339 RVA: 0x0001C76C File Offset: 0x0001AB6C
		private bool SearchTheTextValues()
		{
			return true;
		}

		// Token: 0x06000154 RID: 340 RVA: 0x0001C780 File Offset: 0x0001AB80
		private void txtConfigDepartmentCode_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		// Token: 0x06000155 RID: 341 RVA: 0x0001C79C File Offset: 0x0001AB9C
		private void statusBadgeId_GotFocus(object sender, EventArgs e)
		{
			Thread.Sleep(1000);
			if (this.isReaderInitiated)
			{
				this.myScanSampleAPI.StartRead(true);
				this.myReadNotifyHandler = new EventHandler(this.myReader_ReadNotify);
				this.myScanSampleAPI.AttachReadNotify(this.myReadNotifyHandler);
			}
		}

		// Token: 0x06000156 RID: 342 RVA: 0x0001C7F4 File Offset: 0x0001ABF4
		private void statusBadgeId_LostFocus(object sender, EventArgs e)
		{
			this.myScanSampleAPI.StopRead();
			this.myScanSampleAPI.DetachReadNotify();
		}

		// Token: 0x06000157 RID: 343 RVA: 0x0001C810 File Offset: 0x0001AC10
		private void StartJob_Click(object sender, EventArgs e)
		{
			try
			{
				this.BadgeStart = this.statusBadgeId.Text;
				this.StartDate = this.lblTime.Text;
				this.Timer2.Enabled = true;
				this.stopwatch.Start();
				this.CheckConnectionSettings();
				this.jobstatus = "START";
				this.StatusName.Text = this.jobstatus;
				if (Operators.CompareString(this.Myactivity, "NON CONFORMITY", false) == 0)
				{
					this.WriteInNetworkForNonConformity();
				}
				else
				{
					this.WriteInNetwork();
				}
				this.MonitoringAndCounterCalculation();
				this.StartJob.Enabled = false;
				this.btnPauseJob.Enabled = true;
				this.btnResume.Enabled = false;
				this.btnEndJob.Enabled = true;
				this.tbActivities.SelectedIndex = 0;
				this.statusBadgeId.Enabled = Conversions.ToBoolean("True");
				this.statusBadgeId.Text = "";
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error!" + ex.ToString(), GlobalVariables.strMessagePrefixWarning + " Scan", 0, 48, 0);
				Application.Exit();
			}
		}

		// Token: 0x06000158 RID: 344 RVA: 0x0001C968 File Offset: 0x0001AD68
		private void NoOfOperatorValue_ValueChanged(object sender, EventArgs e)
		{
			if (decimal.Compare(this.NoOfOperatorValue.Value, 1m) < 0)
			{
				this.msgIcon.Visible = Conversions.ToBoolean("True");
				this.lblMessage.Text = "You have reached minimum operator limit";
				this.lblMessage.Visible = Conversions.ToBoolean("True");
			}
			else if (decimal.Compare(this.NoOfOperatorValue.Value, 100m) > 0)
			{
				this.msgIcon.Visible = Conversions.ToBoolean("True");
				this.lblMessage.Text = "You have reached maximum operator limit";
				this.lblMessage.Visible = Conversions.ToBoolean("True");
			}
			else
			{
				this.msgIcon.Visible = Conversions.ToBoolean("False");
				this.lblMessage.Visible = Conversions.ToBoolean("False");
			}
		}

		// Token: 0x06000159 RID: 345 RVA: 0x0001CA5C File Offset: 0x0001AE5C
		private void btnMinus_Click(object sender, EventArgs e)
		{
			decimal value = this.NumericNoOfOperator.Value;
			if (Convert.ToDouble(value) == Conversions.ToDouble("1"))
			{
				this.NumericNoOfOperator.Value = 1m;
			}
			else if (Convert.ToDouble(value) == Conversions.ToDouble("99"))
			{
				this.NumericNoOfOperator.Value = decimal.Subtract(this.NumericNoOfOperator.Value, 1m);
			}
			else
			{
				this.NumericNoOfOperator.Value = decimal.Subtract(this.NumericNoOfOperator.Value, 1m);
			}
		}

		// Token: 0x0600015A RID: 346 RVA: 0x0001CAF4 File Offset: 0x0001AEF4
		private void btnPlus_Click(object sender, EventArgs e)
		{
			decimal value = this.NumericNoOfOperator.Value;
			if (Convert.ToDouble(value) == Conversions.ToDouble("100"))
			{
				this.NumericNoOfOperator.Value = 100m;
			}
			else if (Convert.ToDouble(value) == Conversions.ToDouble("2"))
			{
				this.NumericNoOfOperator.Value = decimal.Add(this.NumericNoOfOperator.Value, 1m);
			}
			else
			{
				this.NumericNoOfOperator.Value = decimal.Add(this.NumericNoOfOperator.Value, 1m);
			}
		}

		// Token: 0x0600015B RID: 347 RVA: 0x0001CB90 File Offset: 0x0001AF90
		private void txtBadgeId_TextChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x04000023 RID: 35
		[AccessedThroughProperty("pnlMenu")]
		private Panel _pnlMenu;

		// Token: 0x04000024 RID: 36
		[AccessedThroughProperty("pcLegnano")]
		private PictureBox _pcLegnano;

		// Token: 0x04000025 RID: 37
		[AccessedThroughProperty("Label8")]
		private Label _Label8;

		// Token: 0x04000026 RID: 38
		[AccessedThroughProperty("lblSelectActivity")]
		private Label _lblSelectActivity;

		// Token: 0x04000027 RID: 39
		[AccessedThroughProperty("btnActivity6")]
		private Button _btnActivity6;

		// Token: 0x04000028 RID: 40
		[AccessedThroughProperty("btnActivity5")]
		private Button _btnActivity5;

		// Token: 0x04000029 RID: 41
		[AccessedThroughProperty("btnActivity4")]
		private Button _btnActivity4;

		// Token: 0x0400002A RID: 42
		[AccessedThroughProperty("btnActivity3")]
		private Button _btnActivity3;

		// Token: 0x0400002B RID: 43
		[AccessedThroughProperty("btnActivity2")]
		private Button _btnActivity2;

		// Token: 0x0400002C RID: 44
		[AccessedThroughProperty("btnActivity1")]
		private Button _btnActivity1;

		// Token: 0x0400002D RID: 45
		[AccessedThroughProperty("tbActivities")]
		private TabControl _tbActivities;

		// Token: 0x0400002E RID: 46
		[AccessedThroughProperty("tbSelectActivity")]
		private TabPage _tbSelectActivity;

		// Token: 0x0400002F RID: 47
		[AccessedThroughProperty("tbScanBarcodes")]
		private TabPage _tbScanBarcodes;

		// Token: 0x04000030 RID: 48
		[AccessedThroughProperty("tbSelectTasks")]
		private TabPage _tbSelectTasks;

		// Token: 0x04000031 RID: 49
		[AccessedThroughProperty("pcClose")]
		private PictureBox _pcClose;

		// Token: 0x04000032 RID: 50
		[AccessedThroughProperty("Label7")]
		private Label _Label7;

		// Token: 0x04000033 RID: 51
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x04000034 RID: 52
		[AccessedThroughProperty("Label2")]
		private Label _Label2;

		// Token: 0x04000035 RID: 53
		[AccessedThroughProperty("lblTime")]
		private Label _lblTime;

		// Token: 0x04000036 RID: 54
		[AccessedThroughProperty("Label3")]
		private Label _Label3;

		// Token: 0x04000037 RID: 55
		[AccessedThroughProperty("Label4")]
		private Label _Label4;

		// Token: 0x04000038 RID: 56
		[AccessedThroughProperty("btn3Activity")]
		private Button _btn3Activity;

		// Token: 0x04000039 RID: 57
		[AccessedThroughProperty("btn2Activity")]
		private Button _btn2Activity;

		// Token: 0x0400003A RID: 58
		[AccessedThroughProperty("btn1Activity")]
		private Button _btn1Activity;

		// Token: 0x0400003B RID: 59
		[AccessedThroughProperty("lblMessage")]
		private Label _lblMessage;

		// Token: 0x0400003C RID: 60
		[AccessedThroughProperty("txtCoreNo")]
		private TextBox _txtCoreNo;

		// Token: 0x0400003D RID: 61
		[AccessedThroughProperty("txtJobNo")]
		private TextBox _txtJobNo;

		// Token: 0x0400003E RID: 62
		[AccessedThroughProperty("btnEndJob")]
		private Button _btnEndJob;

		// Token: 0x0400003F RID: 63
		[AccessedThroughProperty("btnPauseJob")]
		private Button _btnPauseJob;

		// Token: 0x04000040 RID: 64
		[AccessedThroughProperty("Timer1")]
		private Timer _Timer1;

		// Token: 0x04000041 RID: 65
		[AccessedThroughProperty("lblActivity")]
		private Label _lblActivity;

		// Token: 0x04000042 RID: 66
		[AccessedThroughProperty("lblNoOfOperator")]
		private Label _lblNoOfOperator;

		// Token: 0x04000043 RID: 67
		[AccessedThroughProperty("Label9")]
		private Label _Label9;

		// Token: 0x04000044 RID: 68
		[AccessedThroughProperty("Label10")]
		private Label _Label10;

		// Token: 0x04000045 RID: 69
		[AccessedThroughProperty("Label11")]
		private Label _Label11;

		// Token: 0x04000046 RID: 70
		[AccessedThroughProperty("txtActivityName")]
		private TextBox _txtActivityName;

		// Token: 0x04000047 RID: 71
		[AccessedThroughProperty("btnResume")]
		private Button _btnResume;

		// Token: 0x04000048 RID: 72
		[AccessedThroughProperty("StatusName")]
		private TextBox _StatusName;

		// Token: 0x04000049 RID: 73
		[AccessedThroughProperty("statusCoreNo")]
		private TextBox _statusCoreNo;

		// Token: 0x0400004A RID: 74
		[AccessedThroughProperty("statusJobNo")]
		private TextBox _statusJobNo;

		// Token: 0x0400004B RID: 75
		[AccessedThroughProperty("statusBadgeId")]
		private TextBox _statusBadgeId;

		// Token: 0x0400004C RID: 76
		[AccessedThroughProperty("statusActivity")]
		private TextBox _statusActivity;

		// Token: 0x0400004D RID: 77
		[AccessedThroughProperty("Label15")]
		private Label _Label15;

		// Token: 0x0400004E RID: 78
		[AccessedThroughProperty("Label17")]
		private Label _Label17;

		// Token: 0x0400004F RID: 79
		[AccessedThroughProperty("Label16")]
		private Label _Label16;

		// Token: 0x04000050 RID: 80
		[AccessedThroughProperty("Label19")]
		private Label _Label19;

		// Token: 0x04000051 RID: 81
		[AccessedThroughProperty("Label18")]
		private Label _Label18;

		// Token: 0x04000052 RID: 82
		[AccessedThroughProperty("Label20")]
		private Label _Label20;

		// Token: 0x04000053 RID: 83
		[AccessedThroughProperty("txtBadgeId")]
		private TextBox _txtBadgeId;

		// Token: 0x04000054 RID: 84
		[AccessedThroughProperty("tbTableConfig")]
		private TabPage _tbTableConfig;

		// Token: 0x04000055 RID: 85
		[AccessedThroughProperty("txtConfigDepartmentCode")]
		private TextBox _txtConfigDepartmentCode;

		// Token: 0x04000056 RID: 86
		[AccessedThroughProperty("Label21")]
		private Label _Label21;

		// Token: 0x04000057 RID: 87
		[AccessedThroughProperty("txtConfigTableId")]
		private TextBox _txtConfigTableId;

		// Token: 0x04000058 RID: 88
		[AccessedThroughProperty("lblTable")]
		private Label _lblTable;

		// Token: 0x04000059 RID: 89
		[AccessedThroughProperty("btn4Activity")]
		private Button _btn4Activity;

		// Token: 0x0400005A RID: 90
		[AccessedThroughProperty("btnCancelConfig")]
		private Button _btnCancelConfig;

		// Token: 0x0400005B RID: 91
		[AccessedThroughProperty("btnSaveConfig")]
		private Button _btnSaveConfig;

		// Token: 0x0400005C RID: 92
		[AccessedThroughProperty("pcSettings")]
		private PictureBox _pcSettings;

		// Token: 0x0400005D RID: 93
		[AccessedThroughProperty("lblDepartmentCode")]
		private Label _lblDepartmentCode;

		// Token: 0x0400005E RID: 94
		[AccessedThroughProperty("lblTableId")]
		private Label _lblTableId;

		// Token: 0x0400005F RID: 95
		[AccessedThroughProperty("btnAdd")]
		private Button _btnAdd;

		// Token: 0x04000060 RID: 96
		[AccessedThroughProperty("btnSubtract")]
		private Button _btnSubtract;

		// Token: 0x04000061 RID: 97
		[AccessedThroughProperty("NoOfOperatorValue")]
		private NumericUpDown _NoOfOperatorValue;

		// Token: 0x04000062 RID: 98
		[AccessedThroughProperty("MsgIconConfig")]
		private PictureBox _MsgIconConfig;

		// Token: 0x04000063 RID: 99
		[AccessedThroughProperty("msgConfig")]
		private Label _msgConfig;

		// Token: 0x04000064 RID: 100
		[AccessedThroughProperty("Label12")]
		private Label _Label12;

		// Token: 0x04000065 RID: 101
		[AccessedThroughProperty("statusTime")]
		private TextBox _statusTime;

		// Token: 0x04000066 RID: 102
		[AccessedThroughProperty("buttonContinue")]
		private Button _buttonContinue;

		// Token: 0x04000067 RID: 103
		[AccessedThroughProperty("buttonBack")]
		private Button _buttonBack;

		// Token: 0x04000068 RID: 104
		[AccessedThroughProperty("btnClr2")]
		private Button _btnClr2;

		// Token: 0x04000069 RID: 105
		[AccessedThroughProperty("btnClr1")]
		private Button _btnClr1;

		// Token: 0x0400006A RID: 106
		[AccessedThroughProperty("Timer2")]
		private Timer _Timer2;

		// Token: 0x0400006B RID: 107
		[AccessedThroughProperty("msgIcon")]
		private PictureBox _msgIcon;

		// Token: 0x0400006C RID: 108
		[AccessedThroughProperty("StartJob")]
		private Button _StartJob;

		// Token: 0x0400006D RID: 109
		[AccessedThroughProperty("btnMinus")]
		private Button _btnMinus;

		// Token: 0x0400006E RID: 110
		[AccessedThroughProperty("btnPlus")]
		private Button _btnPlus;

		// Token: 0x0400006F RID: 111
		[AccessedThroughProperty("NumericNoOfOperator")]
		private NumericUpDown _NumericNoOfOperator;

		// Token: 0x04000070 RID: 112
		private string strBarcode;

		// Token: 0x04000071 RID: 113
		private Stopwatch stopwatch;

		// Token: 0x04000072 RID: 114
		public DateTime myTime;

		// Token: 0x04000073 RID: 115
		private bool myconnection;

		// Token: 0x04000074 RID: 116
		private string NoOfOperator;

		// Token: 0x04000075 RID: 117
		public string activity;

		// Token: 0x04000076 RID: 118
		public string badgeid;

		// Token: 0x04000077 RID: 119
		public string CustomerNo;

		// Token: 0x04000078 RID: 120
		public string CustomerName;

		// Token: 0x04000079 RID: 121
		public string Description;

		// Token: 0x0400007A RID: 122
		public string NetWeight;

		// Token: 0x0400007B RID: 123
		public string NonConformityDoing;

		// Token: 0x0400007C RID: 124
		public string jobno;

		// Token: 0x0400007D RID: 125
		public string coreno;

		// Token: 0x0400007E RID: 126
		public string tableid;

		// Token: 0x0400007F RID: 127
		public string status;

		// Token: 0x04000080 RID: 128
		private SqlConnection connection;

		// Token: 0x04000081 RID: 129
		public string BadgeStart;

		// Token: 0x04000082 RID: 130
		public string StartDate;

		// Token: 0x04000083 RID: 131
		public string BadgeEnd;

		// Token: 0x04000084 RID: 132
		public string EndDate;

		// Token: 0x04000085 RID: 133
		public string ConfigDepartmentCode;

		// Token: 0x04000086 RID: 134
		public string CoreDescription;

		// Token: 0x04000087 RID: 135
		public decimal WeightForUnitKg;

		// Token: 0x04000088 RID: 136
		public string CustomerDescription;

		// Token: 0x04000089 RID: 137
		public decimal ThicknessInmm;

		// Token: 0x0400008A RID: 138
		public decimal StackInmm;

		// Token: 0x0400008B RID: 139
		public decimal Column1MeasureInmm;

		// Token: 0x0400008C RID: 140
		public decimal CentralMeasureInmm;

		// Token: 0x0400008D RID: 141
		public decimal Column2MeasureInmm;

		// Token: 0x0400008E RID: 142
		public string ConfigTableId;

		// Token: 0x0400008F RID: 143
		private string jobstatus;

		// Token: 0x04000090 RID: 144
		private bool IsClicked;

		// Token: 0x04000091 RID: 145
		private string temp;

		// Token: 0x04000092 RID: 146
		private int ToDo;

		// Token: 0x04000093 RID: 147
		private int Doing;

		// Token: 0x04000094 RID: 148
		private int Done;

		// Token: 0x04000095 RID: 149
		private EventHandler MyEventHandler;

		// Token: 0x04000096 RID: 150
		private bool NoOfOperatorValueIsFocused;

		// Token: 0x04000097 RID: 151
		private ScanApp.VB_BarcodeSample1.API myScanSampleAPI;

		// Token: 0x04000098 RID: 152
		private EventHandler myReadNotifyHandler;

		// Token: 0x04000099 RID: 153
		private EventHandler myStatusNotifyHandler;

		// Token: 0x0400009A RID: 154
		private EventHandler myFormActivatedEventHandler;

		// Token: 0x0400009B RID: 155
		private EventHandler myFormDeactivatedEventHandler;

		// Token: 0x0400009C RID: 156
		private bool isReaderInitiated;

		// Token: 0x0400009D RID: 157
		private States prevState;
	}
}
