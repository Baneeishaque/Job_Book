﻿using System;
using System.Windows.Forms;
using Symbol;
using Symbol.Barcode;
using Symbol.Exceptions;
using Symbol.Generic;
using Symbol.StandardForms;

namespace ScanApp.VB_BarcodeSample1
{
	// Token: 0x02000006 RID: 6
	internal class API
	{
		// Token: 0x06000018 RID: 24 RVA: 0x0000FF00 File Offset: 0x0000E300
		public API()
		{
			this.myReader = null;
			this.myReaderData = null;
			this.myReadNotifyHandler = null;
			this.myStatusNotifyHandler = null;
			this.isBackground = false;
		}

		// Token: 0x06000019 RID: 25 RVA: 0x0000FF30 File Offset: 0x0000E330
		public bool InitReader()
		{
			bool result;
			if (this.myReader != null)
			{
				result = false;
			}
			else
			{
				try
				{
					Symbol.Generic.Device device = SelectDevice.Select(Symbol.Barcode.Device.Title, Symbol.Barcode.Device.AvailableDevices);
					if (device == null)
					{
						MessageBox.Show(Resources.GetString("NoDeviceSelected"), Resources.GetString("SelectDevice"));
						return false;
					}
					this.myReader = new Symbol.Barcode.Reader(device);
					this.myReaderData = new Symbol.Barcode.ReaderData(ReaderDataTypes.Text, ReaderDataLengths.MaximumLabel);
					this.myReader.Actions.Enable();
					switch (this.myReader.ReaderParameters.ReaderType)
					{
					case READER_TYPE.READER_TYPE_LASER:
						this.myReader.ReaderParameters.ReaderSpecific.LaserSpecific.AimType = AIM_TYPE.AIM_TYPE_TRIGGER;
						break;
					case READER_TYPE.READER_TYPE_IMAGER:
						this.myReader.ReaderParameters.ReaderSpecific.ImagerSpecific.AimType = AIM_TYPE.AIM_TYPE_TRIGGER;
						break;
					}
					this.myReader.Actions.SetParameters();
				}
				catch (OperationFailureException ex)
				{
					MessageBox.Show(string.Concat(new string[]
					{
						Resources.GetString("InitReader"),
						"\r\n",
						Resources.GetString("OperationFailure"),
						"\r\n",
						ex.Message,
						"\r\n",
						Resources.GetString("Result"),
						" = ",
						(checked((Results)((uint)ex.Result))).ToString()
					}));
					return false;
				}
				catch (InvalidRequestException ex2)
				{
					MessageBox.Show(string.Concat(new string[]
					{
						Resources.GetString("InitReader"),
						"\r\n",
						Resources.GetString("InvalidRequest"),
						"\r\n",
						ex2.Message
					}));
					return false;
				}
				catch (InvalidIndexerException ex3)
				{
					MessageBox.Show(string.Concat(new string[]
					{
						Resources.GetString("InitReader"),
						"\r\n",
						Resources.GetString("InvalidIndexer"),
						"\r\n",
						ex3.Message
					}));
					return false;
				}
				result = true;
			}
			return result;
		}

		// Token: 0x0600001A RID: 26 RVA: 0x000101E4 File Offset: 0x0000E5E4
		public void TermReader()
		{
			checked
			{
				if (this.myReader != null)
				{
					try
					{
						this.StopRead();
						this.DetachReadNotify();
						this.DetachStatusNotify();
						this.myReader.Actions.Disable();
						this.myReader.Dispose();
						this.myReader = null;
					}
					catch (OperationFailureException ex)
					{
						MessageBox.Show(string.Concat(new string[]
						{
							Resources.GetString("TermReader"),
							"\r\n",
							Resources.GetString("OperationFailure"),
							"\r\n",
							ex.Message,
							"\r\n",
							Resources.GetString("Result"),
							" = ",
							((Results)((uint)ex.Result)).ToString()
						}));
					}
					catch (InvalidRequestException ex2)
					{
						MessageBox.Show(string.Concat(new string[]
						{
							Resources.GetString("TermReader"),
							"\r\n",
							Resources.GetString("InvalidRequest"),
							"\r\n",
							ex2.Message
						}));
					}
					catch (InvalidIndexerException ex3)
					{
						MessageBox.Show(string.Concat(new string[]
						{
							Resources.GetString("TermReader"),
							"\r\n",
							Resources.GetString("InvalidIndexer"),
							"\r\n",
							ex3.Message
						}));
					}
				}
				if (this.myReaderData != null)
				{
					try
					{
						this.myReaderData.Dispose();
						this.myReaderData = null;
					}
					catch (OperationFailureException ex4)
					{
						MessageBox.Show(string.Concat(new string[]
						{
							Resources.GetString("TermReader"),
							"\r\n",
							Resources.GetString("OperationFailure"),
							"\r\n",
							ex4.Message,
							"\r\n",
							Resources.GetString("Result"),
							" = ",
							((Results)((uint)ex4.Result)).ToString()
						}));
					}
					catch (InvalidRequestException ex5)
					{
						MessageBox.Show(string.Concat(new string[]
						{
							Resources.GetString("TermReader"),
							"\r\n",
							Resources.GetString("InvalidRequest"),
							"\r\n",
							ex5.Message
						}));
					}
					catch (InvalidIndexerException ex6)
					{
						MessageBox.Show(string.Concat(new string[]
						{
							Resources.GetString("TermReader"),
							"\r\n",
							Resources.GetString("InvalidIndexer"),
							"\r\n",
							ex6.Message
						}));
					}
				}
			}
		}

		// Token: 0x0600001B RID: 27 RVA: 0x00010578 File Offset: 0x0000E978
		public void StartRead(bool toggleSoftTrigger)
		{
			if (this.myReader != null & this.myReaderData != null & !this.isBackground)
			{
				try
				{
					if (!this.myReaderData.IsPending)
					{
						this.myReader.Actions.Read(this.myReaderData);
						if (toggleSoftTrigger & !this.myReader.Info.SoftTrigger)
						{
							this.myReader.Info.SoftTrigger = true;
						}
					}
				}
				catch (OperationFailureException ex)
				{
					MessageBox.Show(string.Concat(new string[]
					{
						Resources.GetString("StartRead"),
						"\r\n",
						Resources.GetString("OperationFailure"),
						"\r\n",
						ex.Message,
						"\r\n",
						Resources.GetString("Result"),
						" = ",
						(checked((Results)((uint)ex.Result))).ToString()
					}));
				}
				catch (InvalidRequestException ex2)
				{
					MessageBox.Show(string.Concat(new string[]
					{
						Resources.GetString("StartRead"),
						"\r\n",
						Resources.GetString("InvalidRequest"),
						"\r\n",
						ex2.Message
					}));
				}
				catch (InvalidIndexerException ex3)
				{
					MessageBox.Show(string.Concat(new string[]
					{
						Resources.GetString("StartRead"),
						"\r\n",
						Resources.GetString("InvalidIndexer"),
						"\r\n",
						ex3.Message
					}));
				}
			}
		}

		// Token: 0x0600001C RID: 28 RVA: 0x00010778 File Offset: 0x0000EB78
		public void StopRead()
		{
			if (this.myReader != null)
			{
				try
				{
					if (this.myReader.Info.SoftTrigger)
					{
						this.myReader.Info.SoftTrigger = false;
					}
					this.myReader.Actions.Flush();
				}
				catch (OperationFailureException ex)
				{
					MessageBox.Show(string.Concat(new string[]
					{
						Resources.GetString("StopRead"),
						"\r\n",
						Resources.GetString("OperationFailure"),
						"\r\n",
						ex.Message,
						"\r\n",
						Resources.GetString("Result"),
						" = ",
						(checked((Results)((uint)ex.Result))).ToString()
					}));
				}
				catch (InvalidRequestException ex2)
				{
					MessageBox.Show(string.Concat(new string[]
					{
						Resources.GetString("StopRead"),
						"\r\n",
						Resources.GetString("InvalidRequest"),
						"\r\n",
						ex2.Message
					}));
				}
				catch (InvalidIndexerException ex3)
				{
					MessageBox.Show(string.Concat(new string[]
					{
						Resources.GetString("StopRead"),
						"\r\n",
						Resources.GetString("InvalidIndexer"),
						"\r\n",
						ex3.Message
					}));
				}
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x0600001D RID: 29 RVA: 0x00010940 File Offset: 0x0000ED40
		public Symbol.Barcode.Reader Reader
		{
			get
			{
				return this.myReader;
			}
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00010958 File Offset: 0x0000ED58
		public void AttachReadNotify(EventHandler ReadNotifyHandler)
		{
			if (this.myReader != null)
			{
				this.myReader.ReadNotify += ReadNotifyHandler;
				this.myReadNotifyHandler = ReadNotifyHandler;
			}
		}

		// Token: 0x0600001F RID: 31 RVA: 0x0001097C File Offset: 0x0000ED7C
		public void DetachReadNotify()
		{
			if (this.myReader != null & this.myReadNotifyHandler != null)
			{
				this.myReader.ReadNotify -= this.myReadNotifyHandler;
				this.myReadNotifyHandler = null;
			}
		}

		// Token: 0x06000020 RID: 32 RVA: 0x000109B8 File Offset: 0x0000EDB8
		public void AttachStatusNotify(EventHandler StatusNotifyHandler)
		{
			if (this.myReader != null)
			{
				this.myReader.StatusNotify += StatusNotifyHandler;
				this.myStatusNotifyHandler = StatusNotifyHandler;
			}
		}

		// Token: 0x06000021 RID: 33 RVA: 0x000109DC File Offset: 0x0000EDDC
		public void DetachStatusNotify()
		{
			if (this.myReader != null & this.myStatusNotifyHandler != null)
			{
				this.myReader.StatusNotify -= this.myStatusNotifyHandler;
				this.myStatusNotifyHandler = null;
			}
		}

		// Token: 0x04000007 RID: 7
		private Symbol.Barcode.Reader myReader;

		// Token: 0x04000008 RID: 8
		private Symbol.Barcode.ReaderData myReaderData;

		// Token: 0x04000009 RID: 9
		private EventHandler myReadNotifyHandler;

		// Token: 0x0400000A RID: 10
		private EventHandler myStatusNotifyHandler;

		// Token: 0x0400000B RID: 11
		public bool isBackground;
	}
}
