﻿namespace ZebraApp
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.btnNonConformity = new System.Windows.Forms.Button();
            this.BtnAssembly = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblDepartmentCode = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.pictureBoxSettings = new System.Windows.Forms.PictureBox();
            this.lblTableID = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnLegnano = new System.Windows.Forms.Button();
            this.timertickerticker = new System.Windows.Forms.Timer();
            this.timer1 = new System.Windows.Forms.Timer();
            this.panelTable = new System.Windows.Forms.Panel();
            this.panelLast = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnDepartmentCodeClear = new System.Windows.Forms.Button();
            this.TxtDepartmentCode = new System.Windows.Forms.TextBox();
            this.btntableIdClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtTableId = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panelTable.SuspendLayout();
            this.panelLast.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnNonConformity
            // 
            this.btnNonConformity.BackColor = System.Drawing.Color.DarkBlue;
            this.btnNonConformity.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.btnNonConformity.ForeColor = System.Drawing.Color.White;
            this.btnNonConformity.Location = new System.Drawing.Point(25, 124);
            this.btnNonConformity.Name = "btnNonConformity";
            this.btnNonConformity.Size = new System.Drawing.Size(268, 63);
            this.btnNonConformity.TabIndex = 7;
            this.btnNonConformity.Text = "NON CONFORMITY";
            this.btnNonConformity.Click += new System.EventHandler(this.btnNonConformity_Click);
            // 
            // BtnAssembly
            // 
            this.BtnAssembly.BackColor = System.Drawing.Color.DarkBlue;
            this.BtnAssembly.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.BtnAssembly.ForeColor = System.Drawing.Color.White;
            this.BtnAssembly.Location = new System.Drawing.Point(25, 46);
            this.BtnAssembly.Name = "BtnAssembly";
            this.BtnAssembly.Size = new System.Drawing.Size(268, 63);
            this.BtnAssembly.TabIndex = 6;
            this.BtnAssembly.Text = "ASSEMBLY";
            this.BtnAssembly.Click += new System.EventHandler(this.BtnAssembly_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.lblTime);
            this.panel1.Controls.Add(this.lblDepartmentCode);
            this.panel1.Controls.Add(this.lblDate);
            this.panel1.Controls.Add(this.pictureBoxSettings);
            this.panel1.Controls.Add(this.lblTableID);
            this.panel1.Location = new System.Drawing.Point(0, 210);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(319, 30);
            // 
            // lblTime
            // 
            this.lblTime.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.lblTime.Location = new System.Drawing.Point(242, 4);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(91, 20);
            this.lblTime.Text = "00:00:00";
            // 
            // lblDepartmentCode
            // 
            this.lblDepartmentCode.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.lblDepartmentCode.Location = new System.Drawing.Point(35, 4);
            this.lblDepartmentCode.Name = "lblDepartmentCode";
            this.lblDepartmentCode.Size = new System.Drawing.Size(60, 20);
            this.lblDepartmentCode.Text = "AE-APW";
            // 
            // lblDate
            // 
            this.lblDate.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.lblDate.Location = new System.Drawing.Point(161, 4);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(86, 20);
            this.lblDate.Text = "3/11/2010";
            // 
            // pictureBoxSettings
            // 
            this.pictureBoxSettings.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxSettings.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxSettings.Image")));
            this.pictureBoxSettings.Location = new System.Drawing.Point(4, 1);
            this.pictureBoxSettings.Name = "pictureBoxSettings";
            this.pictureBoxSettings.Size = new System.Drawing.Size(25, 26);
            this.pictureBoxSettings.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxSettings.Click += new System.EventHandler(this.pictureBoxSettings_Click);
            // 
            // lblTableID
            // 
            this.lblTableID.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.lblTableID.Location = new System.Drawing.Point(101, 4);
            this.lblTableID.Name = "lblTableID";
            this.lblTableID.Size = new System.Drawing.Size(58, 20);
            this.lblTableID.Text = "M00045";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Red;
            this.btnClose.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(285, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(21, 20);
            this.btnClose.TabIndex = 35;
            this.btnClose.Text = "X";
            this.btnClose.Visible = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnLegnano
            // 
            this.btnLegnano.BackColor = System.Drawing.Color.Navy;
            this.btnLegnano.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.btnLegnano.ForeColor = System.Drawing.Color.White;
            this.btnLegnano.Location = new System.Drawing.Point(0, 0);
            this.btnLegnano.Name = "btnLegnano";
            this.btnLegnano.Size = new System.Drawing.Size(79, 22);
            this.btnLegnano.TabIndex = 40;
            this.btnLegnano.Text = "LEGNANO";
            this.btnLegnano.Click += new System.EventHandler(this.btnLegnano_Click);
            // 
            // timertickerticker
            // 
            this.timertickerticker.Enabled = true;
            this.timertickerticker.Interval = 1000;
            this.timertickerticker.Tick += new System.EventHandler(this.timertickerticker_Tick);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panelTable
            // 
            this.panelTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(225)))));
            this.panelTable.Controls.Add(this.panelLast);
            this.panelTable.Controls.Add(this.label5);
            this.panelTable.Controls.Add(this.label17);
            this.panelTable.Controls.Add(this.btnCancel);
            this.panelTable.Controls.Add(this.btnDepartmentCodeClear);
            this.panelTable.Controls.Add(this.TxtDepartmentCode);
            this.panelTable.Controls.Add(this.btntableIdClear);
            this.panelTable.Controls.Add(this.btnSave);
            this.panelTable.Controls.Add(this.txtTableId);
            this.panelTable.Location = new System.Drawing.Point(0, 0);
            this.panelTable.Name = "panelTable";
            this.panelTable.Size = new System.Drawing.Size(316, 211);
            // 
            // panelLast
            // 
            this.panelLast.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(225)))));
            this.panelLast.Controls.Add(this.textBox3);
            this.panelLast.Controls.Add(this.textBox2);
            this.panelLast.Controls.Add(this.textBox1);
            this.panelLast.Controls.Add(this.textBox4);
            this.panelLast.Controls.Add(this.button4);
            this.panelLast.Controls.Add(this.button6);
            this.panelLast.Controls.Add(this.button5);
            this.panelLast.Controls.Add(this.label12);
            this.panelLast.Controls.Add(this.textBox9);
            this.panelLast.Controls.Add(this.label7);
            this.panelLast.Controls.Add(this.button3);
            this.panelLast.Controls.Add(this.label4);
            this.panelLast.Controls.Add(this.label1);
            this.panelLast.Controls.Add(this.label6);
            this.panelLast.Location = new System.Drawing.Point(0, 3);
            this.panelLast.Name = "panelLast";
            this.panelLast.Size = new System.Drawing.Size(313, 204);
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.textBox3.Location = new System.Drawing.Point(129, 99);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(174, 25);
            this.textBox3.TabIndex = 55;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.textBox2.Location = new System.Drawing.Point(129, 68);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(174, 25);
            this.textBox2.TabIndex = 54;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.textBox1.Location = new System.Drawing.Point(129, 40);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(174, 25);
            this.textBox1.TabIndex = 53;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.textBox4.Location = new System.Drawing.Point(129, 9);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(174, 25);
            this.textBox4.TabIndex = 44;
            this.textBox4.Text = "DI-1125225";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Red;
            this.button4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(228, 164);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(81, 37);
            this.button4.TabIndex = 34;
            this.button4.Text = "END";
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Navy;
            this.button6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(90, 164);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(65, 37);
            this.button6.TabIndex = 33;
            this.button6.Text = "PAUSE";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Navy;
            this.button5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(157, 164);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(65, 37);
            this.button5.TabIndex = 32;
            this.button5.Text = "RESUME";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(3, 141);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 20);
            this.label12.Text = "Time";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.textBox9.Location = new System.Drawing.Point(129, 134);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(173, 25);
            this.textBox9.TabIndex = 21;
            this.textBox9.Text = "00:00:00";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(3, 102);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 22);
            this.label7.Text = "Status";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(3, 164);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(81, 37);
            this.button3.TabIndex = 9;
            this.button3.Text = "START";
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(3, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 20);
            this.label4.Text = "Core No";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(3, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.Text = "Job No";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(3, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 20);
            this.label6.Text = "Operator Badge Id";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(1, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 20);
            this.label5.Text = "Department Code";
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(3, 52);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 20);
            this.label17.Text = "Table Id";
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Red;
            this.btnCancel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(218, 128);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(86, 37);
            this.btnCancel.TabIndex = 39;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnDepartmentCodeClear
            // 
            this.btnDepartmentCodeClear.BackColor = System.Drawing.Color.Red;
            this.btnDepartmentCodeClear.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.btnDepartmentCodeClear.ForeColor = System.Drawing.Color.White;
            this.btnDepartmentCodeClear.Location = new System.Drawing.Point(268, 88);
            this.btnDepartmentCodeClear.Name = "btnDepartmentCodeClear";
            this.btnDepartmentCodeClear.Size = new System.Drawing.Size(35, 34);
            this.btnDepartmentCodeClear.TabIndex = 38;
            this.btnDepartmentCodeClear.Text = "X";
            this.btnDepartmentCodeClear.Click += new System.EventHandler(this.btnDepartmentCodeClear_Click);
            // 
            // TxtDepartmentCode
            // 
            this.TxtDepartmentCode.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.TxtDepartmentCode.Location = new System.Drawing.Point(122, 88);
            this.TxtDepartmentCode.Multiline = true;
            this.TxtDepartmentCode.Name = "TxtDepartmentCode";
            this.TxtDepartmentCode.Size = new System.Drawing.Size(141, 34);
            this.TxtDepartmentCode.TabIndex = 37;
            this.TxtDepartmentCode.Text = "AE-APW";
            // 
            // btntableIdClear
            // 
            this.btntableIdClear.BackColor = System.Drawing.Color.Red;
            this.btntableIdClear.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.btntableIdClear.ForeColor = System.Drawing.Color.White;
            this.btntableIdClear.Location = new System.Drawing.Point(268, 47);
            this.btntableIdClear.Name = "btntableIdClear";
            this.btntableIdClear.Size = new System.Drawing.Size(35, 31);
            this.btntableIdClear.TabIndex = 34;
            this.btntableIdClear.Text = "X";
            this.btntableIdClear.Click += new System.EventHandler(this.btntableIdClear_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Green;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(122, 128);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(86, 37);
            this.btnSave.TabIndex = 33;
            this.btnSave.Text = "SAVE";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtTableId
            // 
            this.txtTableId.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.txtTableId.Location = new System.Drawing.Point(122, 47);
            this.txtTableId.Multiline = true;
            this.txtTableId.Name = "txtTableId";
            this.txtTableId.Size = new System.Drawing.Size(141, 31);
            this.txtTableId.TabIndex = 23;
            this.txtTableId.Text = "M00045";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(225)))));
            this.ClientSize = new System.Drawing.Size(319, 240);
            this.Controls.Add(this.panelTable);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnLegnano);
            this.Controls.Add(this.BtnAssembly);
            this.Controls.Add(this.btnNonConformity);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMain";
            this.Text = "LEGNANO";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.panel1.ResumeLayout(false);
            this.panelTable.ResumeLayout(false);
            this.panelLast.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNonConformity;
        private System.Windows.Forms.Button BtnAssembly;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblDepartmentCode;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.PictureBox pictureBoxSettings;
        private System.Windows.Forms.Label lblTableID;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnLegnano;
        private System.Windows.Forms.Timer timertickerticker;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panelTable;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnDepartmentCodeClear;
        private System.Windows.Forms.TextBox TxtDepartmentCode;
        private System.Windows.Forms.Button btntableIdClear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtTableId;
        private System.Windows.Forms.Panel panelLast;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
    }
}

