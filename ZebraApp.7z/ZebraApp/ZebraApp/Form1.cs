﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Diagnostics;
namespace ZebraApp
{
    public partial class frmMain : Form
    {
        int ms, s, m, h;

        int ms1, s1, m1, h1;
        public frmMain()
        {
            InitializeComponent();
            ms = 0;
            ms1 = 0;
        }
        Stopwatch stopwatch = new Stopwatch();

        Stopwatch timerstartsnow = new Stopwatch();



        private Symbol.Barcode.Reader MyReader = null;
        private Symbol.Barcode.ReaderData MyReaderData = null; 
        private void BtnAssembly_Click(object sender, EventArgs e)
        {
            pictureBoxSettings.Visible = false;
            panelTable.Visible = true;
            panelLast.Visible = true;

            //  Assembly

            label7.Hide();
            textBox3.Hide();
            label12.Hide();
            textBox9.Hide();
            button3.Text = "Back";
            button3.BackColor = Color.Red;
            button4.Text = "Continue";
            button4.BackColor = Color.Green;
            button6.Hide();
            button5.Hide();



            ////Barcode Enable
            //textBox4.Focus();
            //MyReader = new Symbol.Barcode.Reader();
            //MyReaderData = new Symbol.Barcode.ReaderData(Symbol.Barcode.ReaderDataTypes.Text,
            //Symbol.Barcode.ReaderDataLengths.DefaultText);
            //MyReader.ReadNotify += new EventHandler(MyReader_ReadNotify);
            //MyReader.Actions.Enable();
            //MyReader.Actions.Read(MyReaderData);
            //return; 








        }
        
       //private void MyReader_ReadNotify(object sender, EventArgs e)
       // {

       //     textBox4.Focus();
       //     MyReader.Actions.Read(MyReaderData);
       //     return;
       // }

       //public void SymbolReader_ReadNotify(object sender, EventArgs e)
       //{
       //    Symbol.Barcode.ReaderData TheReaderData = Scanner.SymbolReader.GetNextReaderData();
       //    if (TheReaderData.Result == Symbol.Results.SUCCESS && (textBox4.Focused == true))
       //    {
       //        if (textBox4.Focused == true)
       //        {
       //            textBox4.Text = TheReaderData.Text.ToString();
       //            Scanner.SymbolReader.Actions.Read(Scanner.SymbolReaderData);
       //            return;
       //        }
       //    }
       //    Scanner.SymbolReader.Actions.Read(Scanner.SymbolReaderData);
       //}


        private void btnNonConformity_Click(object sender, EventArgs e)
        {
            pictureBoxSettings.Visible = false;
            panelTable.Visible = true;
            panelLast.Visible = true;

            //  Assembly

            label7.Hide();
            textBox3.Hide();
            label12.Hide();
            textBox9.Hide();
            button3.Text = "Back";
            button3.BackColor = Color.Red;
            button4.Text = "Continue";
            button4.BackColor = Color.Green;
            button6.Hide();
            button5.Hide();


        }
        private void frmMain_Load(object sender, EventArgs e)
        {
            panelTable.Hide();
            panelLast.Hide();
            //   panelLast.Hide();
            pictureBoxSettings.Show();




            timerstartsnow.Stop();



            //Date and Time


            DateTime datetoday = DateTime.Now;
            lblDate.Text = datetoday.ToShortDateString();


            string currenttime = DateTime.Now.ToString("HH:mm:ss");
            lblTime.Text = currenttime.ToString();

            //Screen resolution

            this.WindowState = FormWindowState.Normal;
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = true;
            this.Location = new Point(0, 0);
            var fullscreenSize = new Size(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            this.Size = fullscreenSize;

        }

        private void pictureBoxSettings_Click(object sender, EventArgs e)
        {
            panelTable.Show();


            //assembly






        }






        private void btnLegnano_Click(object sender, EventArgs e)
        {
            if (btnClose.Visible == true)
            {

                btnClose.Visible = false;
            }
            else
            {
                btnClose.Visible = true;

            }


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        string stopwatchs;
        private void timertickerticker_Tick(object sender, EventArgs e)
        {

            string currenttime = DateTime.Now.ToString("HH:mm:ss");
            lblTime.Text = currenttime.ToString();


            //stopwatch

            ms = ms + 1;
            if (ms == 9)
            {
                ms = 0;
                s = s + 1;

                if (s == 59)
                {
                    s = 0;
                    m = m + 1;

                    if (m == 59)
                    {
                        m = 0;
                        h = h + 1;

                        {

                        }
                    }
                }


                stopwatchs = (h.ToString() + " : " + m.ToString() + " : " + " : " + s.ToString());
                timertickerticker.Enabled = true;
                lblTime.Text = stopwatchs;
            }
        }











        private void btncontinue_Click(object sender, EventArgs e)
        {





        }

        private void btntableIdClear_Click(object sender, EventArgs e)
        {
            txtTableId.Text = "";
        }

        private void btnDepartmentCodeClear_Click(object sender, EventArgs e)
        {
            TxtDepartmentCode.Text = "";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            if (txtTableId.Text != "" && TxtDepartmentCode.Text != "")
            {

                lblDepartmentCode.Text = TxtDepartmentCode.Text;
                lblTableID.Text = txtTableId.Text;
                MessageBox.Show("Table Id and Department Code saved successfully");
                panelTable.Visible = false;

            }
            else
            {

                MessageBox.Show("Please enter Table Id and Department Code");

            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (txtTableId.Text == "" || TxtDepartmentCode.Text == "")
            {
                txtTableId.Text = "M00045";
                TxtDepartmentCode.Text = "AE-APW";

            }

            panelTable.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {


            if (button4.Text == "Continue")
            {
                label7.Show();
                textBox3.Show();
                label12.Show();
                textBox9.Show();
                button3.Text = "START";
                button3.BackColor = Color.Green;
                button4.Text = "END";
                button4.BackColor = Color.Red;
                button6.Show();
                button5.Show();

                textBox4.Enabled = false;
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                textBox3.Enabled = false;


            }
            else //End
            {
                panelLast.Hide();
                panelTable.Hide();
                pictureBoxSettings.Show();

                textBox1.Text = "";
                textBox2.Text = "";
                textBox9.Text = "";
                textBox4.Text = "";
                textBox3.Text = "";

                textBox4.Enabled = true;
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                textBox3.Enabled = true;

                //timer stop
                timerstartsnow.Stop();
            }


        }

      

        private void button3_Click(object sender, EventArgs e)
        {

            if (button3.Text == "Back")
            {
                panelLast.Hide();
                panelTable.Hide();

                //MyReader.Actions.Flush();
                //MyReader.Actions.Disable();
                //MyReader.Dispose();
                //MyReaderData.Dispose();
                //return;  
            }
            else
            {

                //Timer
                timerstartsnow.Start();
              
            }





        }
        string timerstartsnows;
        private void timer1_Tick(object sender, EventArgs e)
        {
            ms1 = ms1 + 1;
            if (ms1 == 9)
            {
                ms1 = 0;
                s1 = s1 + 1;

                if (s1 == 59)
                {
                    s1 = 0;
                    m1 = m1 + 1;

                    if (m1 == 59)
                    {
                        m1 = 0;
                        h1 = h1 + 1;

                        {

                        }
                    }
                }


                timerstartsnows = (h1.ToString() + " : " + m1.ToString() + " : " + " : " + s1.ToString());
                timer1.Enabled = true;
                textBox9.Text = timerstartsnows;
            }
        }









        //private Symbol.Barcode.Reader MyReader = null;
        //private Symbol.Barcode.ReaderData MyReaderData = null; 

        //private void btnNonConformity_Click_1(object sender, EventArgs e)
        //{
        //    pictureBoxSettings.Visible = false;

        //    panelLast.Visible = true;
        //    panelTable.Visible = false;



        //    btnBack.Visible = true;
        //    btnContinue.Visible = true;
        //    btnstart.Visible = false;
        //    btnPause.Visible = false;
        //    btnResume.Visible = false;
        //    btnEnd.Visible = false;
        //    lblStatus.Visible = false;
        //    txtStatus.Visible = false;
        //    lblTimeof.Visible = false;
        //    txttime.Visible = false;





        //    MyReader = new Symbol.Barcode.Reader();
        //    MyReaderData =
        //    new Symbol.Barcode.ReaderData(Symbol.Barcode.ReaderDataTypes.Text,
        //    Symbol.Barcode.ReaderDataLengths.DefaultText);
        //    MyReader.ReadNotify += new EventHandler(MyReader_ReadNotify);
        //    MyReader.Actions.Enable();
        //    MyReader.Actions.Read(MyReaderData);
        //    return; 








        //}

        //private void MyReader_ReadNotify(object sender, EventArgs e)
        //{
        ////    System.Windows.Forms.MessageBox.Show(MyReaderData.Text, "HelloScan");
        //    MyReader.Actions.Read(MyReaderData);
        //    return;
        //}



        //public void SymbolReader_ReadNotify(object sender, EventArgs e)
        //{
        //    Symbol.Barcode.ReaderData TheReaderData = Scanner.SymbolReader.GetNextReaderData();
        //    if (TheReaderData.Result == Symbol.Results.SUCCESS && (txtoperatorID.Focused == true))
        //    {
        //        if (txtoperatorID.Focused == true)
        //        {
        //            txtoperatorID.Text = TheReaderData.Text.ToString();
        //            Scanner.SymbolReader.Actions.Read(Scanner.SymbolReaderData);
        //            return;
        //        }
        //    }
        //    Scanner.SymbolReader.Actions.Read(Scanner.SymbolReaderData);
        //}

















    }
}
